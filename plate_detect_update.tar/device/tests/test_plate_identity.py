"""Persistent plate identity and stage tracking used by the MQTT publisher."""

from __future__ import annotations

import unittest

from plate_detector.plate_identity import PlateIdentityTracker

SHAPE = (480, 640, 3)


def instance(tracker_id, center_y, color="orange"):
    return {"tracker_id": tracker_id, "xyxy": [100, center_y - 20, 140, center_y + 20], "stable_color": color}


class PlateIdentityTest(unittest.TestCase):
    def setUp(self):
        self.clock = [0.0]
        self.tracker = PlateIdentityTracker()
        self.tracker._now = lambda: self.clock[0]

    def step(self, *instances):
        self.clock[0] += 0.1
        items = list(instances)
        self.tracker.update(items, SHAPE)
        return items

    def test_stages_follow_entry_count_and_exit_lines(self):
        stages = [self.step(instance(1, y))[0]["tracking_stage"] for y in (460, 380, 200, 50)]
        self.assertEqual(stages, ["approaching", "entered", "counted", "exit_candidate"])

    def test_new_tracker_id_near_lost_plate_reuses_persistent_id(self):
        first = self.step(instance(1, 400))[0]
        second = self.step(instance(7, 395))[0]
        self.assertEqual(first["persistent_plate_id"], second["persistent_plate_id"])
        self.assertEqual(self.tracker.states[first["persistent_plate_id"]].reappearances, 1)

    def test_finished_plate_is_never_revived(self):
        item = self.step(instance(1, 400))[0]
        self.tracker.finalize_disappearance(item["persistent_plate_id"], "exit")
        later = self.step(instance(1, 390))[0]
        self.assertTrue(later.get("ignore_after_exit"))
        self.assertNotIn("persistent_plate_id", later)


if __name__ == "__main__":
    unittest.main()
