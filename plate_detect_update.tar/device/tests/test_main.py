"""Tests for the device command dispatcher."""

from __future__ import annotations

import sys
import unittest
from unittest.mock import patch

import main


class MainTest(unittest.TestCase):
    def test_detect_subcommand_forwards_arguments(self):
        with patch.object(sys, "argv", ["main.py", "detect", "--camera", "2"]):
            with patch.object(main, "_detect") as handler:
                main.main()
                self.assertEqual(sys.argv, ["main.py", "--camera", "2"])
        handler.assert_called_once_with()

    def test_list_cameras_dispatches(self):
        with patch.object(sys, "argv", ["main.py", "--list-cameras"]):
            with patch.object(main, "_list_cameras") as handler:
                main.main()
        handler.assert_called_once_with()

    def test_camera_bind_dispatches_binding_tool(self):
        with patch.object(sys, "argv", ["main.py", "camera-bind", "--camera", "0", "--camera-id", "cam-2"]):
            with patch.object(main, "_camera_bind") as handler:
                main.main()
                self.assertEqual(sys.argv, ["main.py", "--camera", "0", "--camera-id", "cam-2"])
        handler.assert_called_once_with()

    def test_validation_commands_are_not_on_the_device_entry(self):
        for command in ("self-check", "evaluate", "record", "batch-preprocess"):
            with patch.object(sys, "argv", ["main.py", command]):
                with self.assertRaises(SystemExit):
                    main.main()


if __name__ == "__main__":
    unittest.main()
