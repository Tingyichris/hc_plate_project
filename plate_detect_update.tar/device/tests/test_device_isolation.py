"""The device package must run without the validation package."""

from __future__ import annotations

import ast
import unittest
from pathlib import Path

DEVICE_ROOT = Path(__file__).resolve().parents[1] / "plate_detector"


class DeviceIsolationTest(unittest.TestCase):
    def test_device_code_never_imports_validation(self):
        offenders = []
        for path in DEVICE_ROOT.rglob("*.py"):
            for node in ast.walk(ast.parse(path.read_text(encoding="utf-8"))):
                names = []
                if isinstance(node, ast.Import):
                    names = [alias.name for alias in node.names]
                elif isinstance(node, ast.ImportFrom) and node.level == 0:
                    names = [node.module or ""]
                offenders += [f"{path.name}: {name}" for name in names if name.split(".")[0] == "validation"]
        self.assertEqual(offenders, [])


if __name__ == "__main__":
    unittest.main()
