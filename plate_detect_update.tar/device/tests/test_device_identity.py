"""Tests for zero-configuration Raspberry Pi identity generation."""

from unittest.mock import patch

from plate_detector import device_identity


def test_automatic_pi_id_is_stable_and_topic_safe():
    with (
        patch.object(device_identity, "_machine_id", return_value="machine-a"),
        patch.object(device_identity.uuid, "getnode", return_value=0x112233445566),
    ):
        first = device_identity.automatic_pi_id()
        second = device_identity.automatic_pi_id()
    assert first == second
    assert first.startswith("pi-")
    assert len(first) == 15
    assert not any(character in first for character in "/+#")
