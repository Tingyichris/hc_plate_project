"""Tests for stable logical camera IDs resolved from USB device paths."""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import cv2

from plate_detector import camera_registry
from plate_detector.camera_registry import (
    auto_bind_devices,
    binding_for,
    binding_for_index,
    enumerate_devices,
    load_device_config,
    resolve_camera_index,
    save_binding,
    save_device_config,
)


def camera(index: int, path: str, name: str = "USB Camera"):
    return SimpleNamespace(index=index, path=path, name=name, vid=123, pid=456)


class CameraRegistryTest(unittest.TestCase):
    def test_auto_binding_assigns_cam_ids_by_stable_port_order(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "device_config.json"
            bindings = auto_bind_devices(
                path=path,
                devices=[camera(4, "port-b"), camera(2, "port-a")],
            )
            self.assertEqual(
                [(item["camera_id"], item["device_path"]) for item in bindings],
                [("cam-1", "port-a"), ("cam-2", "port-b")],
            )

            index, _binding = resolve_camera_index(
                "cam-1",
                path=path,
                devices=[camera(9, "port-a"), camera(3, "port-b")],
            )
            self.assertEqual(index, 9)
            self.assertEqual(
                binding_for_index(
                    3,
                    path=path,
                    devices=[camera(9, "port-a"), camera(3, "port-b")],
                )["camera_id"],
                "cam-2",
            )

    def test_auto_binding_preserves_ids_and_appends_new_ports(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "device_config.json"
            auto_bind_devices(path=path, devices=[camera(0, "port-b")])
            bindings = auto_bind_devices(
                path=path,
                devices=[camera(1, "port-a"), camera(0, "port-b")],
            )
            by_path = {item["device_path"]: item["camera_id"] for item in bindings}
            self.assertEqual(by_path, {"port-b": "cam-1", "port-a": "cam-2"})

    def test_raspberry_pi_isp_nodes_are_never_bound(self):
        devices = [
            camera(22, "isp-1", "bcm2835-isp-capture1"),
            camera(0, "usb-port-1", "openaicam: openaicam"),
            camera(14, "isp-0", "bcm2835-isp-capture0"),
        ]
        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "device_config.json"
            bindings = auto_bind_devices(path=path, devices=devices)
            self.assertEqual(
                [(item["camera_id"], item["device_path"]) for item in bindings],
                [("cam-1", "usb-port-1")],
            )
        with patch.object(camera_registry, "_enumerate_all_devices", return_value=devices):
            self.assertEqual([item.index for item in enumerate_devices()], [0])

    def test_existing_isp_bindings_are_pruned_and_real_ids_kept(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "device_config.json"
            save_device_config({"schema_version": 4, "cameras": [
                {"camera_id": "cam-1", "device_path": "usb-port-1", "device_name": "USB2.0 HD UVC WebCam"},
                {"camera_id": "cam-3", "device_path": "isp-1", "device_name": "bcm2835-isp-capture1"},
                {"camera_id": "cam-4", "device_path": "usb-port-2", "device_name": "openaicam: openaicam"},
            ]}, path)
            bindings = auto_bind_devices(path=path, devices=[camera(0, "usb-port-2", "openaicam: openaicam")])
            self.assertEqual([item["camera_id"] for item in bindings], ["cam-1", "cam-4"])
            self.assertEqual(
                [item["camera_id"] for item in load_device_config(path)["cameras"]], ["cam-1", "cam-4"]
            )

    def test_windows_enumeration_uses_directshow(self):
        with (
            patch.object(camera_registry.sys, "platform", "win32"),
            patch.object(camera_registry, "enumerate_cameras", return_value=[]) as mocked,
        ):
            self.assertEqual(enumerate_devices(), [])
        mocked.assert_called_once_with(cv2.CAP_DSHOW)

    def test_linux_enumeration_uses_v4l2(self):
        with (
            patch.object(camera_registry.sys, "platform", "linux"),
            patch.object(camera_registry, "enumerate_cameras", return_value=[]) as mocked,
        ):
            self.assertEqual(enumerate_devices(), [])
        mocked.assert_called_once_with(cv2.CAP_V4L2)

    def test_macos_enumeration_uses_avfoundation(self):
        with (
            patch.object(camera_registry.sys, "platform", "darwin"),
            patch.object(camera_registry, "enumerate_cameras", return_value=[]) as mocked,
        ):
            self.assertEqual(enumerate_devices(), [])
        mocked.assert_called_once_with(cv2.CAP_AVFOUNDATION)

    def test_device_config_contains_only_generated_usb_bindings(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "device_config.json"
            save_device_config(
                {
                    "pi_id": "pi-07",
                    "backend": {"url": "https://backend.local"},
                    "cameras": [],
                },
                path,
            )
            save_binding(0, "cam-1", path=path, devices=[camera(0, "port-a")])
            config = load_device_config(path)
            self.assertEqual(config["schema_version"], 4)
            self.assertEqual(config["cameras"][0]["camera_id"], "cam-1")
            self.assertNotIn("mqtt", config)
            self.assertNotIn("pi_id", config)
            self.assertNotIn("backend", config)

    def test_schema_two_mqtt_settings_are_ignored(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "device_config.json"
            path.write_text(
                '{"schema_version":2,"pi_id":"pi-01",'
                '"mqtt":{"host":"old-broker"},"cameras":[]}',
                encoding="utf-8",
            )
            config = load_device_config(path)
            self.assertEqual(config["schema_version"], 4)
            self.assertNotIn("mqtt", config)

    def test_binding_follows_usb_path_when_index_changes(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "camera_bindings.json"
            save_binding(
                camera_index=0,
                camera_id="cam-2",
                mqtt_camera_id="mqtt-cam-2",
                handoff_role="upstream",
                peer_camera_id="mqtt-cam-3",
                path=path,
                devices=[camera(0, r"\\?\usb#port-a")],
            )
            index, binding = resolve_camera_index(
                "cam-2",
                path=path,
                devices=[camera(3, r"\\?\USB#PORT-A")],
            )
            self.assertEqual(index, 3)
            self.assertEqual(binding["mqtt_camera_id"], "mqtt-cam-2")
            self.assertEqual(binding["handoff_role"], "upstream")

    def test_rebinding_camera_id_replaces_old_usb_path(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "camera_bindings.json"
            save_binding(0, "cam-2", path=path, devices=[camera(0, "port-a")])
            save_binding(1, "cam-2", path=path, devices=[camera(1, "port-b")])
            self.assertEqual(binding_for("cam-2", path)["device_path"], "port-b")
            with self.assertRaises(LookupError):
                resolve_camera_index(
                    "cam-2", path=path, devices=[camera(0, "port-a")]
                )

    def test_binding_stores_both_neighbor_directions(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "camera_bindings.json"
            binding = save_binding(
                1, "cam-2",
                upstream_camera_id="cam-1",
                downstream_camera_id="cam-3",
                path=path,
                devices=[camera(1, "port-b")],
            )
            self.assertEqual(binding["handoff_role"], "both")
            self.assertEqual(binding["upstream_camera_id"], "cam-1")
            self.assertEqual(binding["downstream_camera_id"], "cam-3")

    def test_camera_without_device_path_is_rejected(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "camera_bindings.json"
            with self.assertRaises(ValueError):
                save_binding(1, "virtual", path=path, devices=[camera(1, "")])


if __name__ == "__main__":
    unittest.main()
