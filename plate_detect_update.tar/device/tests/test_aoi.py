"""Four-point AOI persistence and per-camera file resolution."""

from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

import numpy as np

from plate_detector import constants as const
from plate_detector.aoi import load_aoi_polygon, resolve_aoi_file, save_aoi_polygon


class AoiTest(unittest.TestCase):
    def test_round_trip_keeps_four_points(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "nested" / "cam-1.json"
            polygon = np.asarray([[10, 20], [90, 20], [90, 70], [10, 70]], dtype=np.int32)
            save_aoi_polygon(path, polygon, (100, 100, 3))
            np.testing.assert_array_equal(load_aoi_polygon(path, (100, 100, 3)), polygon)

    def test_non_four_point_file_is_treated_as_missing(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "aoi.json"
            path.write_text(json.dumps([[0.1, 0.1], [0.9, 0.1], [0.5, 0.9]]), encoding="utf-8")
            self.assertIsNone(load_aoi_polygon(path, (100, 100, 3)))
            self.assertIsNone(load_aoi_polygon(Path(directory) / "missing.json", (100, 100, 3)))

    def test_resolution_prefers_binding_then_camera_id_then_default(self):
        self.assertEqual(
            resolve_aoi_file("cam-2", {"aoi_file": "detector_config/custom.json"}),
            const.project_path("detector_config/custom.json"),
        )
        self.assertEqual(resolve_aoi_file("cam-2"), const.project_path("detector_config/aoi/cam-2.json"))
        self.assertEqual(resolve_aoi_file(), const.project_path(const.AOI_FILE))


if __name__ == "__main__":
    unittest.main()
