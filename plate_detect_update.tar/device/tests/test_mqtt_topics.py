import unittest
import json
import tempfile
from pathlib import Path
from types import SimpleNamespace

from plate_detector.mqtt import PlateMqttPublisher, camera_topics


class MqttTopicTest(unittest.TestCase):
    def test_pi_id_namespaces_duplicate_local_camera_ids(self):
        self.assertEqual(
            camera_topics("pi-02", "cam-1"),
            ("sushi/pi-02/events/cam-1", "sushi/pi-02/status/cam-1"),
        )

    def test_topic_wildcards_are_rejected(self):
        with self.assertRaises(ValueError):
            camera_topics("pi/+", "cam-1")

    def test_aoi_message_is_saved_for_the_current_camera(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            publisher = PlateMqttPublisher.__new__(PlateMqttPublisher)
            publisher.aoi_topic = "sushi/pi-01/config/cam-1/aoi"
            publisher.aoi_file = Path(temporary_directory) / "aoi" / "cam-1.json"
            publisher._aoi_updated = False
            points = [[0.1, 0.1], [0.1, 0.9], [0.9, 0.9], [0.9, 0.1]]
            publisher._handle_message(None, None, SimpleNamespace(
                topic=publisher.aoi_topic,
                payload=json.dumps({"points": points}).encode(),
            ))
            self.assertEqual(json.loads(publisher.aoi_file.read_text()), points)
            self.assertTrue(publisher.consume_aoi_updated())


if __name__ == "__main__":
    unittest.main()
