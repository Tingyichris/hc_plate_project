"""Persistent logical-camera bindings resolved from stable USB device paths."""

from __future__ import annotations

import json
import os
import re
import sys
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace

import cv2
from cv2_enumerate_cameras import enumerate_cameras

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG_FILE = PROJECT_ROOT / "detector_config" / "device_config.json"
LEGACY_BINDINGS_FILE = PROJECT_ROOT / "detector_config" / "camera_bindings.json"
# Compatibility name for callers that imported the old constant.
DEFAULT_BINDINGS_FILE = DEFAULT_CONFIG_FILE


def _default_config() -> dict:
    return {
        "schema_version": 4,
        "cameras": [],
    }


# Raspberry Pi SoC video nodes (ISP, codec, CSI receiver) show up in V4L2 enumeration
# but are not plate cameras; binding them would create bogus cam-N entries.
NON_CAMERA_NAME_PREFIXES = (
    "bcm2835-isp",
    "bcm2835-codec",
    "pispbe",
    "rpi-hevc",
    "rpivid",
    "rp1-cfe",
    "unicam",
)


def is_camera_device(device) -> bool:
    """False for platform video nodes that are never real cameras."""
    name = str(getattr(device, "name", "") or "").strip().casefold()
    return not name.startswith(NON_CAMERA_NAME_PREFIXES)


def enumerate_devices() -> list:
    return [device for device in _enumerate_all_devices() if is_camera_device(device)]


def _enumerate_all_devices() -> list:
    if sys.platform.startswith("win"):
        backend = cv2.CAP_DSHOW
    elif sys.platform.startswith("linux"):
        backend = cv2.CAP_V4L2
    elif sys.platform == "darwin":
        backend = cv2.CAP_AVFOUNDATION
    else:
        backend = cv2.CAP_ANY
    return list(enumerate_cameras(backend))


def _device_port_path(device) -> str:
    """Return a stable physical-port identity when Linux udev exposes one."""
    device_path = str(getattr(device, "path", "") or "").strip()
    if not device_path or not sys.platform.startswith("linux"):
        return device_path
    target = Path(device_path).resolve()
    by_path = Path("/dev/v4l/by-path")
    if by_path.is_dir():
        for link in sorted(by_path.iterdir(), key=lambda item: item.name):
            try:
                if link.resolve() == target:
                    return re.sub(r"-video-index\d+$", "", str(link))
            except OSError:
                continue
    return device_path


def auto_bind_devices(path: Path = DEFAULT_CONFIG_FILE, devices: Iterable | None = None) -> list[dict]:
    """Bind every newly discovered physical USB port to the next local cam-N ID."""
    available = [
        device
        for device in (list(devices) if devices is not None else enumerate_devices())
        if is_camera_device(device)
    ]
    grouped: dict[str, object] = {}
    for device in available:
        port_path = _device_port_path(device)
        if port_path:
            grouped.setdefault(_normalized_path(port_path), device)

    data = load_device_config(path)
    # Drop bindings an older version created for Raspberry Pi platform video nodes.
    bindings = [
        binding
        for binding in data["cameras"]
        if is_camera_device(SimpleNamespace(name=binding.get("device_name", "")))
    ]
    changed = len(bindings) != len(data["cameras"])

    # Migrate older Linux bindings that stored /dev/videoN to the stable udev
    # by-path identity while the old device node is still available.
    for binding in bindings:
        saved = _normalized_path(binding.get("device_path", ""))
        for device in available:
            raw = _normalized_path(getattr(device, "path", ""))
            if saved and saved == raw:
                stable = _device_port_path(device)
                if stable and stable != binding.get("device_path"):
                    binding["device_path"] = stable
                    changed = True
                break

    bound_paths = {
        _normalized_path(binding.get("device_path", "")) for binding in bindings
    }
    used_numbers = [
        int(match.group(1))
        for binding in bindings
        if (match := re.fullmatch(r"cam-(\d+)", str(binding.get("camera_id", ""))))
    ]
    next_number = max(used_numbers, default=0) + 1

    for normalized_port, device in sorted(grouped.items()):
        port_path = _device_port_path(device)
        if normalized_port in bound_paths:
            continue
        camera_id = f"cam-{next_number}"
        next_number += 1
        bindings.append({
            "camera_id": camera_id,
            "mqtt_camera_id": camera_id,
            "device_path": port_path,
            "device_name": str(getattr(device, "name", "") or ""),
            "vid": getattr(device, "vid", None),
            "pid": getattr(device, "pid", None),
            "handoff_role": "off",
            "peer_camera_id": "",
            "upstream_camera_id": "",
            "downstream_camera_id": "",
        })
        bound_paths.add(normalized_port)
        changed = True

    if changed:
        bindings.sort(key=lambda item: str(item.get("camera_id", "")))
        data["cameras"] = bindings
        save_device_config(data, path)
    return bindings


def _normalized_path(value: str) -> str:
    return str(value or "").strip().casefold()


def load_device_config(path: Path = DEFAULT_CONFIG_FILE) -> dict:
    if not path.is_file():
        if path == DEFAULT_CONFIG_FILE and LEGACY_BINDINGS_FILE.is_file():
            return load_device_config(LEGACY_BINDINGS_FILE)
        return _default_config()
    data = json.loads(path.read_text(encoding="utf-8"))
    # Read the former camera_bindings.json shape so existing installations can
    # migrate simply by running camera-bind once with the new code.
    if data.get("schema_version") == 1 and isinstance(data.get("bindings"), list):
        migrated = _default_config()
        migrated["cameras"] = data["bindings"]
        return migrated
    if data.get("schema_version") not in {2, 3, 4}:
        raise ValueError(f"Unsupported device config schema: {path}")
    if not isinstance(data.get("cameras"), list):
        raise ValueError(f"Invalid device config: {path}")
    merged = _default_config()
    merged["cameras"] = data["cameras"]
    return merged


def save_device_config(data: dict, path: Path = DEFAULT_CONFIG_FILE) -> None:
    output = _default_config()
    output["cameras"] = list(data.get("cameras", []))
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    try:
        temporary.write_text(
            json.dumps(output, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        temporary.replace(path)
    finally:
        if temporary.exists():
            temporary.unlink()


def load_bindings(path: Path = DEFAULT_CONFIG_FILE) -> dict:
    """Compatibility wrapper; new code should use load_device_config()."""
    return load_device_config(path)


def save_binding(
    camera_index: int,
    camera_id: str,
    mqtt_camera_id: str = "",
    handoff_role: str = "off",
    peer_camera_id: str = "",
    upstream_camera_id: str = "",
    downstream_camera_id: str = "",
    path: Path = DEFAULT_CONFIG_FILE,
    devices: Iterable | None = None,
) -> dict:
    available = list(devices) if devices is not None else enumerate_devices()
    device = next(
        (item for item in available if int(item.index) == int(camera_index)),
        None,
    )
    if device is None:
        raise LookupError(f"Camera index {camera_index} was not enumerated")
    device_path = _device_port_path(device)
    if not device_path:
        raise ValueError(
            f"Camera index {camera_index} has no stable USB path and cannot be bound"
        )
    logical_id = str(camera_id).strip()
    if not logical_id:
        raise ValueError("camera_id cannot be empty")
    if handoff_role not in {"off", "upstream", "downstream", "both"}:
        raise ValueError(f"Invalid handoff role: {handoff_role}")
    upstream_id = str(upstream_camera_id).strip()
    downstream_id = str(downstream_camera_id).strip()
    legacy_peer = str(peer_camera_id).strip()
    if not upstream_id and handoff_role == "downstream":
        upstream_id = legacy_peer
    if not downstream_id and handoff_role == "upstream":
        downstream_id = legacy_peer
    if upstream_id or downstream_id:
        handoff_role = "both" if upstream_id and downstream_id else (
            "downstream" if upstream_id else "upstream"
        )
    binding = {
        "camera_id": logical_id,
        "mqtt_camera_id": str(mqtt_camera_id).strip() or logical_id,
        "device_path": device_path,
        "device_name": str(getattr(device, "name", "") or ""),
        "vid": getattr(device, "vid", None),
        "pid": getattr(device, "pid", None),
        "handoff_role": handoff_role,
        "peer_camera_id": legacy_peer,
        "upstream_camera_id": upstream_id,
        "downstream_camera_id": downstream_id,
    }
    data = load_device_config(path)
    normalized = _normalized_path(device_path)
    data["cameras"] = [
        item
        for item in data["cameras"]
        if str(item.get("camera_id", "")) != logical_id
        and _normalized_path(item.get("device_path", "")) != normalized
    ]
    data["cameras"].append(binding)
    data["cameras"].sort(key=lambda item: str(item.get("camera_id", "")))
    save_device_config(data, path)
    return binding


def binding_for(camera_id: str, path: Path = DEFAULT_CONFIG_FILE) -> dict | None:
    logical_id = str(camera_id).strip()
    return next(
        (
            dict(item)
            for item in load_device_config(path)["cameras"]
            if str(item.get("camera_id", "")) == logical_id
        ),
        None,
    )


def binding_for_index(
    camera_index: int,
    path: Path = DEFAULT_CONFIG_FILE,
    devices: Iterable | None = None,
) -> dict | None:
    available = list(devices) if devices is not None else enumerate_devices()
    auto_bind_devices(path=path, devices=available)
    device = next(
        (item for item in available if int(item.index) == int(camera_index)),
        None,
    )
    if device is None:
        return None
    expected_path = _normalized_path(_device_port_path(device))
    return next(
        (
            dict(item)
            for item in load_device_config(path)["cameras"]
            if _normalized_path(item.get("device_path", "")) == expected_path
        ),
        None,
    )


def resolve_camera_index(
    camera_id: str,
    path: Path = DEFAULT_CONFIG_FILE,
    devices: Iterable | None = None,
) -> tuple[int, dict]:
    available = list(devices) if devices is not None else enumerate_devices()
    binding = binding_for(camera_id, path)
    if binding is None:
        auto_bind_devices(path=path, devices=available)
        binding = binding_for(camera_id, path)
    if binding is None:
        raise LookupError(
            f"No USB binding exists for {camera_id!r}. Run camera-bind first."
        )
    expected_path = _normalized_path(binding.get("device_path", ""))
    device = next(
        (
            item
            for item in available
            if _normalized_path(_device_port_path(item)) == expected_path
        ),
        None,
    )
    if device is None:
        visible = [
            f"{getattr(item, 'index', '?')}:{getattr(item, 'name', '?')}"
            for item in available
        ]
        raise LookupError(
            f"Bound USB camera {camera_id!r} is not connected at its saved path. "
            f"Visible cameras: {', '.join(visible) or 'none'}"
        )
    return int(device.index), binding


@dataclass
class CameraSelection:
    camera_index: int | None
    camera_id: str
    binding: dict | None
    mqtt_camera_id: str


def resolve_camera_selection(camera: int | None, camera_id: str = "", mqtt_camera_id: str = "") -> CameraSelection:
    """Combine ``--camera``/``--camera-id``/``--mqtt-camera-id`` with saved USB bindings."""
    camera_id = str(camera_id or "").strip()
    binding = None
    if camera_id:
        if camera is None:
            camera, binding = resolve_camera_index(camera_id)
            print(f"Resolved {camera_id} to current camera index {camera} via saved USB path.")
        else:
            binding = binding_for(camera_id)
    elif camera is not None:
        binding = binding_for_index(camera)
        if binding is not None:
            camera_id = str(binding["camera_id"])
    mqtt_camera_id = str(mqtt_camera_id or "").strip()
    if not mqtt_camera_id and binding is not None:
        mqtt_camera_id = str(binding.get("mqtt_camera_id", "")).strip()
    return CameraSelection(camera, camera_id, binding, mqtt_camera_id or camera_id)
