"""Four-point conveyor AOI: file resolution, persistence, drawing, and cropping.

The AOI file stores four normalized ``[x, y]`` points.  Files with any other
point count are treated as "no AOI" so that the distance self-check can always
build its four-point world transform from the same file the device uses.
"""

from __future__ import annotations

import json
from pathlib import Path

import cv2
import numpy as np

from . import constants as const

AOI_POINT_COUNT = 4


def resolve_aoi_file(camera_id: str = "", binding: dict | None = None) -> Path:
    """Return the AOI file for a logical camera, falling back to plate.toml's AOI file."""
    configured = str((binding or {}).get("aoi_file") or "").strip()
    if configured:
        return Path(const.project_path(configured))
    camera_id = str(camera_id or "").strip()
    if camera_id:
        return Path(const.project_path(f"detector_config/aoi/{camera_id}.json"))
    return Path(const.project_path(const.AOI_FILE))


def save_aoi_polygon(path, polygon, frame_shape) -> None:
    frame_height, frame_width = frame_shape[:2]
    normalized = [
        [float(point[0]) / float(frame_width), float(point[1]) / float(frame_height)]
        for point in np.asarray(polygon)
    ]
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(normalized, handle, indent=2)


def load_aoi_polygon(path, frame_shape):
    path = Path(path)
    if not path.exists():
        return None
    with path.open("r", encoding="utf-8") as handle:
        normalized = json.load(handle)
    if not isinstance(normalized, list):
        return None
    points = [point for point in normalized if isinstance(point, list) and len(point) >= 2]
    if len(points) != AOI_POINT_COUNT:
        return None
    frame_height, frame_width = frame_shape[:2]
    polygon = np.asarray(
        [
            [int(round(float(point[0]) * frame_width)), int(round(float(point[1]) * frame_height))]
            for point in points
        ],
        dtype=np.int32,
    )
    polygon[:, 0] = np.clip(polygon[:, 0], 0, frame_width - 1)
    polygon[:, 1] = np.clip(polygon[:, 1], 0, frame_height - 1)
    return polygon


def _draw_selection(frame, points):
    preview = frame.copy()
    for index, point in enumerate(points, start=1):
        cv2.circle(preview, point, 6, (0, 255, 255), -1)
        cv2.putText(
            preview, str(index), (point[0] + 8, point[1] - 8),
            cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 255), 2, cv2.LINE_AA,
        )
    if len(points) >= 2:
        cv2.polylines(
            preview, [np.asarray(points, dtype=np.int32)], len(points) == AOI_POINT_COUNT,
            (0, 255, 255), 2, cv2.LINE_AA,
        )
    cv2.putText(
        preview, "Left:add  Right:undo  Enter:save  Esc:cancel", (15, 30),
        cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 2, cv2.LINE_AA,
    )
    return preview


def select_aoi_polygon(frame, path):
    """Let the operator click exactly four points, then save them to ``path``."""
    points = []
    window_name = f"Draw Conveyor AOI (exactly {AOI_POINT_COUNT} points)"

    def mouse_callback(event, x, y, _flags, _param):
        if event == cv2.EVENT_LBUTTONDOWN and len(points) < AOI_POINT_COUNT:
            points.append((x, y))
        elif event == cv2.EVENT_RBUTTONDOWN and points:
            points.pop()

    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
    cv2.setMouseCallback(window_name, mouse_callback)
    while True:
        cv2.imshow(window_name, _draw_selection(frame, points))
        key = cv2.waitKey(20) & 0xFF
        if key in (10, 13) and len(points) == AOI_POINT_COUNT:
            break
        if key == 27:
            cv2.destroyWindow(window_name)
            raise RuntimeError("AOI selection was cancelled.")
    cv2.destroyWindow(window_name)
    polygon = np.asarray(points, dtype=np.int32)
    save_aoi_polygon(path, polygon, frame.shape)
    print("AOI saved:", path)
    return polygon


def load_or_select_aoi_polygon(frame, path):
    polygon = load_aoi_polygon(path, frame.shape)
    return polygon if polygon is not None else select_aoi_polygon(frame, path)


def full_frame_polygon(frame):
    frame_height, frame_width = frame.shape[:2]
    return np.asarray(
        [[0, 0], [frame_width - 1, 0], [frame_width - 1, frame_height - 1], [0, frame_height - 1]],
        dtype=np.int32,
    )


def crop_and_mask_aoi(frame, polygon):
    x, y, width, height = cv2.boundingRect(polygon)
    original_crop = frame[y:y + height, x:x + width].copy()
    if original_crop.size == 0:
        return None, None, 0, 0, None
    local_polygon = polygon - np.array([x, y], dtype=np.int32)
    mask = np.zeros((height, width), dtype=np.uint8)
    cv2.fillPoly(mask, [local_polygon], 255)
    masked_crop = cv2.bitwise_and(original_crop, original_crop, mask=mask)
    return original_crop, masked_crop, x, y, local_polygon
