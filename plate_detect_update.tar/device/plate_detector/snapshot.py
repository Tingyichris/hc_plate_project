"""Upload camera previews to the backend."""

from __future__ import annotations

import urllib.parse
import urllib.request

import cv2

from . import constants as const


def upload_camera_snapshot(frame):
    ok, encoded = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 82])
    if not ok:
        return
    source_id = f"{const.PI_ID}/{const.MQTT_CAMERA_ID}"
    url = (f"{const.BACKEND_URL}/api/ingest/camera-snapshot?source_id="
           f"{urllib.parse.quote(source_id, safe='')}")
    request = urllib.request.Request(
        url, data=encoded.tobytes(), method="POST",
        headers={"Content-Type": "image/jpeg",
                 "Authorization": f"Bearer {const.BACKEND_SERVICE_TOKEN}"},
    )
    try:
        with urllib.request.urlopen(request, timeout=5):
            pass
    except OSError as exc:
        print(f"Snapshot upload failed: {exc}")
