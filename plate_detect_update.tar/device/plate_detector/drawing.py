"""Live detector overlays."""

from __future__ import annotations

import cv2
import numpy as np

from .color import color_bgr
from .geometry import interpolate_aoi_cross_section, project_box_to_frame
from .settings import (
    COUNTING_LINE_RATIO,
    ENTRY_LINE_RATIO,
    EXIT_LINE_RATIO,
)


def draw_aoi_overlay(frame, polygon):
    overlay = frame.copy()

    cv2.fillPoly(
        overlay,
        [polygon],
        (40, 150, 70),
    )

    cv2.addWeighted(
        overlay,
        0.16,
        frame,
        0.84,
        0,
        frame,
    )


def draw_tracking_guides(frame, aoi_polygon):
    guides = [
        ("ENTRY", ENTRY_LINE_RATIO, (255, 210, 60)),
        ("COUNT", COUNTING_LINE_RATIO, (0, 255, 255)),
        ("EXIT", EXIT_LINE_RATIO, (80, 100, 255)),
    ]

    cv2.polylines(
        frame,
        [np.asarray(aoi_polygon, dtype=np.int32)],
        True,
        (80, 230, 100),
        2,
        cv2.LINE_AA,
    )

    for label, ratio, color in guides:
        line = interpolate_aoi_cross_section(aoi_polygon, ratio)
        cv2.line(
            frame,
            tuple(line[0]),
            tuple(line[1]),
            color,
            2,
            cv2.LINE_AA,
        )
        label_x = int((line[0, 0] + line[1, 0]) / 2)
        label_y = int((line[0, 1] + line[1, 1]) / 2)
        cv2.putText(
            frame,
            label,
            (label_x + 6, label_y - 6),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.48,
            color,
            1,
            cv2.LINE_AA,
        )


def draw_summary_panel(
    frame,
    tracked_instances,
    inference_ms,
    preprocess_mode,
    warp_active,
    use_aoi,
    recorder_lines=None,
):
    visible_instances = [
        instance
        for instance in tracked_instances
        if not instance.get("ignore_after_exit")
    ]

    header_lines = [
        (
            f"plates={len(visible_instances)} | "
            f"inference={inference_ms:.0f} ms | "
            f"mode={preprocess_mode} | "
            f"warp={'on' if warp_active else 'off'} | "
            f"aoi={'on' if use_aoi else 'full'}"
        ),
        "Q=quit B=next batch A=AOI R=redraw W=warp S=save",
    ]
    header_lines.extend(recorder_lines or [])

    plate_items = []
    for instance in visible_instances[:8]:
        plate_id = instance.get("persistent_plate_id")
        tracker_id = instance["tracker_id"]
        identity = (
            f"P{plate_id}/T{tracker_id}"
            if plate_id is not None
            else f"T{tracker_id}"
        )
        expected = instance.get("expected_color") or "-"
        plate_items.append(
            (
                f"{identity} GT={expected}:",
                color_bgr(instance["stable_color"]),
            )
        )

    footer_lines = []
    if len(visible_instances) > 8:
        footer_lines.append(
            f"... {len(visible_instances) - 8} more"
        )

    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = 0.48
    thickness = 1
    padding = 10
    line_gap = 8
    circle_radius = 7
    circle_gap = 10

    text_lines = header_lines + footer_lines
    text_sizes = [
        cv2.getTextSize(line, font, font_scale, thickness)[0]
        for line in text_lines
    ]
    item_text_sizes = [
        cv2.getTextSize(prefix, font, font_scale, thickness)[0]
        for prefix, _color in plate_items
    ]

    max_text_width = max(
        [width for width, _height in text_sizes] + [0]
    )
    max_item_width = max(
        [
            width + circle_gap + circle_radius * 2
            for width, _height in item_text_sizes
        ] + [0]
    )
    max_text_height = max(
        [height for _width, height in text_sizes + item_text_sizes] + [0]
    )
    panel_width = max(max_text_width, max_item_width) + padding * 2
    line_height = max(max_text_height, circle_radius * 2)
    line_count = len(header_lines) + len(plate_items) + len(footer_lines)
    panel_height = (
        line_count * line_height
        + max(0, line_count - 1) * line_gap
        + padding * 2
    )

    x1 = 12
    y2 = frame.shape[0] - 12
    y1 = max(12, y2 - panel_height)
    x2 = min(frame.shape[1] - 1, x1 + panel_width)

    overlay = frame.copy()
    cv2.rectangle(
        overlay,
        (x1, y1),
        (x2, y2),
        (20, 20, 20),
        -1,
    )
    cv2.addWeighted(
        overlay,
        0.72,
        frame,
        0.28,
        0,
        frame,
    )
    cv2.rectangle(
        frame,
        (x1, y1),
        (x2, y2),
        (255, 255, 255),
        1,
    )

    y = y1 + padding + line_height

    for line in header_lines:
        cv2.putText(
            frame,
            line,
            (x1 + padding, y),
            font,
            font_scale,
            (255, 255, 255),
            thickness,
            cv2.LINE_AA,
        )
        y += line_height + line_gap

    for prefix, circle_color in plate_items:
        cv2.putText(
            frame,
            prefix,
            (x1 + padding, y),
            font,
            font_scale,
            (255, 255, 255),
            thickness,
            cv2.LINE_AA,
        )
        prefix_size = cv2.getTextSize(
            prefix,
            font,
            font_scale,
            thickness,
        )[0]
        circle_x = x1 + padding + prefix_size[0] + circle_gap + circle_radius
        circle_y = y - line_height // 2 + 2
        cv2.circle(
            frame,
            (circle_x, circle_y),
            circle_radius,
            circle_color,
            -1,
            cv2.LINE_AA,
        )
        cv2.circle(
            frame,
            (circle_x, circle_y),
            circle_radius,
            (255, 255, 255),
            1,
            cv2.LINE_AA,
        )
        y += line_height + line_gap

    for line in footer_lines:
        cv2.putText(
            frame,
            line,
            (x1 + padding, y),
            font,
            font_scale,
            (255, 255, 255),
            thickness,
            cv2.LINE_AA,
        )
        y += line_height + line_gap


def draw_tracked_instances(
    frame,
    tracked_instances,
    aoi_x,
    aoi_y,
    aoi_polygon,
    inverse_matrix=None,
):
    # Keep segmentation polygons internally for color classification and
    # tracking, but present detections as simple rectangular bounding boxes.
    for instance in tracked_instances:
        if instance.get("ignore_after_exit"):
            continue
        stable_color = instance["stable_color"]

        color = color_bgr(stable_color)
        box_x1, box_y1, box_x2, box_y2 = project_box_to_frame(
            instance["xyxy"],
            aoi_x,
            aoi_y,
            frame.shape,
            inverse_matrix,
        )

        cv2.rectangle(
            frame,
            (box_x1, box_y1),
            (box_x2, box_y2),
            color,
            2,
            cv2.LINE_AA,
        )

        label_x = box_x1
        label_y = box_y1

        plate_id = instance.get("persistent_plate_id")
        tracker_id = instance["tracker_id"]
        label = (
            f"P{plate_id}/T{tracker_id}"
            if plate_id is not None
            else f"T{tracker_id}"
        )
        expected = instance.get("expected_color")
        if expected:
            label += f" GT={expected}"

        cv2.putText(
            frame,
            label,
            (label_x, max(22, label_y - 8)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.48,
            color,
            2,
            cv2.LINE_AA,
        )
