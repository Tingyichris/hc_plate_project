"""Create and inspect persistent USB-port camera bindings."""

from __future__ import annotations

import argparse

from plate_detector.camera_registry import (
    auto_bind_devices,
    enumerate_devices,
    load_device_config,
    resolve_camera_index,
    save_binding,
)
from plate_detector.constants import PI_ID


def bind_main() -> None:
    parser = argparse.ArgumentParser(description="Bind a logical ID to a USB camera path")
    parser.add_argument("--camera", type=int, required=True, help="current camera index")
    parser.add_argument("--camera-id", required=True, help="stable logical ID")
    parser.add_argument("--mqtt-camera-id", default="", help="MQTT ID; defaults to camera-id")
    parser.add_argument(
        "--handoff-role", choices=("off", "upstream", "downstream", "both"),
        default="off", help="legacy compatibility; neighbor IDs are preferred"
    )
    parser.add_argument("--peer-camera-id", default="")
    parser.add_argument("--upstream-camera-id", default="")
    parser.add_argument("--downstream-camera-id", default="")
    args = parser.parse_args()
    binding = save_binding(
        camera_index=args.camera,
        camera_id=args.camera_id,
        mqtt_camera_id=args.mqtt_camera_id,
        handoff_role=args.handoff_role,
        peer_camera_id=args.peer_camera_id,
        upstream_camera_id=args.upstream_camera_id,
        downstream_camera_id=args.downstream_camera_id,
    )
    print("Camera binding saved:")
    for key, value in binding.items():
        print(f"  {key}: {value}")


def list_main() -> None:
    parser = argparse.ArgumentParser(description="List saved and currently resolved cameras")
    parser.parse_args()
    devices = enumerate_devices()
    before = {item["camera_id"] for item in load_device_config()["cameras"]}
    auto_bind_devices(devices=devices)
    data = load_device_config()
    created = [item["camera_id"] for item in data["cameras"] if item["camera_id"] not in before]
    if created:
        print(f"Automatically bound: {', '.join(created)}")
    print(f"Raspberry Pi ID: {PI_ID}")
    if not data["cameras"]:
        print("No USB cameras were detected, so no automatic bindings were created.")
        return
    for binding in data["cameras"]:
        camera_id = str(binding["camera_id"])
        try:
            index, _resolved = resolve_camera_index(camera_id, devices=devices)
            status = f"connected as index {index}"
        except LookupError as error:
            status = f"unavailable ({error})"
        print(
            f"{camera_id}: {status}; mqtt={binding.get('mqtt_camera_id', camera_id)}; "
            f"upstream={binding.get('upstream_camera_id', '') or '-'}; "
            f"downstream={binding.get('downstream_camera_id', '') or '-'}; "
            f"device={binding.get('device_name', '')}"
        )
