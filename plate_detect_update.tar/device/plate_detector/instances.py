"""Turn model predictions into filtered, tracked, color-labelled plate instances."""

from __future__ import annotations

from collections import defaultdict, deque

import cv2
import numpy as np

from . import supervision as sv
from .color import classify_plate_hls, stable_color_from_history
from .geometry import box_iou, polygon_mask
from .inference import predictions_to_detections
from .settings import (
    COLOR_HISTORY_LENGTH,
    EXCLUDED_PLATE_COLORS,
    OVERLAP_IOU_THRESHOLD,
    OVERLAP_SMALLER_AREA_THRESHOLD,
    TRACK_ACTIVATION_THRESHOLD,
    TRACK_LOST_BUFFER,
    TRACK_MINIMUM_CONSECUTIVE_FRAMES,
    TRACK_MINIMUM_MATCHING_THRESHOLD,
)


def assign_display_order(instances):
    ordered = sorted(
        instances,
        key=lambda item: (
            item.get("track_order_y", 0.0),
            item.get("track_order_x", 0.0),
            -item.get("confidence", 0.0),
        ),
    )

    for display_order, instance in enumerate(ordered, start=1):
        instance["display_order"] = display_order

    return ordered


def filter_overlapping_instances(instances, image_shape):
    if not instances:
        return []

    candidates = []

    for instance in instances:
        mask = polygon_mask(
            image_shape,
            instance["polygon"],
        )

        area = int(cv2.countNonZero(mask))

        if area <= 0:
            continue

        candidate = dict(instance)
        candidate["area"] = area
        x1, y1, x2, y2 = candidate["xyxy"]
        candidate["track_order_x"] = float(x1 + x2) / 2.0
        candidate["track_order_y"] = float(y1 + y2) / 2.0
        candidate["_mask"] = mask
        candidates.append(candidate)

    candidates.sort(
        key=lambda item: (
            item["confidence"],
            item["area"],
        ),
        reverse=True,
    )

    kept = []

    for candidate in candidates:
        should_keep = True

        for kept_instance in kept:
            intersection = cv2.bitwise_and(
                candidate["_mask"],
                kept_instance["_mask"],
            )

            intersection_area = int(
                cv2.countNonZero(intersection)
            )

            smaller_area = max(
                1,
                min(
                    candidate["area"],
                    kept_instance["area"],
                ),
            )

            overlap_ratio = (
                intersection_area / float(smaller_area)
            )

            iou_ratio = box_iou(
                candidate["xyxy"],
                kept_instance["xyxy"],
            )

            if (
                overlap_ratio >= OVERLAP_SMALLER_AREA_THRESHOLD
                or iou_ratio >= OVERLAP_IOU_THRESHOLD
            ):
                should_keep = False
                break

        if should_keep:
            kept.append(candidate)

    for instance in kept:
        instance.pop("_mask", None)

    return assign_display_order(kept)


def process_predictions(
    result,
    original_aoi,
    tracker,
    color_history,
):
    aoi_height, aoi_width = original_aoi.shape[:2]

    detections, polygons = predictions_to_detections(
        result=result,
        aoi_width=aoi_width,
        aoi_height=aoi_height,
    )

    tracked_detections = tracker.update_with_detections(
        detections
    )

    tracked_instances = []

    if len(tracked_detections) == 0:
        return tracked_instances

    source_indices = tracked_detections.data.get(
        "source_index",
        np.empty((0,), dtype=np.int32),
    )

    for index in range(len(tracked_detections)):
        if index >= len(source_indices):
            continue

        source_index = int(source_indices[index])

        if source_index < 0 or source_index >= len(polygons):
            continue

        polygon = polygons[source_index]

        tracker_id = int(
            tracked_detections.tracker_id[index]
        )

        confidence = float(
            tracked_detections.confidence[index]
        )

        # Final application-side gate before an object can be displayed,
        # recorded, or assigned a permanent plate ID.
        if confidence + 1e-6 < TRACK_ACTIVATION_THRESHOLD:
            continue

        xyxy = tracked_detections.xyxy[index].copy()

        current_color, ratios, ring_mask = classify_plate_hls(
            original_aoi,
            polygon,
        )

        color_history[tracker_id].append(
            current_color
        )

        stable_color = stable_color_from_history(
            color_history[tracker_id]
        )

        if stable_color.lower() in EXCLUDED_PLATE_COLORS:
            continue

        tracked_instances.append(
            {
                "tracker_id": tracker_id,
                "confidence": confidence,
                "xyxy": xyxy,
                "polygon": polygon,
                "current_color": current_color,
                "stable_color": stable_color,
                "ratios": ratios,
                "ring_mask": ring_mask,
            }
        )

    return filter_overlapping_instances(
        tracked_instances,
        original_aoi.shape,
    )


def create_tracker(frame_rate, activation_threshold=TRACK_ACTIVATION_THRESHOLD):
    return sv.ByteTrack(
        track_activation_threshold=activation_threshold,
        lost_track_buffer=TRACK_LOST_BUFFER,
        minimum_matching_threshold=TRACK_MINIMUM_MATCHING_THRESHOLD,
        frame_rate=max(1.0, float(frame_rate)),
        minimum_consecutive_frames=TRACK_MINIMUM_CONSECUTIVE_FRAMES,
    )


def create_color_history():
    return defaultdict(lambda: deque(maxlen=COLOR_HISTORY_LENGTH))
