"""Detector tuning values derived from detector_config/plate.toml (see constants.py)."""

from . import constants as const


API_URL = str(const.INFERENCE_URL)

# YOLO26 Nano Instance Segmentation
MODEL_ID = str(const.INFERENCE_MODEL_ID).strip()

TARGET_CLASS = str(const.INFERENCE_TARGET_CLASS).strip()

CAMERA_INDEX = int(const.CAMERA_INDEX)
VIDEO_SOURCE = str(const.CAMERA_SOURCE).strip() or None
USE_AOI_DEFAULT = bool(const.AOI_ENABLED)
CAMERA_WIDTH = int(const.CAMERA_WIDTH)
CAMERA_HEIGHT = int(const.CAMERA_HEIGHT)
CAMERA_FPS = int(const.CAMERA_FPS)


# Model and new-track confidence threshold.
CONFIDENCE = 0.35
IOU_THRESHOLD = 0.50

# Run segmentation every N camera frames.
# Run inference on every camera frame. The effective display rate is still
# limited by camera capture and model response time.
PROCESS_EVERY_N_FRAMES = 1


PREPROCESS_MODE = "clean_contrast"

DEFAULT_WARP_ENABLED = bool(const.AOI_WARP_ENABLED)
MIN_WARP_SIDE = 80
# 0 keeps the photographed trapezoid, 1 produces a fully rectangular
# bird's-eye view.  A partial correction enlarges distant plates without the
# severe blur caused by stretching a very narrow far edge to the full width.
WARP_STRENGTH = float(const.AOI_WARP_STRENGTH)

# ByteTrack
TRACK_ACTIVATION_THRESHOLD = 0.35
TRACK_LOST_BUFFER = 30
TRACK_MINIMUM_CONSECUTIVE_FRAMES = 1
# Moving conveyor plates rarely keep 80% bbox overlap between inferences.
# A 40% threshold preserves IDs while still requiring meaningful overlap.
TRACK_MINIMUM_MATCHING_THRESHOLD = 0.40

# HLS
MIN_COLOR_PIXELS = 20
MIN_COLOR_SATURATION = 25
MIN_COLOR_LIGHTNESS = 20
MAX_COLOR_LIGHTNESS = 245
MIN_CHROMATIC_COVERAGE = 0.18
MIN_ACHROMATIC_RATIO = 0.35
BLACK_LIGHTNESS_MAX = 65
WHITE_LIGHTNESS_MIN = 170
WHITE_SATURATION_MAX = 55
GRAY_LIGHTNESS_MIN = 66
GRAY_LIGHTNESS_MAX = 169
GRAY_SATURATION_MAX = 50
LAB_MAX_DISTANCE = 58.0
MIN_LAB_COLOR_SCORE = 0.12
COLOR_CLASSIFICATION_CLAHE_CLIP = 2.0
COLOR_CLASSIFICATION_CLAHE_TILE = (8, 8)
COLOR_CLASSIFICATION_SATURATION_GAIN = 1.35
LAB_COLOR_CENTERS = {
    # Calibrated from A-preprocessed production-camera anomaly captures.
    "orange": (185.0, 182.0),
    "yellow": (139.0, 190.0),
    "light_green": (118.0, 156.0),
}
HLS_HUE_RANGES = {
    "orange": [(0, 12)],
    "yellow": [(15, 26)],
    "light_green": [(28, 38)],
}
COLOR_NAMES = [
    "red",
    "orange",
    "yellow",
    "green",
    "light_green",
    "white",
    "gray",
    "black",
    "unknown",
]

# Detection input enhancement. The model and post-detection color filtering
# both use this adjusted image so reflection suppression is consistent through
# the whole pipeline. The display still uses the unmodified camera image.
# The tone curve and saturation gain are calibrated against the root reference
# image so the conveyor stays dark while plates remain vivid.
CLEAN_CONTRAST_BRIGHTNESS = -45.0
CLEAN_CONTRAST_CONTRAST = 45.0

# Colors that cannot represent a real plate in this installation. Detections
# with one of these stable colors are removed before display, counting, and
# accuracy recording. Override with a comma-separated environment variable;
# use "none" to keep every color.
EXCLUDED_PLATE_COLORS = {
    str(color).strip().lower()
    for color in const.DETECTION_EXCLUDED_COLORS
    if str(color).strip() and str(color).strip().lower() != "none"
}

# How many color results are used for temporal voting.
COLOR_HISTORY_LENGTH = 7

# Approximate plate-edge thickness.
# Larger value analyzes a thicker portion of the plate.
RING_EROSION_RATIO = 0.18


# The conveyor moves from the lower part of the image toward the upper part.
# Ratios are measured from the AOI's upper edge toward its lower edge, so the
# entrance has the larger ratio. Filled masks appear from COUNT to EXIT.
ENTRY_LINE_RATIO = 0.85
COUNTING_LINE_RATIO = 0.55
EXIT_LINE_RATIO = 0.05

# Drop duplicate detections when masks/boxes overlap too much.
OVERLAP_SMALLER_AREA_THRESHOLD = 0.45
OVERLAP_IOU_THRESHOLD = 0.35
