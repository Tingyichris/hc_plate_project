"""Generate a stable device identity without per-device configuration."""

from __future__ import annotations

import hashlib
import uuid
from pathlib import Path


def _machine_id() -> str:
    for path in (Path("/etc/machine-id"), Path("/var/lib/dbus/machine-id")):
        try:
            value = path.read_text(encoding="utf-8").strip()
        except OSError:
            continue
        if value:
            return value
    return ""


def automatic_pi_id() -> str:
    """Return a reproducible ID unique to the OS installation and hardware."""
    material = f"{_machine_id()}:{uuid.getnode():012x}"
    digest = hashlib.sha256(material.encode("utf-8")).hexdigest()[:12]
    return f"pi-{digest}"
