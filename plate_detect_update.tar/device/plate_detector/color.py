"""Plate color classification from the plate rim."""

from __future__ import annotations

from collections import Counter

import cv2
import numpy as np

from .settings import (
    BLACK_LIGHTNESS_MAX,
    COLOR_CLASSIFICATION_CLAHE_CLIP,
    COLOR_CLASSIFICATION_CLAHE_TILE,
    COLOR_CLASSIFICATION_SATURATION_GAIN,
    COLOR_NAMES,
    GRAY_LIGHTNESS_MAX,
    GRAY_LIGHTNESS_MIN,
    GRAY_SATURATION_MAX,
    HLS_HUE_RANGES,
    LAB_COLOR_CENTERS,
    LAB_MAX_DISTANCE,
    MAX_COLOR_LIGHTNESS,
    MIN_ACHROMATIC_RATIO,
    MIN_COLOR_LIGHTNESS,
    MIN_COLOR_PIXELS,
    MIN_COLOR_SATURATION,
    MIN_LAB_COLOR_SCORE,
    RING_EROSION_RATIO,
    WHITE_LIGHTNESS_MIN,
    WHITE_SATURATION_MAX,
)


def create_plate_ring_mask(image_shape, polygon):
    """
    原始 polygon 用來顯示模型結果。

    HLS 盤緣則使用 polygon 的 convex hull 建立較平滑的外框，
    最後與原始 segmentation mask 交集，只保留模型認為是盤子的像素。
    """
    image_height, image_width = image_shape[:2]

    # 原始 segmentation mask
    segmentation_mask = np.zeros(
        (image_height, image_width),
        dtype=np.uint8,
    )

    cv2.fillPoly(
        segmentation_mask,
        [polygon],
        255,
    )

    # 盤子近似凸形，填補被盤上物體造成的內凹輪廓
    hull = cv2.convexHull(polygon)

    hull_mask = np.zeros(
        (image_height, image_width),
        dtype=np.uint8,
    )

    cv2.fillPoly(
        hull_mask,
        [hull],
        255,
    )

    _, _, width, height = cv2.boundingRect(hull)

    plate_size = max(1, min(width, height))

    erosion_pixels = max(
        2,
        int(round(plate_size * RING_EROSION_RATIO)),
    )

    kernel_size = max(
        3,
        erosion_pixels * 2 + 1,
    )

    kernel = cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE,
        (kernel_size, kernel_size),
    )

    eroded_hull = cv2.erode(
        hull_mask,
        kernel,
        iterations=1,
    )

    # 凸包的外側環形區域
    geometric_ring = cv2.subtract(
        hull_mask,
        eroded_hull,
    )

    # 只取模型認為屬於盤子的可見像素，
    # 避免凸包補出的遮擋區域影響 HLS。
    ring_mask = cv2.bitwise_and(
        geometric_ring,
        segmentation_mask,
    )

    return segmentation_mask, ring_mask


def enhance_for_color_classification(image, mask):
    mask_pixels = mask > 0

    if not np.any(mask_pixels):
        return image

    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
    l_channel, a_channel, b_channel = cv2.split(lab)
    clahe = cv2.createCLAHE(
        clipLimit=COLOR_CLASSIFICATION_CLAHE_CLIP,
        tileGridSize=COLOR_CLASSIFICATION_CLAHE_TILE,
    )
    enhanced_l = clahe.apply(l_channel)
    enhanced_lab = cv2.merge((enhanced_l, a_channel, b_channel))
    enhanced_bgr = cv2.cvtColor(enhanced_lab, cv2.COLOR_LAB2BGR)

    classification_image = image.copy()
    classification_image[mask_pixels] = enhanced_bgr[mask_pixels]

    hls = cv2.cvtColor(classification_image, cv2.COLOR_BGR2HLS)
    saturation = hls[:, :, 2].astype(np.float32)
    saturation[mask_pixels] = np.clip(
        saturation[mask_pixels] * COLOR_CLASSIFICATION_SATURATION_GAIN,
        0,
        255,
    )
    hls[:, :, 2] = saturation.astype(np.uint8)
    boosted_bgr = cv2.cvtColor(hls, cv2.COLOR_HLS2BGR)
    classification_image[mask_pixels] = boosted_bgr[mask_pixels]

    return classification_image


def select_color_sample_mask(segmentation_mask, ring_mask):
    ring_pixels = ring_mask > 0

    if int(np.count_nonzero(ring_pixels)) >= MIN_COLOR_PIXELS:
        return ring_pixels

    return segmentation_mask > 0


def score_lab_color_votes(lab_image, color_pixels):
    lab_scores = {
        color_name: 0.0
        for color_name in LAB_COLOR_CENTERS
    }

    color_count = int(np.count_nonzero(color_pixels))

    if color_count < MIN_COLOR_PIXELS:
        return lab_scores

    a_values = lab_image[:, :, 1][color_pixels].astype(np.float32)
    b_values = lab_image[:, :, 2][color_pixels].astype(np.float32)

    color_names = list(LAB_COLOR_CENTERS)
    distances = np.stack(
        [
            np.hypot(a_values - center_a, b_values - center_b)
            for center_a, center_b in LAB_COLOR_CENTERS.values()
        ],
        axis=1,
    )
    nearest = np.argmin(distances, axis=1)
    nearest_distances = distances[
        np.arange(color_count),
        nearest,
    ]
    confident_votes = nearest_distances <= (
        LAB_MAX_DISTANCE * (1.0 - MIN_LAB_COLOR_SCORE)
    )

    if not np.any(confident_votes):
        return lab_scores

    for color_index, color_name in enumerate(color_names):
        lab_scores[color_name] = float(
            np.count_nonzero(
                confident_votes & (nearest == color_index)
            )
        ) / color_count

    return lab_scores


def score_hls_hue_votes(hls_image, color_pixels):
    hue_scores = {
        color_name: 0.0
        for color_name in LAB_COLOR_CENTERS
    }
    color_count = int(np.count_nonzero(color_pixels))

    if color_count < MIN_COLOR_PIXELS:
        return hue_scores

    hue = hls_image[:, :, 0]

    for color_name, ranges in HLS_HUE_RANGES.items():
        color_match = np.zeros(hue.shape, dtype=bool)

        for hue_min, hue_max in ranges:
            color_match |= (
                (hue >= hue_min)
                & (hue <= hue_max)
            )

        hue_scores[color_name] = float(
            np.count_nonzero(color_pixels & color_match)
        ) / color_count

    return hue_scores


def combine_chromatic_scores(lab_scores, hue_scores):
    return {
        color_name: (
            0.25 * lab_scores[color_name]
            + 0.75 * hue_scores[color_name]
        )
        for color_name in LAB_COLOR_CENTERS
    }


def classify_plate_hls(aoi_image, polygon):
    """
    OpenCV HLS ranges:
      H: 0..180
      L: 0..255
      S: 0..255

    These ranges are initial calibration values and should be adjusted
    using images from the production camera.
    """
    segmentation_mask, ring_mask = create_plate_ring_mask(
        aoi_image.shape,
        polygon,
    )

    original_hls = cv2.cvtColor(
        aoi_image,
        cv2.COLOR_BGR2HLS,
    )
    original_lightness = original_hls[:, :, 1]
    original_saturation = original_hls[:, :, 2]

    classification_image = enhance_for_color_classification(
        aoi_image,
        segmentation_mask,
    )

    hls = cv2.cvtColor(classification_image, cv2.COLOR_BGR2HLS)

    sample_pixels = select_color_sample_mask(
        segmentation_mask,
        ring_mask,
    )
    sample_count = int(np.count_nonzero(sample_pixels))

    if sample_count < MIN_COLOR_PIXELS:
        return "unknown", {
            color_name: 0.0
            for color_name in COLOR_NAMES
            if color_name != "unknown"
        }, ring_mask

    black_pixels = sample_pixels & (original_lightness <= BLACK_LIGHTNESS_MAX)
    white_pixels = (
        sample_pixels
        & (original_lightness >= WHITE_LIGHTNESS_MIN)
        & (original_saturation <= WHITE_SATURATION_MAX)
    )
    gray_pixels = (
        sample_pixels
        & (original_lightness >= GRAY_LIGHTNESS_MIN)
        & (original_lightness <= GRAY_LIGHTNESS_MAX)
        & (original_saturation <= GRAY_SATURATION_MAX)
    )

    usable_lightness = (
        (original_lightness >= MIN_COLOR_LIGHTNESS)
        & (original_lightness <= MAX_COLOR_LIGHTNESS)
    )
    color_pixels = (
        sample_pixels
        & usable_lightness
        & (original_saturation >= MIN_COLOR_SATURATION)
    )
    color_count = int(np.count_nonzero(color_pixels))
    chromatic_coverage = float(color_count) / sample_count

    lab = cv2.cvtColor(classification_image, cv2.COLOR_BGR2LAB)
    lab_scores = score_lab_color_votes(lab, color_pixels)
    hue_scores = score_hls_hue_votes(original_hls, color_pixels)
    chromatic_scores = combine_chromatic_scores(
        lab_scores,
        hue_scores,
    )

    ratios = {
        **chromatic_scores,
        "white": float(np.count_nonzero(white_pixels)) / sample_count,
        "gray": float(np.count_nonzero(gray_pixels)) / sample_count,
        "black": float(np.count_nonzero(black_pixels)) / sample_count,
    }

    candidate_thresholds = {
        color_name: MIN_LAB_COLOR_SCORE
        for color_name in chromatic_scores
    }
    candidate_thresholds.update(
        {
            "black": MIN_ACHROMATIC_RATIO,
            "white": MIN_ACHROMATIC_RATIO,
            "gray": MIN_ACHROMATIC_RATIO,
        }
    )
    best_color = max(
        candidate_thresholds,
        key=lambda color_name: ratios.get(color_name, 0.0),
    )

    if ratios.get(best_color, 0.0) < candidate_thresholds[best_color]:
        best_color = "unknown"

    return best_color, ratios, ring_mask


def stable_color_from_history(history):
    known_colors = [
        color
        for color in history
        if color != "unknown"
    ]

    if not known_colors:
        return "unknown"

    counts = Counter(known_colors)
    return counts.most_common(1)[0][0]


def color_bgr(color_name):
    return {
        "red": (0, 0, 255),
        "orange": (0, 140, 255),
        "yellow": (0, 255, 255),
        "green": (0, 220, 0),
        "light_green": (120, 255, 120),
        "white": (245, 245, 245),
        "gray": (150, 150, 150),
        "black": (35, 35, 35),
        "unknown": (0, 255, 255),
    }.get(color_name, (0, 255, 255))
