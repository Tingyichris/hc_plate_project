"""Persistent plate identity and ENTRY/COUNT/EXIT stage tracking for live detection.

ByteTrack IDs can change when a plate is briefly lost.  This tracker reconnects
such IDs to one persistent plate ID and annotates each instance with
``persistent_plate_id`` and ``tracking_stage``, which the MQTT publisher needs.
Validation recorders subclass it and use the ``_on_*`` hooks to log evidence.
"""

from __future__ import annotations

import math
import time
from dataclasses import dataclass, field

ENTRY_LINE_RATIO = 0.85
COUNTING_LINE_RATIO = 0.55
EXIT_LINE_RATIO = 0.15
RECONNECT_BOX_SCORE_MAX = 1.5


@dataclass
class PlateState:
    plate_id: int
    tracker_ids: set[int] = field(default_factory=set)
    first_seen: float = 0.0
    last_seen: float = 0.0
    last_box: tuple[float, float, float, float] | None = None
    last_color: str = "unknown"
    observations: int = 0
    disappearances: int = 0
    reappearances: int = 0
    color_switches: int = 0
    last_progress: float | None = None
    stage: str = "approaching"
    entry_time: float | None = None
    entry_color: str = ""
    count_time: float | None = None
    count_color: str = ""
    exit_time: float | None = None
    exit_color: str = ""
    exit_candidate: bool = False
    caught_time: float | None = None

    @property
    def finished(self) -> bool:
        return self.exit_time is not None or self.caught_time is not None


def box_center(box):
    return ((box[0] + box[2]) / 2.0, (box[1] + box[3]) / 2.0)


def box_match_score(first, second) -> float:
    ax, ay = box_center(first)
    bx, by = box_center(second)
    scale = max(20.0, math.hypot(second[2] - second[0], second[3] - second[1]))
    return math.hypot(ax - bx, ay - by) / scale


def line_crossed(previous, current, threshold) -> bool:
    if previous is None:
        return current <= threshold
    return previous > threshold >= current


class PlateIdentityTracker:
    """Assign persistent plate IDs and lifecycle stages to tracked instances."""

    state_class = PlateState

    def __init__(self, reconnect_seconds: float = 2.0):
        self.started = time.perf_counter()
        self.reconnect_seconds = reconnect_seconds
        self.inference_index = 0
        self.next_plate_id = 1
        self.states: dict[int, PlateState] = {}
        self.tracker_to_plate: dict[int, int] = {}
        self.visible_last: set[int] = set()
        self.frame_shape = None

    def _now(self) -> float:
        return time.perf_counter() - self.started

    def _plate_for(self, tracker_id, box, now):
        if tracker_id in self.tracker_to_plate:
            return self.tracker_to_plate[tracker_id], False
        candidates = []
        for plate_id, state in self.states.items():
            # EXIT is terminal: a detection above it must never revive a finished plate.
            if state.finished:
                continue
            gap = now - state.last_seen
            if state.last_box is None or gap <= 0 or gap > self.reconnect_seconds:
                continue
            score = box_match_score(box, state.last_box)
            if score <= RECONNECT_BOX_SCORE_MAX:
                candidates.append((score, plate_id))
        if candidates:
            plate_id = min(candidates)[1]
            self.states[plate_id].reappearances += 1
            return self._bind(tracker_id, plate_id), True
        plate_id = self.next_plate_id
        self.next_plate_id += 1
        self.states[plate_id] = self.state_class(plate_id=plate_id, first_seen=now)
        return self._bind(tracker_id, plate_id), False

    def _bind(self, tracker_id, plate_id):
        self.tracker_to_plate[tracker_id] = plate_id
        return plate_id

    @staticmethod
    def _progress(box, frame_shape) -> float:
        return box_center(box)[1] / max(1.0, float(frame_shape[0] - 1))

    def _active_instances(self, instances, frame_shape):
        """Drop observations after EXIT; keep the first crossing so it can finalize."""
        active = []
        for item in instances:
            box = tuple(float(value) for value in item["xyxy"])
            mapped_plate_id = self.tracker_to_plate.get(int(item["tracker_id"]))
            mapped_state = self.states.get(mapped_plate_id)
            if mapped_state is not None and mapped_state.finished:
                item["ignore_after_exit"] = True
                continue
            if mapped_plate_id is None and self._progress(box, frame_shape) <= EXIT_LINE_RATIO:
                item["ignore_after_exit"] = True
                continue
            active.append(item)
        return active

    def update(self, instances, frame_shape, frame_index=0, inference_ms=0.0):
        """Annotate ``instances`` in place with persistent IDs and stages."""
        now = self._now()
        self.inference_index += 1
        self.frame_shape = tuple(frame_shape[:2])
        active = self._active_instances(instances, frame_shape)
        self._on_frame(now, frame_index, inference_ms, active)
        visible = set()
        for index, item in enumerate(active):
            tracker_id = int(item["tracker_id"])
            box = tuple(float(value) for value in item["xyxy"])
            color = item.get("stable_color", "unknown")
            plate_id, reappeared = self._plate_for(tracker_id, box, now)
            state = self.states[plate_id]
            switched = (
                state.observations > 0 and color != "unknown"
                and state.last_color != "unknown" and color != state.last_color
            )
            state.tracker_ids.add(tracker_id)
            state.last_seen = now
            state.last_box = box
            state.observations += 1
            state.color_switches += int(switched)
            if color != "unknown":
                state.last_color = color
            visible.add(plate_id)
            progress = self._progress(box, frame_shape)
            self._update_line_crossings(state, color, now, progress)
            if state.exit_time is not None:
                item["ignore_after_exit"] = True
            item["persistent_plate_id"] = plate_id
            item["tracking_stage"] = state.stage
            self._on_observation(
                now=now, frame_index=frame_index, inference_ms=inference_ms, index=index,
                item=item, state=state, box=box, progress=progress,
                reappeared=reappeared, switched=switched,
            )
        for plate_id in self.visible_last - visible:
            self.states[plate_id].disappearances += 1
        self.visible_last = visible
        self._on_frame_done(now, visible)

    def _update_line_crossings(self, state, color, now, progress):
        previous = state.last_progress
        if state.entry_time is None and line_crossed(previous, progress, ENTRY_LINE_RATIO):
            state.entry_time = now
            state.entry_color = color
            state.stage = "entered"
            self._on_entry(state)
            self._on_crossing(state, "entry", color, now, progress)
        if (
            state.entry_time is not None and state.count_time is None
            and line_crossed(previous, progress, COUNTING_LINE_RATIO)
        ):
            state.count_time = now
            state.count_color = color
            state.stage = "counted"
            self._on_crossing(state, "count", color, now, progress)
        if (
            state.entry_time is not None and state.exit_time is None
            and line_crossed(previous, progress, EXIT_LINE_RATIO)
        ):
            state.exit_candidate = True
            state.stage = "exit_candidate"
        state.last_progress = progress

    def finalize_disappearance(self, plate_id, event):
        """Apply an MQTT ``exit``/``catch`` decision to the plate lifecycle."""
        state = self.states.get(int(plate_id))
        if state is None or event not in {"exit", "catch"}:
            return
        now = self._now()
        state.stage = "exited" if event == "exit" else "caught"
        if event == "catch":
            state.caught_time = now
        if event == "exit" and state.exit_time is None:
            state.exit_time = now
            state.exit_color = state.last_color
            self._on_exit(state)
            self._on_crossing(state, "exit", state.last_color, now, state.last_progress or 0.0)

    # Hooks for validation recorders; the device needs none of them.
    def _on_frame(self, now, frame_index, inference_ms, active_instances):
        pass

    def _on_observation(self, **observation):
        pass

    def _on_frame_done(self, now, visible):
        pass

    def _on_entry(self, state):
        pass

    def _on_exit(self, state):
        pass

    def _on_crossing(self, state, line, color, now, progress):
        pass
