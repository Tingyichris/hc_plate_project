"""Allow the detector to run with ``python -m plate_detector``."""

from .launcher import main


if __name__ == "__main__":
    main()
