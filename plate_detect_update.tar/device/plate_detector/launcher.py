"""Launch the device detector with optional USB camera binding resolution."""

from __future__ import annotations

import argparse

from .aoi import resolve_aoi_file
from .camera_registry import auto_bind_devices, load_device_config, resolve_camera_selection
from .settings import CAMERA_INDEX, VIDEO_SOURCE


def add_camera_arguments(parser: argparse.ArgumentParser) -> None:
    selection = parser.add_mutually_exclusive_group()
    selection.add_argument("--camera", type=int, help="explicit current camera index")
    selection.add_argument("--camera-id", default="", help="saved logical camera ID")
    parser.add_argument("--mqtt-camera-id", default="", help="override the binding/default MQTT camera ID")


def build_runtime(args, identity=None, observers=(), show_window=True):
    """Resolve the camera/AOI/MQTT selection and return a ready DetectorRuntime."""
    from .runtime import DetectorRuntime

    auto_bind_devices()
    load_device_config()
    selection = resolve_camera_selection(args.camera, args.camera_id, args.mqtt_camera_id)
    if selection.camera_index is not None:
        source = selection.camera_index
    else:
        source = VIDEO_SOURCE if VIDEO_SOURCE is not None else CAMERA_INDEX
    return DetectorRuntime(
        source=source,
        aoi_file=resolve_aoi_file(selection.camera_id, selection.binding),
        mqtt_camera_id=selection.mqtt_camera_id,
        identity=identity,
        observers=observers,
        show_window=show_window,
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    add_camera_arguments(parser)
    build_runtime(parser.parse_args()).run()


if __name__ == "__main__":
    main()
