"""Application settings for the deployment environment."""

from pathlib import Path

from .device_identity import automatic_pi_id

PROJECT_ROOT = Path(__file__).resolve().parent.parent


def project_path(value: str | Path) -> Path:
    """Resolve a setting path relative to the project directory."""
    path = Path(value)
    return path if path.is_absolute() else PROJECT_ROOT / path

# Camera
CAMERA_INDEX = 2
CAMERA_SOURCE = ""
CAMERA_WIDTH = 1280
CAMERA_HEIGHT = 720
CAMERA_FPS = 30

# Inference
INFERENCE_URL = "http://192.168.100.69:9001"
# Deployment credential. Keep this file private when a real key is assigned.
INFERENCE_API_KEY = "BVx5V2cFNjfZVkscdtcb"
INFERENCE_MODEL_ID = "-v4qph/-j7pjz-4-yolo26n-seg-t1"
INFERENCE_TARGET_CLASS = ""

# AOI
AOI_ENABLED = True
AOI_FILE = "detector_config/cam-2-aoi.json"
AOI_WARP_ENABLED = False
AOI_WARP_STRENGTH = 0.35

# Detection (recording/capture settings live in validation/settings.py)
DETECTION_EXCLUDED_COLORS = ["black"]

# MQTT
MQTT_ENABLED = True
# Device identity is generated automatically; connection settings have one source.
PI_ID = automatic_pi_id()
REPORT_MQTT_BROKER_HOST = "192.168.100.69"
REPORT_MQTT_BROKER_PORT = 1883
REPORT_MQTT_USERNAME = "HC-A2"
REPORT_MQTT_PASSWORD = "Hc80636855"
REPORT_MQTT_CLIENT_ID = "plate-detector"
REPORT_MQTT_QOS = 1
MQTT_KEEPALIVE = 30
MQTT_CAMERA_ID = "cam-1"
BACKEND_URL = "https://192.168.100.69"
BACKEND_SERVICE_TOKEN = "dev-service-token"
SNAPSHOT_INTERVAL_SECONDS = 5.0
MQTT_DISAPPEAR_CONFIRM_SECONDS = 2.3
MQTT_EXIT_APPROACH_RATIO = 0.35

# Optional backend topology source. When configured, the active map is the
# authority for this camera's immediate upstream/downstream neighbours.
TOPOLOGY_BACKEND_URL = BACKEND_URL
TOPOLOGY_SERVICE_TOKEN = BACKEND_SERVICE_TOKEN

# Accuracy test metadata
TEST_MEAL = "unspecified"
TEST_SPACING = "unspecified"
TEST_SPEED = "unspecified"
TEST_PLANNED_LAPS = 10


