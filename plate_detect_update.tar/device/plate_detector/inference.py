"""Model input preparation, inference calls, and prediction parsing."""

from __future__ import annotations

from collections import Counter

import numpy as np

from . import constants as const
from . import supervision as sv
from .inference_sdk import InferenceConfiguration, InferenceHTTPClient
from .settings import (
    API_URL,
    CLEAN_CONTRAST_BRIGHTNESS,
    CLEAN_CONTRAST_CONTRAST,
    CONFIDENCE,
    IOU_THRESHOLD,
    MODEL_ID,
    PREPROCESS_MODE,
    TARGET_CLASS,
)


def preprocess_aoi_for_inference(masked_aoi):
    if PREPROCESS_MODE == "clean_contrast":
        # Apply brightness first, then contrast. Work in BGR so no hue or
        # saturation operation
        # can create patchy false colors on a smooth plate surface.
        valid_pixels = np.any(masked_aoi != 0, axis=2)
        darkened = np.clip(
            masked_aoi.astype(np.float32) + CLEAN_CONTRAST_BRIGHTNESS,
            0,
            255,
        )
        contrast = CLEAN_CONTRAST_CONTRAST
        contrast_factor = (
            259.0 * (contrast + 255.0)
        ) / (
            255.0 * (259.0 - contrast)
        )
        enhanced = np.clip(
            contrast_factor * (darkened - 128.0) + 128.0,
            0,
            255,
        ).astype(np.uint8)
        enhanced[~valid_pixels] = 0
        return enhanced

    # Defensive fallback if PREPROCESS_MODE is changed incorrectly.
    return masked_aoi


def normalize_result(result):
    if isinstance(result, list):
        if not result:
            return {"predictions": []}
        result = result[0]

    if not isinstance(result, dict):
        return {"predictions": []}

    return result


def run_inference(client, aoi_image):
    result = normalize_result(
        client.infer(
            aoi_image,
            model_id=MODEL_ID,
        )
    )
    # Enforce the threshold locally as well. Do not rely solely on the
    # inference server honoring the requested confidence configuration.
    result["predictions"] = [
        prediction
        for prediction in result.get("predictions", [])
        if float(prediction.get("confidence", 0.0)) >= CONFIDENCE
    ]
    return result


def prediction_to_polygon(prediction, image_width, image_height):
    points = prediction.get("points", [])

    if len(points) < 3:
        return None

    polygon = np.array(
        [
            [
                int(round(point["x"])),
                int(round(point["y"])),
            ]
            for point in points
        ],
        dtype=np.int32,
    )

    polygon[:, 0] = np.clip(
        polygon[:, 0],
        0,
        image_width - 1,
    )
    polygon[:, 1] = np.clip(
        polygon[:, 1],
        0,
        image_height - 1,
    )

    return polygon


def describe_predictions(result):
    predictions = result.get("predictions", [])
    classes = Counter(
        str(prediction.get("class", "unknown"))
        for prediction in predictions
    )
    best_confidence = max(
        (
            float(prediction.get("confidence", 0.0))
            for prediction in predictions
        ),
        default=0.0,
    )
    return predictions, classes, best_confidence


def predictions_to_detections(result, aoi_width, aoi_height):
    """
    Convert Roboflow object-detection output into sv.Detections.

    The bbox model does not return segmentation points. When points are absent,
    we use the detection box as a rectangular polygon so the existing color,
    ordering, tracking, and drawing logic can stay shared.
    """
    boxes = []
    confidences = []
    class_ids = []
    class_names = []
    source_indices = []
    polygons = []

    for prediction in result.get("predictions", []):
        prediction_class = str(prediction.get("class", ""))

        if TARGET_CLASS and prediction_class != TARGET_CLASS:
            continue

        confidence = float(prediction.get("confidence", 0.0))

        # Second defensive gate for callers/tests that pass a result directly
        # instead of going through run_inference().
        if confidence < CONFIDENCE:
            continue

        center_x = float(prediction["x"])
        center_y = float(prediction["y"])
        box_width = float(prediction["width"])
        box_height = float(prediction["height"])

        x1 = center_x - box_width / 2.0
        y1 = center_y - box_height / 2.0
        x2 = center_x + box_width / 2.0
        y2 = center_y + box_height / 2.0

        x1 = np.clip(x1, 0, aoi_width - 1)
        y1 = np.clip(y1, 0, aoi_height - 1)
        x2 = np.clip(x2, 0, aoi_width - 1)
        y2 = np.clip(y2, 0, aoi_height - 1)

        polygon = prediction_to_polygon(
            prediction,
            image_width=aoi_width,
            image_height=aoi_height,
        )

        if polygon is None:
            polygon = np.asarray(
                [
                    [int(round(x1)), int(round(y1))],
                    [int(round(x2)), int(round(y1))],
                    [int(round(x2)), int(round(y2))],
                    [int(round(x1)), int(round(y2))],
                ],
                dtype=np.int32,
            )

        source_index = len(polygons)
        polygons.append(polygon)

        boxes.append([x1, y1, x2, y2])
        confidences.append(confidence)
        class_ids.append(int(prediction.get("class_id", 0)))
        class_names.append(prediction_class)
        source_indices.append(source_index)

    if not boxes:
        detections = sv.Detections(
            xyxy=np.empty((0, 4), dtype=np.float32),
            confidence=np.empty((0,), dtype=np.float32),
            class_id=np.empty((0,), dtype=np.int32),
            data={
                "class_name": np.empty((0,), dtype=object),
                "source_index": np.empty((0,), dtype=np.int32),
            },
        )
        return detections, polygons

    detections = sv.Detections(
        xyxy=np.asarray(boxes, dtype=np.float32),
        confidence=np.asarray(confidences, dtype=np.float32),
        class_id=np.asarray(class_ids, dtype=np.int32),
        data={
            "class_name": np.asarray(class_names, dtype=object),
            "source_index": np.asarray(source_indices, dtype=np.int32),
        },
    )

    return detections, polygons


def create_inference_client(confidence=CONFIDENCE, iou_threshold=IOU_THRESHOLD):
    api_key = str(const.INFERENCE_API_KEY).strip()
    if not api_key:
        raise RuntimeError("INFERENCE_API_KEY is empty in plate_detector/constants.py.")
    client = InferenceHTTPClient(api_url=API_URL, api_key=api_key)
    client.configure(
        InferenceConfiguration(
            confidence_threshold=confidence,
            iou_threshold=iou_threshold,
            api_key_transport="header",
        )
    )
    return client
