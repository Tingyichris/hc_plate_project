"""Device detection loop: camera -> AOI -> inference -> tracking -> identity -> MQTT.

Validation tools attach to this loop through ``observers`` and may replace the
identity tracker with a recording subclass; the device never imports them.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field

import cv2

from . import constants as const
from .aoi import full_frame_polygon, load_aoi_polygon, load_or_select_aoi_polygon, select_aoi_polygon
from .camera import open_source
from .drawing import draw_aoi_overlay, draw_summary_panel, draw_tracked_instances, draw_tracking_guides
from .geometry import prepare_aoi_view
from .inference import create_inference_client, describe_predictions, preprocess_aoi_for_inference, run_inference
from .instances import create_color_history, create_tracker, process_predictions
from .plate_identity import PlateIdentityTracker
from .settings import (
    CAMERA_FPS,
    DEFAULT_WARP_ENABLED,
    PREPROCESS_MODE,
    PROCESS_EVERY_N_FRAMES,
    TARGET_CLASS,
    USE_AOI_DEFAULT,
)
from .snapshot import upload_camera_snapshot

WINDOW_TITLE = "Plate Segmentation + BBox + ByteTrack + HLS"


@dataclass
class FrameResult:
    """Everything one inference produced; handed to observers."""

    frame_index: int
    frame: object
    original_aoi: object
    masked_aoi: object
    model_input: object = None
    predictions: list = field(default_factory=list)
    classes: dict = field(default_factory=dict)
    best_confidence: float = 0.0
    instances: list = field(default_factory=list)
    inference_ms: float = 0.0
    plate_events: list = field(default_factory=list)
    preprocess_mode: str = PREPROCESS_MODE
    warp_active: bool = False
    use_aoi: bool = False


class DetectionObserver:
    """No-op base for validation hooks."""

    def on_inference(self, result: FrameResult) -> None:
        pass

    def display_lines(self) -> list[str]:
        return []

    def on_output(self, output, result: FrameResult | None) -> None:
        pass

    def on_key(self, key: int, result: FrameResult | None, output) -> None:
        pass

    def close(self) -> None:
        pass


class DetectorRuntime:
    def __init__(self, source, aoi_file, mqtt_camera_id="", identity=None, observers=(), show_window=True):
        self.source = source
        self.aoi_file = aoi_file
        self.identity = identity if identity is not None else PlateIdentityTracker()
        self.observers = list(observers)
        self.show_window = show_window
        self.client = create_inference_client()
        self.tracker = create_tracker(CAMERA_FPS / PROCESS_EVERY_N_FRAMES)
        self.color_history = create_color_history()
        self.mqtt = None
        if const.MQTT_ENABLED:
            from .mqtt import PlateMqttPublisher

            self.mqtt = PlateMqttPublisher(camera_id=mqtt_camera_id or None, aoi_file=aoi_file)
        self.warp_enabled = DEFAULT_WARP_ENABLED
        self.latest: FrameResult | None = None
        self.last_error = ""
        self.last_debug_print = 0.0
        self.last_snapshot_upload = float("-inf")
        self.snapshot_thread = None

    def _initial_aoi(self, frame):
        self.use_aoi = USE_AOI_DEFAULT
        if self.use_aoi and const.BACKEND_URL:
            # A new camera must start and upload previews before an AOI is drawn in the web UI;
            # use the full frame until retained MQTT configuration arrives.
            self.aoi_polygon = load_aoi_polygon(self.aoi_file, frame.shape)
            if self.aoi_polygon is None:
                self.use_aoi = False
                self.aoi_polygon = full_frame_polygon(frame)
        elif self.use_aoi:
            self.aoi_polygon = load_or_select_aoi_polygon(frame, self.aoi_file)
        else:
            self.aoi_polygon = full_frame_polygon(frame)

    def _reset_tracking(self):
        self.tracker.reset()
        self.color_history.clear()
        self.latest = None

    def _refresh_aoi_from_mqtt(self, frame):
        if self.mqtt is not None and self.mqtt.consume_aoi_updated():
            updated = load_aoi_polygon(self.aoi_file, frame.shape)
            if updated is not None:
                self.aoi_polygon = updated
                self.use_aoi = True

    def _maybe_upload_snapshot(self, frame):
        now = time.monotonic()
        interval = const.SNAPSHOT_INTERVAL_SECONDS
        busy = self.snapshot_thread is not None and self.snapshot_thread.is_alive()
        if not const.BACKEND_URL or interval <= 0 or busy or now - self.last_snapshot_upload < interval:
            return
        self.snapshot_thread = threading.Thread(target=upload_camera_snapshot, args=(frame.copy(),), daemon=True)
        self.snapshot_thread.start()
        self.last_snapshot_upload = now

    def _aoi_view(self, frame):
        if self.use_aoi:
            return prepare_aoi_view(frame, self.aoi_polygon, self.warp_enabled)
        self.aoi_polygon = full_frame_polygon(frame)
        return frame, frame, 0, 0, None, False

    def _infer(self, result: FrameResult):
        started = time.perf_counter()
        prediction = run_inference(self.client, result.model_input)
        result.predictions, result.classes, result.best_confidence = describe_predictions(prediction)
        # Classification/reflection filtering uses the same calibrated image as inference.
        result.instances = process_predictions(
            result=prediction,
            original_aoi=result.model_input,
            tracker=self.tracker,
            color_history=self.color_history,
        )
        result.inference_ms = (time.perf_counter() - started) * 1000.0
        shape = result.original_aoi.shape
        self.identity.update(result.instances, shape, result.frame_index, result.inference_ms)
        if self.mqtt is not None:
            result.plate_events = self.mqtt.observe(result.instances, shape)
            for event, plate_id, _plate_class in result.plate_events:
                if event in {"exit", "catch"}:
                    self.identity.finalize_disappearance(plate_id, event)
        for observer in self.observers:
            observer.on_inference(result)
        self._debug_print(result)

    def _debug_print(self, result: FrameResult):
        now = time.time()
        if now - self.last_debug_print < 1.0:
            return
        print(
            "Inference:",
            f"predictions={len(result.predictions)}",
            f"classes={dict(result.classes)}",
            f"best={result.best_confidence:.2f}",
            f"tracked={len(result.instances)}",
            f"target={TARGET_CLASS or 'ALL'}",
            f"mode={result.preprocess_mode}",
            f"warp={'on' if result.warp_active else 'off'}",
            f"aoi={'on' if result.use_aoi else 'full'}",
        )
        self.last_debug_print = now

    def _process_frame(self, frame_index, frame):
        original_aoi, masked_aoi, aoi_x, aoi_y, inverse, warp_active = self._aoi_view(frame)
        if original_aoi is None or original_aoi.size == 0:
            print("AOI is empty.")
            return None, None
        result = FrameResult(
            frame_index=frame_index, frame=frame, original_aoi=original_aoi, masked_aoi=masked_aoi,
            model_input=preprocess_aoi_for_inference(masked_aoi), warp_active=warp_active, use_aoi=self.use_aoi,
        )
        if frame_index == 1 or frame_index % PROCESS_EVERY_N_FRAMES == 0:
            try:
                self._infer(result)
                self.latest = result
                self.last_error = ""
            except Exception as error:  # keep the device loop alive on transient inference failures
                self.latest = None
                self.last_error = str(error)
                print("Inference error:", repr(error))
        return self._render(frame, result, aoi_x, aoi_y, inverse), result

    def _render(self, frame, result, aoi_x, aoi_y, inverse):
        latest = self.latest
        instances = latest.instances if latest is not None else []
        output = frame.copy()
        draw_aoi_overlay(output, self.aoi_polygon)
        draw_tracked_instances(
            frame=output, tracked_instances=instances, aoi_x=aoi_x, aoi_y=aoi_y,
            aoi_polygon=self.aoi_polygon, inverse_matrix=inverse,
        )
        draw_tracking_guides(output, self.aoi_polygon)
        extra_lines = [line for observer in self.observers for line in observer.display_lines()]
        draw_summary_panel(
            frame=output, tracked_instances=instances,
            inference_ms=latest.inference_ms if latest is not None else 0.0,
            preprocess_mode=result.preprocess_mode, warp_active=result.warp_active,
            use_aoi=self.use_aoi, recorder_lines=extra_lines or None,
        )
        if self.last_error:
            cv2.putText(
                output, "Inference error - see terminal", (15, 28),
                cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 0, 255), 2, cv2.LINE_AA,
            )
        return output

    def _handle_key(self, key, frame) -> bool:
        """Return False when the loop should stop."""
        if key == ord("q"):
            return False
        if key == ord("a"):
            self.use_aoi = not self.use_aoi
            self.aoi_polygon = (
                load_or_select_aoi_polygon(frame, self.aoi_file) if self.use_aoi else full_frame_polygon(frame)
            )
            self._reset_tracking()
        elif key == ord("r"):
            self.use_aoi = True
            self.aoi_polygon = select_aoi_polygon(frame, self.aoi_file)
            self._reset_tracking()
        elif key == ord("w"):
            self.warp_enabled = not self.warp_enabled
            self._reset_tracking()
        return True

    def run(self):
        capture, frame = open_source(self.source)
        self._initial_aoi(frame)
        frame_index = 0
        try:
            while True:
                success, frame = capture.read()
                if not success:
                    print("Camera frame could not be read.")
                    break
                frame_index += 1
                self._refresh_aoi_from_mqtt(frame)
                self._maybe_upload_snapshot(frame)
                output, result = self._process_frame(frame_index, frame)
                if output is None:
                    break
                for observer in self.observers:
                    observer.on_output(output, self.latest)
                if not self.show_window:
                    continue
                cv2.imshow(WINDOW_TITLE, output)
                key = cv2.waitKey(1) & 0xFF
                for observer in self.observers:
                    observer.on_key(key, self.latest or result, output)
                if not self._handle_key(key, frame):
                    break
        finally:
            capture.release()
            for observer in self.observers:
                observer.close()
            if self.mqtt is not None:
                self.mqtt.close()
            cv2.destroyAllWindows()
