"""Open USB cameras or video files with MJPEG negotiation and black-frame warm-up."""

from __future__ import annotations

import sys
import time

import cv2

from .camera_registry import auto_bind_devices, enumerate_devices
from .settings import CAMERA_FPS, CAMERA_HEIGHT, CAMERA_WIDTH


def _is_usable(frame) -> bool:
    # UVC startup frames can be readable yet completely black.
    return frame is not None and float(frame.mean()) > 2.0 and int(frame.max()) > 10


def read_warmed_frame(capture, attempts: int = 30):
    last_frame = None
    for _ in range(attempts):
        ok, frame = capture.read()
        if ok and frame is not None:
            last_frame = frame
            if _is_usable(frame):
                return frame
        time.sleep(0.04)
    return last_frame


def create_capture(camera_index: int, force_mjpeg: bool, size=(CAMERA_WIDTH, CAMERA_HEIGHT), fps=CAMERA_FPS):
    backend = cv2.CAP_DSHOW if sys.platform.startswith("win") else cv2.CAP_ANY
    capture = cv2.VideoCapture(camera_index, backend)
    if capture.isOpened() and force_mjpeg:
        # Asking OpenCV only for width/height/FPS may negotiate a black YUY2 stream.
        capture.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
        capture.set(cv2.CAP_PROP_FRAME_WIDTH, size[0])
        capture.set(cv2.CAP_PROP_FRAME_HEIGHT, size[1])
        capture.set(cv2.CAP_PROP_FPS, fps)
    return capture


def camera_info_by_index() -> dict:
    return {camera.index: camera for camera in enumerate_devices()}


def open_camera(camera_index: int, size=(CAMERA_WIDTH, CAMERA_HEIGHT), fps=CAMERA_FPS):
    """Return ``(capture, first_frame)``; try MJPEG first, then the device default."""
    info = camera_info_by_index().get(camera_index)
    device_label = info.name if info is not None else "unknown device"
    for force_mjpeg in (True, False):
        capture = create_capture(camera_index, force_mjpeg, size, fps)
        if not capture.isOpened():
            capture.release()
            continue
        frame = read_warmed_frame(capture)
        if _is_usable(frame):
            mode = f"MJPEG {size[0]}x{size[1]}" if force_mjpeg else "device default"
            print(
                f"Camera {camera_index} ({device_label}) opened with {mode}; "
                f"frame={frame.shape[1]}x{frame.shape[0]} mean={frame.mean():.1f}"
            )
            return capture, frame
        capture.release()

    info_hint = f" ({info.path})" if info is not None and info.path else ""
    raise RuntimeError(
        f"Camera index {camera_index} ({device_label}) opened no usable non-black "
        f"stream{info_hint}. Run 'python main.py --list-cameras'. "
        f"Close Camera/Teams/OBS/other detector processes if they own the device."
    )


def open_source(source):
    """Open a camera index (int or digit string) or a video file path."""
    if isinstance(source, str) and source.strip().isdigit():
        source = int(source)
    if isinstance(source, int):
        return open_camera(source)
    capture = cv2.VideoCapture(source)
    if not capture.isOpened():
        raise RuntimeError(f"Cannot open video source {source!r}.")
    ok, frame = capture.read()
    if not ok:
        capture.release()
        raise RuntimeError(f"Video source {source!r} opened, but no frame could be read.")
    return capture, frame


def list_cameras() -> None:
    found = []
    cameras = enumerate_devices()
    bindings = auto_bind_devices(devices=cameras)
    print(f"Enumerated {len(cameras)} camera devices:")
    for info in cameras:
        print(f"  camera {info.index}: {info.name}")
        if info.path:
            print(f"    path: {info.path}")
        try:
            capture, frame = open_camera(info.index)
            height, width = frame.shape[:2]
            found.append(info.index)
            print(f"    stream: usable ({width}x{height}, mean={frame.mean():.1f})")
            capture.release()
        except RuntimeError as error:
            print(f"    stream: unusable ({error})")
    if not found:
        print("No readable camera found. Close apps using the cameras and retry.")
        return
    if bindings:
        print("Automatic USB-port bindings:")
        for binding in bindings:
            print(f"  {binding['camera_id']}: {binding['device_path']}")
    print("Launch example:")
    print("  python main.py detect --camera-id cam-1")
