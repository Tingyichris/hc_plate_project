"""Pure AOI/plate geometry helpers shared by detection and validation."""

from __future__ import annotations

import cv2
import numpy as np

from .aoi import crop_and_mask_aoi
from .settings import (
    MIN_WARP_SIDE,
    WARP_STRENGTH,
)


def order_quad_points(points):
    points = np.asarray(points, dtype=np.float32)

    if points.shape != (4, 2):
        raise ValueError("Exactly four 2D points are required.")

    # The usual sum/difference shortcut can select the same vertex twice for
    # strongly skewed conveyor trapezoids.  Ordering the convex hull around
    # its centroid guarantees four distinct corners.
    hull = cv2.convexHull(points).reshape(-1, 2)
    if len(hull) != 4:
        raise ValueError("Perspective AOI must be a convex quadrilateral.")

    center = np.mean(hull, axis=0)
    angles = np.arctan2(hull[:, 1] - center[1], hull[:, 0] - center[0])
    ordered = hull[np.argsort(angles)]

    # Start at the upper-left corner. In image coordinates (Y grows down), a
    # positive cross product gives TL, TR, BR, BL order.
    start = int(np.argmin(ordered[:, 0] + ordered[:, 1]))
    ordered = np.roll(ordered, -start, axis=0)
    first_edge = ordered[1] - ordered[0]
    second_edge = ordered[2] - ordered[1]
    edge_cross = (
        first_edge[0] * second_edge[1]
        - first_edge[1] * second_edge[0]
    )
    if edge_cross < 0:
        ordered = ordered[[0, 3, 2, 1]]

    return ordered.astype(np.float32)


def build_perspective_warp(frame, polygon):
    source_polygon = polygon

    if len(source_polygon) != 4:
        hull = cv2.convexHull(source_polygon)
        perimeter = cv2.arcLength(hull, True)
        source_polygon = cv2.approxPolyDP(
            hull,
            0.03 * perimeter,
            True,
        ).reshape(-1, 2)

    if len(source_polygon) != 4:
        return None

    source = order_quad_points(source_polygon)

    top_width = np.linalg.norm(source[1] - source[0])
    bottom_width = np.linalg.norm(source[2] - source[3])

    warp_width = int(round(max(top_width, bottom_width)))

    # Area / mean width estimates the perpendicular conveyor length.  Using
    # the longest slanted side here made heavily skewed AOIs unnecessarily
    # tall and visibly distorted.
    polygon_area = abs(float(cv2.contourArea(source)))
    mean_width = max(1.0, (top_width + bottom_width) * 0.5)
    warp_height = int(round(polygon_area / mean_width))

    if warp_width < MIN_WARP_SIDE or warp_height < MIN_WARP_SIDE:
        return None

    strength = float(np.clip(WARP_STRENGTH, 0.0, 1.0))
    near_width = max(top_width, bottom_width)
    far_width = min(top_width, bottom_width)
    corrected_far_width = far_width + strength * (near_width - far_width)
    far_margin = (warp_width - corrected_far_width) * 0.5

    # The narrower edge is the distant side.  Expand it only partially while
    # leaving the near edge at its natural width.
    if top_width <= bottom_width:
        top_left = far_margin
        top_right = warp_width - 1 - far_margin
        bottom_left = 0.0
        bottom_right = warp_width - 1.0
    else:
        top_left = 0.0
        top_right = warp_width - 1.0
        bottom_left = far_margin
        bottom_right = warp_width - 1 - far_margin

    destination = np.array(
        [
            [top_left, 0],
            [top_right, 0],
            [bottom_right, warp_height - 1],
            [bottom_left, warp_height - 1],
        ],
        dtype=np.float32,
    )

    matrix = cv2.getPerspectiveTransform(
        source,
        destination,
    )

    inverse_matrix = cv2.getPerspectiveTransform(
        destination,
        source,
    )

    warped_original = cv2.warpPerspective(
        frame,
        matrix,
        (warp_width, warp_height),
        flags=cv2.INTER_LINEAR,
    )

    # Do not let pixels outside the selected conveyor AOI leak into the model
    # input through the unused margins of a partial perspective correction.
    destination_mask = np.zeros((warp_height, warp_width), dtype=np.uint8)
    cv2.fillConvexPoly(
        destination_mask,
        np.rint(destination).astype(np.int32),
        255,
    )
    warped_original = cv2.bitwise_and(
        warped_original,
        warped_original,
        mask=destination_mask,
    )

    return warped_original, inverse_matrix


def prepare_aoi_view(frame, polygon, warp_enabled):
    if warp_enabled:
        warped = build_perspective_warp(frame, polygon)

        if warped is not None:
            warped_original, inverse_matrix = warped
            return warped_original, warped_original, 0, 0, inverse_matrix, True

    original_aoi, masked_aoi, aoi_x, aoi_y, _local_polygon = (
        crop_and_mask_aoi(frame, polygon)
    )

    return original_aoi, masked_aoi, aoi_x, aoi_y, None, False


def interpolate_aoi_cross_section(polygon, ratio):
    """Return a cross-section for a four-point conveyor AOI."""
    points = np.asarray(polygon, dtype=np.float32)

    if len(points) != 4:
        x, y, width, height = cv2.boundingRect(points.astype(np.int32))
        line_y = y + int(round(height * ratio))
        return np.asarray([[x, line_y], [x + width, line_y]], dtype=np.int32)

    # AOI selection order is upper-left, lower-left, lower-right,
    # upper-right. Interpolate both conveyor edges by the same ratio.
    left = points[0] + (points[1] - points[0]) * ratio
    right = points[3] + (points[2] - points[3]) * ratio
    return np.rint([left, right]).astype(np.int32)


def project_polygon_to_frame(
    polygon,
    aoi_x,
    aoi_y,
    frame_shape,
    inverse_matrix=None,
):
    projected = polygon.astype(np.float32)

    if inverse_matrix is not None:
        projected = cv2.perspectiveTransform(
            projected.reshape(-1, 1, 2),
            inverse_matrix,
        ).reshape(-1, 2)
    else:
        projected[:, 0] += aoi_x
        projected[:, 1] += aoi_y

    projected = np.rint(projected).astype(np.int32)
    projected[:, 0] = np.clip(projected[:, 0], 0, frame_shape[1] - 1)
    projected[:, 1] = np.clip(projected[:, 1], 0, frame_shape[0] - 1)

    return projected


def project_box_to_frame(
    xyxy,
    aoi_x,
    aoi_y,
    frame_shape,
    inverse_matrix=None,
):
    x1, y1, x2, y2 = xyxy
    corners = np.asarray(
        [
            [x1, y1],
            [x2, y1],
            [x2, y2],
            [x1, y2],
        ],
        dtype=np.float32,
    )
    projected = project_polygon_to_frame(
        corners,
        aoi_x,
        aoi_y,
        frame_shape,
        inverse_matrix,
    )

    box_x1 = int(np.min(projected[:, 0]))
    box_y1 = int(np.min(projected[:, 1]))
    box_x2 = int(np.max(projected[:, 0]))
    box_y2 = int(np.max(projected[:, 1]))

    return box_x1, box_y1, box_x2, box_y2


def polygon_mask(image_shape, polygon):
    mask = np.zeros(
        image_shape[:2],
        dtype=np.uint8,
    )

    cv2.fillPoly(
        mask,
        [polygon],
        255,
    )

    return mask


def box_iou(first, second):
    x1 = max(float(first[0]), float(second[0]))
    y1 = max(float(first[1]), float(second[1]))
    x2 = min(float(first[2]), float(second[2]))
    y2 = min(float(first[3]), float(second[3]))

    intersection = max(0.0, x2 - x1) * max(0.0, y2 - y1)
    first_area = max(0.0, float(first[2] - first[0])) * max(
        0.0,
        float(first[3] - first[1]),
    )
    second_area = max(0.0, float(second[2] - second[0])) * max(
        0.0,
        float(second[3] - second[1]),
    )
    union = first_area + second_area - intersection

    if union <= 0:
        return 0.0

    return intersection / union
