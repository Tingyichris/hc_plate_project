"""Device entry point: live plate detection only.

Accuracy validation and improvement tools live in ``validation/``; run
``python -m validation --help`` for those workflows.
"""

from __future__ import annotations

import sys

HELP = """\
Plate detector (device)

  python main.py detect [--camera CAMERA_INDEX | --camera-id LOGICAL_ID] [--mqtt-camera-id ID]
  python main.py --list-cameras
  python main.py camera-bindings  # auto-bind all detected USB ports
  python main.py camera-bind --camera N --camera-id ID  # optional manual override

Validation / accuracy improvement tools:
  python -m validation --help
"""


def _detect() -> None:
    from plate_detector.launcher import main

    main()


def _list_cameras() -> None:
    from plate_detector.camera import list_cameras

    list_cameras()


def _camera_bind() -> None:
    from plate_detector.bindings_cli import bind_main

    bind_main()


def _camera_bindings() -> None:
    from plate_detector.bindings_cli import list_main

    list_main()


COMMANDS = {
    "detect": "_detect",
    "--list-cameras": "_list_cameras",
    "camera-bind": "_camera_bind",
    "camera-bindings": "_camera_bindings",
}


def main() -> None:
    args = sys.argv[1:]
    if not args or args[0] in {"-h", "--help"}:
        print(HELP)
        return
    handler_name = COMMANDS.get(args[0])
    if handler_name is None:
        raise SystemExit(f"Unknown command: {args[0]!r}. Available commands: {', '.join(COMMANDS)}")
    sys.argv = [sys.argv[0], *args[1:]]
    globals()[handler_name]()


if __name__ == "__main__":
    main()
