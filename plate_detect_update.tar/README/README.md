# 餐盤距離偵測系統

本專案用於輸送帶餐盤的影像偵測、顏色分類、距離穩定度檢查、跨鏡頭交接、MQTT 事件發布及量化評估。

專案分成兩個資料夾：`device/` 是可執行的裝置辨識程式（`python device/main.py`），`validation/` 是驗證與精準度改善工具（在專案根目錄執行 `python -m validation`）。USB 攝影機可綁定固定邏輯 ID，因此 Windows 重新開機後不必依賴可能改變的 OpenCV camera index。

## 文件索引

- [專案啟動與架構說明](專案啟動與架構說明.md)：第一次安裝、USB 綁定、ROI、日常啟動、MVC 目錄與全部指令。
- [專案操作指南](專案操作指南.md)：正式偵測、錄影、批次處理、評估與重新分析。
- [系統架構](系統架構.md)：單鏡頭生命週期、跨鏡頭交接、MQTT、Fusion 與資料流。
- [跨鏡頭交接與融合技術說明](跨鏡頭交接與融合技術說明.md)：Handoff、Fusion、時間窗、全域 ID、位置推算與失敗情境。
- [實驗與決策標準](實驗與決策標準.md)：資料完整性、Ground Truth、評估指標與變更控制規則。

## 系統功能

- 將四點 AOI 投影為輸送帶距離。
- 顯示餐盤距離、本地通過編號、追蹤器 ID、信心分數與顏色。
- 使用 HLS 與 Lab 證據進行顏色分類。
- 使用 ByteTrack 並在短暫斷軌後嘗試恢復本地生命週期。
- 透過 MQTT 交換上下游事件。
- 保存原始觀測、交接結果、JSON／CSV 與 Markdown 報告。
- 將預測與獨立 Ground Truth 分開評估。

沒有獨立感測器或人工 Ground Truth 時，距離自我檢查只能代表信心與追蹤穩定度代理指標，不能宣稱為正式 Precision、Recall 或誤判率。

## 快速開始

```powershell
cd D:\AI\plate_detect
python -m pip install -r device/requirements.txt
python device/main.py --help
```

第一次使用先列出攝影機：

```powershell
python device/main.py --list-cameras
```

建立 USB 綁定後，每顆鏡頭都會同時接收上游並通知下游；日常啟動只需指定
自己的固定 Camera ID：

```powershell
python -m validation self-check --camera-id cam-2 --continuous-handoff
python -m validation self-check --camera-id cam-3 --continuous-handoff
```

正式偵測：

```powershell
python device/main.py detect --camera-id cam-2
```

## 常用輸出

執行結果保存在 `validation/outputs/`，可能包含：

```text
distance_detections.csv
distance_metrics.csv
distance_summary.json
local_lifecycles.json
alignment_candidates.json
algorithm_decisions.json
handoff_results.csv
handoff_summary.json
mqtt_events.jsonl
evaluation.json
evaluation_summary.md
```

實際產出會依啟動模式與可用證據而不同。

## 操作按鍵

- `Q`：結束並保存。
- `R`：重新選擇 ROI。
- `S`：立即保存目前報告。
- `B`：開始一輪橘、綠、黃餐盤測試。
- `A`：保存目前異常畫面。

使用 `--continuous-handoff` 時會自動開始記錄，不需要按 `B`。

## 重要原則

- 原始觀測不可修改。
- 預測與 Ground Truth 必須分開保存。
- 不確定結果必須標示為 `uncertain`。
- 一台鏡頭的顏色不得覆寫另一台鏡頭的本地顏色。
- 未滿足完整驗收條件時不得宣稱 100%。

詳細規範請閱讀 [實驗與決策標準](實驗與決策標準.md)。
