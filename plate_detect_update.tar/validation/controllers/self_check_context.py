"""Controller for the standalone 10 cm distance stability self-check.

This utility deliberately does not change the production detector, recorder,
MQTT publisher, or config/plate.toml.  Edit the SELF-CHECK SETTINGS below and
run:

    python main.py --camera 1

The existing camera/model/AOI settings are reused.  The selected AOI near edge
is treated as 0 cm and its far edge as TRACK_LENGTH_CM.  This is sufficient for
an operational self-check when those two AOI edges physically match the stated
locations.  It is not a ground-truth precision/recall test: without an
independent label or sensor, missed plates cannot be distinguished from empty
track.  The report therefore contains confidence and tracking stability proxy
metrics, not claimed model accuracy.
"""

from __future__ import annotations

import argparse
import math

import cv2
import numpy as np

from plate_detector import constants as const
from validation import settings as validation_settings
from plate_detector.geometry import order_quad_points

# Device folder: detector_config and AOI files are read from here.
PROJECT_ROOT = const.PROJECT_ROOT


# ---------------------------------------------------------------------------
# SELF-CHECK SETTINGS -- keep these settings here; no TOML entry is required.
# ---------------------------------------------------------------------------

REQUIRED_DETECTION_LENGTH_CM = 60.0
ENTRY_BUFFER_CM = 5.0
EXIT_BUFFER_CM = 10.0
TRACK_LENGTH_CM = (
    ENTRY_BUFFER_CM + REQUIRED_DETECTION_LENGTH_CM + EXIT_BUFFER_CM
)
DETECTION_START_CM = ENTRY_BUFFER_CM
DETECTION_END_CM = ENTRY_BUFFER_CM + REQUIRED_DETECTION_LENGTH_CM
BIN_SIZE_CM = 10.0
NEAR_DISTANCE_CM = 0.0

# Change this default or launch with --camera N. Use --list-cameras to discover
# Windows camera indices.
DEFAULT_CAMERA_INDEX = 1

CONFIDENCE_THRESHOLD = 0.35
IOU_THRESHOLD = 0.50

# A bin is provisionally stable when it has enough observations and its lower
# confidence tail remains above this limit.  These are proxy thresholds, not
# precision/recall thresholds.
MIN_OBSERVATIONS_PER_BIN = 20
MIN_CONFIDENCE_P10 = 0.50
MAX_TRACK_GAP_RATE = 0.15
MIN_COLOR_ACCURACY = 0.95
PLANNED_PASSES = 20
TRACK_SPEED_CM_PER_SECOND = 10.0
PASS_RECONNECT_MAX_SECONDS = 3.5
REMOVAL_SUSPECT_SECONDS = 0.35
REMOVAL_CONFIRM_MIN_SECONDS = 0.65
REMOVAL_CONFIRM_MAX_SECONDS = 1.50
PASS_RECONNECT_DISTANCE_TOLERANCE_CM = 15.0
# The belt is one-way.  Keep a small allowance for projection jitter, but do
# not let a following plate jump backwards into an older pass.
PASS_RECONNECT_BACKWARD_TOLERANCE_CM = 3.0
# Keep the production recorder's bbox-based identity check as a second signal.
# This prevents a new tracker from being attached to a nearby plate merely
# because both plates have a plausible conveyor distance.
PASS_RECONNECT_BOX_SCORE_MAX = 1.5
PASS_RECONNECT_BOX_GATE_SECONDS = 2.0
PASS_RECONNECT_COLOR_MIN_VOTES = 2
PASS_RECONNECT_COLOR_MIN_RATIO = 0.75
PASS_RECONNECT_COLOR_MIN_CONFIDENCE = 0.85
BASELINE_MIN_OBSERVATIONS = 2
# Two consecutive equal observations retain a consensus gate while avoiding the
# extra inference cycle that made the live map appear roughly two seconds late.
CONTINUOUS_MIN_PUBLISH_OBSERVATIONS = 2
CONTINUOUS_MAX_FIRST_DISTANCE_CM = DETECTION_START_CM + BIN_SIZE_CM

# Automatic anomaly evidence.
ANOMALY_LOW_CONFIDENCE = 0.65
ANOMALY_CAPTURE_COOLDOWN_SECONDS = 0.75
ANOMALY_MAX_EXPECTED_INSTANCES = 3

# Physical plate order used by this installation.
EXPECTED_COLOR_SEQUENCE = ("orange", "light_green", "yellow")
DISPLAY_COLOR_NAMES = {
    "orange": "O",
    "light_green": "G",
    "yellow": "Y",
    "unknown": "?",
}


def normalize_operational_colors(instance: dict) -> None:
    """Map installation-specific raw gray evidence to the green plate class."""
    raw_current = str(instance.get("current_color", "unknown") or "unknown")
    raw_stable = str(instance.get("stable_color", "unknown") or "unknown")
    instance["raw_current_color"] = raw_current
    instance["raw_stable_color"] = raw_stable
    if raw_current == "gray":
        instance["current_color"] = "light_green"
    if raw_stable == "gray":
        instance["stable_color"] = "light_green"

WINDOW_TITLE = (
    f"Plate distance self-check "
    f"(L{REQUIRED_DETECTION_LENGTH_CM:g}, R{TRACK_LENGTH_CM:g}, "
    f"E{ENTRY_BUFFER_CM:g}, X{EXIT_BUFFER_CM:g})"
)
OUTPUT_ROOT = validation_settings.OUTPUT_ROOT


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--camera",
        type=int,
        default=None,
        help=(
            "OpenCV camera index; when omitted, --camera-id is resolved from "
            "detector_config/device_config.json"
        ),
    )
    parser.add_argument(
        "--list-cameras",
        action="store_true",
        help="probe camera indices and exit",
    )
    parser.add_argument(
        "--select-roi",
        action="store_true",
        help="draw and save this self-check project's four-point ROI",
    )
    parser.add_argument(
        "--handoff-role", choices=("off", "upstream", "downstream", "both"),
        default=None, help="legacy override; neighbor IDs are preferred",
    )
    parser.add_argument(
        "--no-handoff", action="store_true",
        help="disable saved/backend handoff topology for this run",
    )
    parser.add_argument("--camera-id", default="", help="logical camera ID, e.g. cam-3")
    parser.add_argument(
        "--mqtt-camera-id",
        default="",
        help="MQTT camera ID; defaults to the saved binding or --camera-id",
    )
    parser.add_argument("--peer-camera-id", default="", help="other handoff camera ID")
    parser.add_argument(
        "--upstream-camera-id", default="",
        help="immediate upstream MQTT camera ID",
    )
    parser.add_argument(
        "--downstream-camera-id", default="",
        help="immediate downstream MQTT camera ID",
    )
    parser.add_argument(
        "--matching-mode", choices=("fifo",), default="fifo",
        help="cross-camera matching engine (production uses original FIFO)",
    )
    parser.add_argument(
        "--backend-url", default=str(const.TOPOLOGY_BACKEND_URL),
        help="backend base URL; active map supplies immediate neighbours",
    )
    parser.add_argument(
        "--backend-service-token", default=str(const.TOPOLOGY_SERVICE_TOKEN),
        help="optional service token for the active-map request",
    )
    parser.add_argument(
        "--continuous-handoff", action="store_true",
        help="always-on unknown-count/color handoff mode; does not require B",
    )
    parser.add_argument(
        "--headless", action="store_true",
        help="production mode: no window or keyboard controls; continuous recording",
    )
    parser.add_argument(
        "--autosave-seconds", type=float, default=5.0,
        help="live snapshot interval in seconds (default: 5)",
    )
    return parser.parse_args()


def build_world_transform(aoi_polygon: np.ndarray):
    """Return image<->world homographies for the four-point conveyor AOI."""
    ordered = order_quad_points(aoi_polygon)
    # order_quad_points returns TL, TR, BR, BL.  The narrower/top edge is the
    # far end in the current installation; Y=TRACK_LENGTH_CM at that edge.
    world = np.asarray(
        [
            [0.0, TRACK_LENGTH_CM],
            [1.0, TRACK_LENGTH_CM],
            [1.0, NEAR_DISTANCE_CM],
            [0.0, NEAR_DISTANCE_CM],
        ],
        dtype=np.float32,
    )
    image_to_world = cv2.getPerspectiveTransform(ordered, world)
    world_to_image = cv2.getPerspectiveTransform(world, ordered)
    return image_to_world, world_to_image


def transform_points(points: np.ndarray, matrix: np.ndarray) -> np.ndarray:
    points = np.asarray(points, dtype=np.float32).reshape(-1, 1, 2)
    return cv2.perspectiveTransform(points, matrix).reshape(-1, 2)


def distance_bin_start(distance_cm: float) -> float:
    """Return a 10 cm bin aligned to the formal decision interval."""
    bounded = float(np.clip(distance_cm, DETECTION_START_CM, DETECTION_END_CM))
    if math.isclose(bounded, DETECTION_END_CM):
        bounded = max(DETECTION_START_CM, bounded - 1e-6)
    offset = bounded - DETECTION_START_CM
    return DETECTION_START_CM + math.floor(offset / BIN_SIZE_CM) * BIN_SIZE_CM


def distance_bin_end(bin_start_cm: float) -> float:
    """Cap the final distance bin at the decision line."""
    return min(DETECTION_END_CM, bin_start_cm + BIN_SIZE_CM)


def draw_distance_grid(frame: np.ndarray, world_to_image: np.ndarray) -> None:
    distances = [NEAR_DISTANCE_CM, TRACK_LENGTH_CM]
    distances.extend(
        np.arange(
            DETECTION_START_CM,
            DETECTION_END_CM + 1e-6,
            BIN_SIZE_CM,
            dtype=float,
        )
    )
    distances.extend([DETECTION_START_CM, DETECTION_END_CM])
    distances = sorted(set(distances))
    for distance in distances:
        world_line = np.asarray([[0.0, distance], [1.0, distance]], np.float32)
        image_line = np.rint(transform_points(world_line, world_to_image)).astype(int)
        p1 = tuple(image_line[0])
        p2 = tuple(image_line[1])
        is_roi_end = math.isclose(distance, NEAR_DISTANCE_CM) or math.isclose(
            distance, TRACK_LENGTH_CM
        )
        is_detection_edge = math.isclose(
            distance, DETECTION_START_CM
        ) or math.isclose(distance, DETECTION_END_CM)
        if is_roi_end:
            color = (0, 210, 255)
        elif is_detection_edge:
            color = (0, 255, 0)
        else:
            color = (160, 160, 70)
        cv2.line(
            frame,
            p1,
            p2,
            color,
            2 if is_roi_end or is_detection_edge else 1,
            cv2.LINE_AA,
        )
        label_x = int((p1[0] + p2[0]) / 2)
        label_y = int((p1[1] + p2[1]) / 2)
        cv2.putText(
            frame,
            (
                f"{distance:.0f} cm "
                + (
                    "ENTRY"
                    if math.isclose(distance, DETECTION_START_CM)
                    else "DECISION END"
                    if math.isclose(distance, DETECTION_END_CM)
                    else ""
                )
            ).rstrip(),
            (label_x + 5, label_y - 3),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.42,
            color,
            1,
            cv2.LINE_AA,
        )


