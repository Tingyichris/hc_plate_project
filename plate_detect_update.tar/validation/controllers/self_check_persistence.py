"""Focused SelfCheckRecorder behavior."""

from __future__ import annotations

import csv
import json
import math
import time
from collections import Counter, defaultdict

import numpy as np

from .self_check_context import (
    BIN_SIZE_CM,
    DETECTION_END_CM,
    DETECTION_START_CM,
    ENTRY_BUFFER_CM,
    EXIT_BUFFER_CM,
    EXPECTED_COLOR_SEQUENCE,
    MAX_TRACK_GAP_RATE,
    MIN_COLOR_ACCURACY,
    MIN_CONFIDENCE_P10,
    MIN_OBSERVATIONS_PER_BIN,
    PLANNED_PASSES,
    REQUIRED_DETECTION_LENGTH_CM,
    TRACK_LENGTH_CM,
)


class SelfCheckPersistenceMixin:
    def color_calibration_markdown(self) -> str:
        lines = [
            "# 顏色校準建議",
            "",
            f"產生時間：{time.strftime('%Y-%m-%d %H:%M:%S')}",
            "",
            "資料來源為本次 B 啟動後、前處理影像中 segmentation 內縮區域的有效彩色像素。",
            "建議值不會自動寫入正式 detector；請先用另一批盤次驗證。",
            "",
            "## 實測分布與建議",
            "",
            "| 顏色 | observations | H p10 | H 中位數 | H p90 | 建議 HLS 範圍 | 建議 Lab (a,b) |",
            "|---|---:|---:|---:|---:|---|---|",
        ]
        suggested_hues = {}
        lab_centers = {}
        for color in EXPECTED_COLOR_SEQUENCE:
            rows = [
                row for row in self.color_samples
                if row["expected_color"] == color
            ]
            if not rows:
                lines.append(f"| {color} | 0 | - | - | - | 無資料 | 無資料 |")
                continue
            hues = np.asarray([float(row["h_median"]) for row in rows])
            if color == "orange":
                hues = np.where(hues > 150.0, hues - 180.0, hues)
            h10, h50, h90 = np.percentile(hues, [10, 50, 90])
            low = int(math.floor(h10 - 2.0))
            high = int(math.ceil(h90 + 2.0))
            hue_values = set()
            if low < 0:
                ranges = [(0, min(180, high)), (max(0, 180 + low), 180)]
            elif high > 180:
                ranges = [(max(0, low), 180), (0, min(180, high - 180))]
            else:
                ranges = [(max(0, low), min(180, high))]
            for range_low, range_high in ranges:
                hue_values.update(range(range_low, range_high + 1))
            suggested_hues[color] = hue_values
            range_text = ", ".join(f"({a}, {b})" for a, b in ranges)
            lab_a = float(np.median([row["lab_a_median"] for row in rows]))
            lab_b = float(np.median([row["lab_b_median"] for row in rows]))
            lab_centers[color] = (lab_a, lab_b)
            lines.append(
                f"| {color} | {len(rows)} | {h10:.1f} | {h50:.1f} | {h90:.1f} "
                f"| `{range_text}` | `({lab_a:.1f}, {lab_b:.1f})` |"
            )

        lines.extend(["", "## 範圍重疊檢查", ""])
        overlaps = []
        colors = list(suggested_hues)
        for index, left in enumerate(colors):
            for right in colors[index + 1:]:
                shared = sorted(suggested_hues[left] & suggested_hues[right])
                if shared:
                    overlaps.append((left, right, shared))
        if overlaps:
            for left, right, shared in overlaps:
                lines.append(
                    f"- `{left}` 與 `{right}` 重疊 H={min(shared)}～{max(shared)}；"
                    "不要直接套用，需增加樣本或用 Lab 作邊界判斷。"
                )
        else:
            lines.append("- 三種顏色的建議 HLS 範圍沒有重疊。")

        lines.extend([
            "",
            "## 建議常數",
            "",
            "```python",
            "HLS_HUE_RANGES = {",
        ])
        for color in EXPECTED_COLOR_SEQUENCE:
            if color not in suggested_hues:
                continue
            values = sorted(suggested_hues[color])
            ranges = []
            start = previous = values[0]
            for value in values[1:]:
                if value != previous + 1:
                    ranges.append((start, previous))
                    start = value
                previous = value
            ranges.append((start, previous))
            lines.append(f'    "{color}": {ranges},')
        lines.extend(["}", "", "LAB_COLOR_CENTERS = {"])
        for color in EXPECTED_COLOR_SEQUENCE:
            if color in lab_centers:
                a_value, b_value = lab_centers[color]
                lines.append(
                    f'    "{color}": ({a_value:.1f}, {b_value:.1f}),' 
                )
        lines.extend([
            "}",
            "```",
            "",
            "## 驗證要求",
            "",
            "- 每種顏色建議至少累積 20 個完整盤次後再採用。",
            "- 校準資料與驗證資料必須分開。",
            "- 驗證時要逐 10 cm 檢查正確率與橘黃、綠黃混淆。",
            "",
        ])
        return "\n".join(lines)

    def save(self) -> None:
        detection_fields = [
            "session_s",
            "wall_timestamp",
            "inference_index",
            "tracker_id",
            "pass_id",
            "lap_id",
            "distance_cm",
            "distance_bin_start_cm",
            "distance_bin_end_cm",
            "confidence",
            "predicted_color",
            "current_color",
            "raw_predicted_color",
            "raw_current_color",
            "expected_color",
            "upstream_pass_id",
            "upstream_sequence",
            "upstream_published_at",
            "mqtt_received_at",
            "color_correct",
        ]
        with (self.directory / "distance_detections.csv").open(
            "w", newline="", encoding="utf-8-sig"
        ) as handle:
            writer = csv.DictWriter(handle, fieldnames=detection_fields)
            writer.writeheader()
            writer.writerows(self.rows)

        color_event_fields = [
            "wall_timestamp", "session_s", "inference_index", "lap_id",
            "pass_id", "tracker_id", "distance_cm", "confidence",
            "current_color", "stable_color", "raw_current_color",
            "raw_stable_color", "upstream_pass_id",
            "upstream_sequence", "upstream_color", "upstream_published_at",
            "mqtt_received_at", "mqtt_delay_ms",
        ]
        with (self.directory / "downstream_color_events.csv").open(
            "w", newline="", encoding="utf-8-sig"
        ) as handle:
            writer = csv.DictWriter(handle, fieldnames=color_event_fields)
            writer.writeheader()
            for row in self.rows:
                published_at = row.get("upstream_published_at", "")
                received_at = row.get("mqtt_received_at", "")
                mqtt_delay_ms = ""
                if published_at not in ("", None) and received_at not in ("", None):
                    mqtt_delay_ms = round(
                        (float(received_at) - float(published_at)) * 1000.0, 3
                    )
                writer.writerow({
                    "wall_timestamp": row.get("wall_timestamp", ""),
                    "session_s": row.get("session_s", ""),
                    "inference_index": row.get("inference_index", ""),
                    "lap_id": row.get("lap_id", ""),
                    "pass_id": row.get("pass_id", ""),
                    "tracker_id": row.get("tracker_id", ""),
                    "distance_cm": row.get("distance_cm", ""),
                    "confidence": row.get("confidence", ""),
                    "current_color": row.get("current_color", ""),
                    "stable_color": row.get("predicted_color", ""),
                    "raw_current_color": row.get("raw_current_color", ""),
                    "raw_stable_color": row.get("raw_predicted_color", ""),
                    "upstream_pass_id": row.get("upstream_pass_id", ""),
                    "upstream_sequence": row.get("upstream_sequence", ""),
                    "upstream_color": row.get("expected_color", ""),
                    "upstream_published_at": published_at,
                    "mqtt_received_at": received_at,
                    "mqtt_delay_ms": mqtt_delay_ms,
                })

        color_summary_fields = [
            "pass_id", "lap_id", "tracker_ids", "observation_count",
            "first_seen_at", "last_seen_at", "first_stable_color",
            "majority_color", "final_color", "color_change_count",
            "upstream_pass_id", "upstream_sequence", "upstream_color",
            "mqtt_delay_ms", "reference_vs_first_detection_ms",
        ]
        with (self.directory / "downstream_color_summary.csv").open(
            "w", newline="", encoding="utf-8-sig"
        ) as handle:
            writer = csv.DictWriter(handle, fieldnames=color_summary_fields)
            writer.writeheader()
            grouped_rows = defaultdict(list)
            for row in self.rows:
                grouped_rows[int(row["pass_id"])].append(row)
            for pass_id, rows in sorted(grouped_rows.items()):
                rows = sorted(rows, key=lambda item: float(item["wall_timestamp"]))
                colors = [str(row.get("predicted_color", "unknown")) for row in rows]
                known_colors = [color for color in colors if color != "unknown"]
                majority_color = (
                    Counter(known_colors).most_common(1)[0][0]
                    if known_colors else "unknown"
                )
                color_changes = sum(
                    left != right
                    for left, right in zip(known_colors, known_colors[1:])
                )
                state = self.pass_states.get(pass_id, {})
                published_at = state.get("upstream_published_at")
                received_at = state.get("mqtt_received_at")
                first_seen_at = float(rows[0]["wall_timestamp"])
                writer.writerow({
                    "pass_id": pass_id,
                    "lap_id": rows[0].get("lap_id", ""),
                    "tracker_ids": " ".join(
                        str(value) for value in sorted(
                            {int(row["tracker_id"]) for row in rows}
                        )
                    ),
                    "observation_count": len(rows),
                    "first_seen_at": first_seen_at,
                    "last_seen_at": rows[-1].get("wall_timestamp", ""),
                    "first_stable_color": known_colors[0] if known_colors else "unknown",
                    "majority_color": majority_color,
                    "final_color": state.get("final_color") or majority_color,
                    "color_change_count": color_changes,
                    "upstream_pass_id": state.get("upstream_pass_id", ""),
                    "upstream_sequence": state.get("upstream_sequence", ""),
                    "upstream_color": state.get("expected_color", ""),
                    "mqtt_delay_ms": (
                        round((float(received_at) - float(published_at)) * 1000.0, 3)
                        if received_at is not None and published_at is not None else ""
                    ),
                    "reference_vs_first_detection_ms": (
                        round((float(received_at) - first_seen_at) * 1000.0, 3)
                        if received_at is not None else ""
                    ),
                })

        calibration_fields = [
            "inference_index", "tracker_id", "pass_id", "lap_id", "distance_cm",
            "distance_bin_start_cm", "expected_color", "predicted_color",
            "confidence", "sample_pixels", "h_p10", "h_median", "h_p90",
            "l_median", "s_median", "lab_a_median", "lab_b_median",
        ]
        with (self.directory / "color_calibration.csv").open(
            "w", newline="", encoding="utf-8-sig"
        ) as handle:
            writer = csv.DictWriter(handle, fieldnames=calibration_fields)
            writer.writeheader()
            writer.writerows(self.color_samples)

        pass_results = self.pass_bin_results()
        pass_fields = [
            "pass_id", "lap_id", "expected_color", "distance_bin_start_cm",
            "distance_bin_end_cm", "observation_count", "majority_color",
            "majority_count", "majority_ratio", "color_correct",
            "confidence_median", "tracker_ids",
        ]
        with (self.directory / "pass_distance_results.csv").open(
            "w", newline="", encoding="utf-8-sig"
        ) as handle:
            writer = csv.DictWriter(handle, fieldnames=pass_fields)
            writer.writeheader()
            writer.writerows(pass_results)

        metrics = self.metrics()
        with (self.directory / "distance_metrics.csv").open(
            "w", newline="", encoding="utf-8-sig"
        ) as handle:
            writer = csv.DictWriter(handle, fieldnames=list(metrics[0].keys()))
            writer.writeheader()
            writer.writerows(metrics)

        with (self.directory / "distance_summary.json").open(
            "w", encoding="utf-8"
        ) as handle:
            json.dump(
                {
                    "track_length_cm": TRACK_LENGTH_CM,
                    "required_detection_length_cm": REQUIRED_DETECTION_LENGTH_CM,
                    "entry_buffer_cm": ENTRY_BUFFER_CM,
                    "detection_start_cm": DETECTION_START_CM,
                    "detection_end_cm": DETECTION_END_CM,
                    "exit_buffer_cm": EXIT_BUFFER_CM,
                    "bin_size_cm": BIN_SIZE_CM,
                    "planned_passes": PLANNED_PASSES,
                    "identified_passes": len(self.pass_states),
                    "recorded_laps": self.current_lap_id,
                    "thresholds": {
                        "minimum_observations_per_bin": MIN_OBSERVATIONS_PER_BIN,
                        "minimum_confidence_p10": MIN_CONFIDENCE_P10,
                        "maximum_track_gap_rate": MAX_TRACK_GAP_RATE,
                        "minimum_color_accuracy": MIN_COLOR_ACCURACY,
                    },
                    "metric_scope": "pass_distance_majority_vote_and_tracking_stability",
                    "color_accuracy_scope": (
                        "conditional_on_detected_observations_with_O_G_Y_sequence"
                    ),
                    "metrics": metrics,
                },
                handle,
                ensure_ascii=False,
                indent=2,
            )
        (self.directory / "analysis_summary.md").write_text(
            self.analysis_markdown(metrics, pass_results),
            encoding="utf-8",
        )
        (self.directory / "color_calibration_suggestions.md").write_text(
            self.color_calibration_markdown(),
            encoding="utf-8",
        )
        print("Self-check saved:", self.directory)

    def reset(self) -> None:
        self.rows.clear()
        self.by_bin.clear()
        self.bin_tracker_ids.clear()
        self.last_seen_inference.clear()
        self.tracker_gaps.clear()
        self.tracker_observations.clear()
        self.color_samples.clear()
        self.tracker_to_pass.clear()
        self.pass_states.clear()
        self.next_pass_id = 1
        self.next_expected_index = 0
        self.current_lap_id = 0
        self.evaluation_active = False
        self.started = time.perf_counter()
        print("Self-check statistics reset.")


