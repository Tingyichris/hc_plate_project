"""Focused SelfCheckRecorder behavior."""

from __future__ import annotations

import math
import time
from collections import Counter, defaultdict

import cv2
import numpy as np

from plate_detector.settings import MAX_COLOR_LIGHTNESS, MIN_COLOR_LIGHTNESS, MIN_COLOR_PIXELS, MIN_COLOR_SATURATION
from . import self_check_context
from .self_check_context import (
    CONTINUOUS_MAX_FIRST_DISTANCE_CM,
    CONTINUOUS_MIN_PUBLISH_OBSERVATIONS,
    DETECTION_END_CM,
    DISPLAY_COLOR_NAMES,
    ENTRY_BUFFER_CM,
    EXIT_BUFFER_CM,
    EXPECTED_COLOR_SEQUENCE,
    PASS_RECONNECT_BACKWARD_TOLERANCE_CM,
    PASS_RECONNECT_BOX_GATE_SECONDS,
    PASS_RECONNECT_BOX_SCORE_MAX,
    PASS_RECONNECT_COLOR_MIN_RATIO,
    PASS_RECONNECT_COLOR_MIN_VOTES,
    PASS_RECONNECT_DISTANCE_TOLERANCE_CM,
    PASS_RECONNECT_MAX_SECONDS,
    REMOVAL_CONFIRM_MAX_SECONDS,
    REMOVAL_CONFIRM_MIN_SECONDS,
    REMOVAL_SUSPECT_SECONDS,
    REQUIRED_DETECTION_LENGTH_CM,
    TRACK_LENGTH_CM,
    TRACK_SPEED_CM_PER_SECOND,
    distance_bin_start,
)


class SelfCheckLifecycleMixin:
    def __init__(self, handoff=None, external_expected: bool = False,
                 session_suffix: str = "", continuous_mode: bool = False):
        session_name = (
            time.strftime("%Y%m%d_%H%M%S")
            + f"_L{REQUIRED_DETECTION_LENGTH_CM:g}"
            + f"_R{TRACK_LENGTH_CM:g}"
            + f"_E{ENTRY_BUFFER_CM:g}"
            + f"_X{EXIT_BUFFER_CM:g}"
            + (f"_{session_suffix}" if session_suffix else "")
        )
        self.directory = self_check_context.OUTPUT_ROOT / session_name
        self.directory.mkdir(parents=True, exist_ok=True)
        self.started = time.perf_counter()
        self.rows: list[dict] = []
        self.by_bin: dict[float, list[float]] = defaultdict(list)
        self.bin_tracker_ids: dict[float, set[int]] = defaultdict(set)
        self.last_seen_inference: dict[int, int] = {}
        self.tracker_gaps: dict[float, int] = defaultdict(int)
        self.tracker_observations: dict[float, int] = defaultdict(int)
        self.evaluation_active = bool(continuous_mode)
        self.color_samples: list[dict] = []
        self.tracker_to_pass: dict[int, int] = {}
        self.pass_states: dict[int, dict] = {}
        self.next_pass_id = 1
        self.next_expected_index = 0
        self.current_lap_id = 1 if continuous_mode else 0
        self.handoff = handoff
        self.external_expected = external_expected
        self.continuous_mode = continuous_mode

    def _publishes_downstream(self) -> bool:
        """Support both dual nodes and legacy test/one-way handoff objects."""
        return bool(
            self.handoff is not None
            and getattr(
                self.handoff, "publishes_downstream", not self.external_expected
            )
        )

    def start_color_cycle(self) -> None:
        self.current_lap_id += 1
        self.evaluation_active = True
        self.next_expected_index = 0
        # A new lap must not reconnect to a plate from the previous lap, but
        # all prior observations remain available for the final report.
        self.tracker_to_pass.clear()
        self.last_seen_inference.clear()
        print(
            f"Lap {self.current_lap_id} armed: next plates must be "
            "ORANGE, GREEN, YELLOW. Previous laps are preserved."
        )
        if self.handoff is not None:
            self.handoff.start_lap(self.current_lap_id)

    @staticmethod
    def _box_match_score(first, second):
        if first is None or second is None:
            return None
        ax = (float(first[0]) + float(first[2])) / 2.0
        ay = (float(first[1]) + float(first[3])) / 2.0
        bx = (float(second[0]) + float(second[2])) / 2.0
        by = (float(second[1]) + float(second[3])) / 2.0
        scale = max(
            20.0,
            math.hypot(
                float(second[2]) - float(second[0]),
                float(second[3]) - float(second[1]),
            ),
        )
        return math.hypot(ax - bx, ay - by) / scale

    def _new_pass(self, tracker_id, distance, now, inference_index, box=None):
        pass_id = self.next_pass_id
        self.next_pass_id += 1
        expected_color = ""
        if not self.external_expected and not self.continuous_mode:
            expected_color = EXPECTED_COLOR_SEQUENCE[self.next_expected_index]
            self.next_expected_index = (
                self.next_expected_index + 1
            ) % len(EXPECTED_COLOR_SEQUENCE)
        state = {
            "pass_id": pass_id,
            "lap_id": self.current_lap_id,
            "expected_color": expected_color,
            "last_distance": distance,
            "min_distance": distance,
            "last_seen": now,
            "first_seen_unix": time.time(),
            "last_inference": inference_index,
            "last_box": box,
            "tracker_ids": {tracker_id},
            "measurement_started": False,
            "decision_locked": False,
            "final_color": None,
            "final_observations": 0,
            "final_confidence_median": None,
            "stage": "approaching",
            "missing_since": None,
            "removal_suspected": False,
            # This is strictly this camera's own colour history.  In
            # downstream mode the MQTT reference colour is deliberately not
            # used for identity matching, so the validation remains blind.
            "local_color_votes": Counter(),
        }
        self.pass_states[pass_id] = state
        self.tracker_to_pass[tracker_id] = pass_id
        print(
            f"New pass P{pass_id}: expected="
            f"{DISPLAY_COLOR_NAMES.get(expected_color, expected_color) or 'upstream'}"
        )
        return state

    @staticmethod
    def _stable_local_color(state):
        votes = state.get("local_color_votes") or Counter()
        known = Counter({
            color: count for color, count in votes.items()
            if color and color != "unknown"
        })
        total = sum(known.values())
        if total < PASS_RECONNECT_COLOR_MIN_VOTES:
            return None
        color, count = known.most_common(1)[0]
        if count / total < PASS_RECONNECT_COLOR_MIN_RATIO:
            return None
        return color

    def _assign_pass(
        self, tracker_id, distance, now, inference_index, assigned_this_inference,
        box=None, local_color=None,
    ):
        mapped_pass_id = self.tracker_to_pass.get(tracker_id)
        if mapped_pass_id is not None and mapped_pass_id in assigned_this_inference:
            # A duplicate detection carrying the same tracker ID must not be
            # allowed to create or steal another persistent pass ID.
            return None
        if mapped_pass_id is not None:
            state = self.pass_states[mapped_pass_id]
            if state["stage"] in {"exited", "caught"}:
                return None
        else:
            candidates = []
            for pass_id, candidate in self.pass_states.items():
                if pass_id in assigned_this_inference:
                    continue
                if int(candidate["lap_id"]) != self.current_lap_id:
                    continue
                if candidate["stage"] in {"exited", "caught"}:
                    continue
                elapsed = now - float(candidate["last_seen"])
                if elapsed < 0 or elapsed > PASS_RECONNECT_MAX_SECONDS:
                    continue
                last_distance = float(candidate["last_distance"])
                if distance < last_distance - PASS_RECONNECT_BACKWARD_TOLERANCE_CM:
                    continue
                predicted_distance = min(
                    TRACK_LENGTH_CM,
                    last_distance + TRACK_SPEED_CM_PER_SECOND * elapsed,
                )
                error = abs(distance - predicted_distance)
                if error > PASS_RECONNECT_DISTANCE_TOLERANCE_CM:
                    continue
                box_score = self._box_match_score(box, candidate.get("last_box"))
                candidate_color = self._stable_local_color(candidate)
                color_matches = (
                    candidate_color is not None
                    and local_color not in (None, "", "unknown")
                    and local_color == candidate_color
                )
                color_mismatches = (
                    candidate_color is not None
                    and local_color not in (None, "", "unknown")
                    and local_color != candidate_color
                )
                if color_mismatches:
                    # A pass with a strong local colour history must not be
                    # stolen by a close following plate of another colour.
                    continue
                if (
                    box_score is not None
                    and elapsed <= PASS_RECONNECT_BOX_GATE_SECONDS
                    and box_score > PASS_RECONNECT_BOX_SCORE_MAX
                    and not color_matches
                ):
                    continue
                # Distance remains the primary conveyor-motion signal.  The
                # production-style bbox score resolves nearby candidates.
                candidates.append(
                    (error, box_score if box_score is not None else math.inf,
                     -last_distance, pass_id, candidate)
                )
            if candidates:
                _error, _box_score, _neg_distance, mapped_pass_id, state = min(candidates)
                self.tracker_to_pass[tracker_id] = mapped_pass_id
                state["tracker_ids"].add(tracker_id)
            else:
                # A brand-new detection beyond the decision line is not a new
                # plate.  It is either an unmatched tail or an edge artefact.
                if distance >= DETECTION_END_CM:
                    return None
                state = self._new_pass(
                    tracker_id, distance, now, inference_index, box=box
                )

        if state.get("removal_suspected") and self.handoff is not None:
            self.handoff.revoke_local_removal(state)
        state["missing_since"] = None
        state["removal_suspected"] = False
        state["last_distance"] = max(float(state["last_distance"]), distance)
        state["min_distance"] = min(float(state["min_distance"]), distance)
        state["last_seen"] = now
        state["last_inference"] = inference_index
        if box is not None:
            state["last_box"] = box
        assigned_this_inference.add(int(state["pass_id"]))
        return state

    def _lock_pass_result(self, state: dict, inference_index: int) -> None:
        """Freeze the pass result on its first crossing of the decision line."""
        if state["decision_locked"]:
            return
        pass_id = int(state["pass_id"])
        rows = [row for row in self.rows if int(row["pass_id"]) == pass_id]
        state["decision_locked"] = True
        state["stage"] = "exit_candidate"
        state["final_observations"] = len(rows)
        if rows:
            votes = Counter(row["predicted_color"] for row in rows)
            state["final_color"] = votes.most_common(1)[0][0]
            state["final_confidence_median"] = float(
                np.median([float(row["confidence"]) for row in rows])
            )
        print(
            f"Pass P{pass_id} locked at {DETECTION_END_CM:g} cm: "
            f"color={state['final_color'] or 'none'} "
            f"observations={state['final_observations']}"
        )
        if self.handoff is not None:
            if self.external_expected:
                self.handoff.finalize_downstream(state)
            if self._publishes_downstream():
                publish_allowed = True
                if self.continuous_mode:
                    publish_allowed = (
                        int(state.get("final_observations", 0))
                        >= CONTINUOUS_MIN_PUBLISH_OBSERVATIONS
                        and float(state.get("min_distance", TRACK_LENGTH_CM))
                        <= CONTINUOUS_MAX_FIRST_DISTANCE_CM
                    )
                if publish_allowed:
                    if self.continuous_mode:
                        self.handoff.publish_final_plate(state)
                    else:
                        self.handoff.publish_locked_plate(state)
                else:
                    state["publish_rejected"] = True
                    print(
                        f"Pass P{pass_id} not published: entrance evidence "
                        f"is insufficient (observations={state['final_observations']}, "
                        f"first={state.get('min_distance')} cm)"
                    )

    def _publish_early_handoff(self, state: dict) -> None:
        """Announce a continuous-mode upstream plate after two stable votes."""
        if (
            self.handoff is None
            or not self._publishes_downstream()
            or not self.continuous_mode
            or state.get("decision_locked")
            or float(state.get("min_distance", TRACK_LENGTH_CM))
            > CONTINUOUS_MAX_FIRST_DISTANCE_CM
        ):
            return
        pass_id = int(state["pass_id"])
        rows = [row for row in self.rows if int(row["pass_id"]) == pass_id]
        if len(rows) < CONTINUOUS_MIN_PUBLISH_OBSERVATIONS:
            return
        recent = rows[-CONTINUOUS_MIN_PUBLISH_OBSERVATIONS:]
        colors = [str(row.get("predicted_color", "")) for row in recent]
        if not colors[0] or any(color != colors[0] for color in colors):
            return
        self.handoff.publish_detected_plate(
            state,
            colors[0],
            float(np.median([float(row["confidence"]) for row in rows])),
            len(rows),
        )

    def _finalize_missing_passes(
        self,
        visible_pass_ids: set[int],
        now: float,
        inference_index: int,
    ) -> None:
        """Finalize an exit/catch only after the normal reconnect window."""
        for pass_id, state in self.pass_states.items():
            if state["stage"] in {"exited", "caught"} or pass_id in visible_pass_ids:
                continue
            if state["missing_since"] is None:
                state["missing_since"] = now
            missing_seconds = now - float(state["last_seen"])
            if (
                self.handoff is not None
                and not state["decision_locked"]
                and missing_seconds >= REMOVAL_SUSPECT_SECONDS
                and not state.get("removal_suspected")
            ):
                state["removal_suspected"] = True
                self.handoff.suspect_local_removal(state)
            remaining_cm = max(
                0.0, DETECTION_END_CM - float(state.get("last_distance", 0.0))
            )
            dynamic_confirm_seconds = min(
                REMOVAL_CONFIRM_MAX_SECONDS,
                max(
                    REMOVAL_CONFIRM_MIN_SECONDS,
                    (remaining_cm / TRACK_SPEED_CM_PER_SECOND) * 0.35,
                ),
            )
            confirm_seconds = (
                dynamic_confirm_seconds
                if not state["decision_locked"]
                else PASS_RECONNECT_MAX_SECONDS
            )
            if missing_seconds <= confirm_seconds:
                continue
            state["stage"] = "exited" if state["decision_locked"] else "caught"
            if (
                self.handoff is not None
                and self.external_expected
                and not state["decision_locked"]
            ):
                self.handoff.finalize_downstream_removed(state)
            if (
                self.handoff is not None
                and self._publishes_downstream()
                and self.continuous_mode
                and not state["decision_locked"]
            ):
                self.handoff.publish_removed_plate(state)

    def _record_color_calibration(
        self,
        inference_index: int,
        instance: dict,
        color_image: np.ndarray,
    ) -> None:
        polygon = np.rint(instance["polygon"]).astype(np.int32)
        mask = np.zeros(color_image.shape[:2], dtype=np.uint8)
        cv2.fillPoly(mask, [polygon], 255)
        x, y, width, height = cv2.boundingRect(polygon)
        erosion = max(1, int(round(min(width, height) * 0.06)))
        kernel_size = max(3, erosion * 2 + 1)
        kernel = cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE, (kernel_size, kernel_size)
        )
        inner_mask = cv2.erode(mask, kernel, iterations=1)
        if np.count_nonzero(inner_mask) < MIN_COLOR_PIXELS:
            inner_mask = mask

        hls = cv2.cvtColor(color_image, cv2.COLOR_BGR2HLS)
        lab = cv2.cvtColor(color_image, cv2.COLOR_BGR2LAB)
        hue, lightness, saturation = cv2.split(hls)
        sample = (
            (inner_mask > 0)
            & (saturation >= MIN_COLOR_SATURATION)
            & (lightness >= MIN_COLOR_LIGHTNESS)
            & (lightness <= MAX_COLOR_LIGHTNESS)
        )
        sample_count = int(np.count_nonzero(sample))
        if sample_count < MIN_COLOR_PIXELS:
            return

        hue_values = hue[sample].astype(np.float32)
        lightness_values = lightness[sample].astype(np.float32)
        saturation_values = saturation[sample].astype(np.float32)
        a_values = lab[:, :, 1][sample].astype(np.float32)
        b_values = lab[:, :, 2][sample].astype(np.float32)
        self.color_samples.append(
            {
                "inference_index": inference_index,
                "tracker_id": int(instance["tracker_id"]),
                "pass_id": int(instance["pass_id"]),
                "lap_id": int(instance["lap_id"]),
                "distance_cm": round(float(instance["distance_cm"]), 3),
                "distance_bin_start_cm": round(
                    distance_bin_start(float(instance["distance_cm"])), 1
                ),
                "expected_color": str(instance["expected_color"]),
                "predicted_color": str(instance.get("stable_color", "unknown")),
                "confidence": round(float(instance["confidence"]), 6),
                "sample_pixels": sample_count,
                "h_p10": round(float(np.percentile(hue_values, 10)), 3),
                "h_median": round(float(np.median(hue_values)), 3),
                "h_p90": round(float(np.percentile(hue_values, 90)), 3),
                "l_median": round(float(np.median(lightness_values)), 3),
                "s_median": round(float(np.median(saturation_values)), 3),
                "lab_a_median": round(float(np.median(a_values)), 3),
                "lab_b_median": round(float(np.median(b_values)), 3),
            }
        )

