"""Focused SelfCheckRecorder behavior."""

from __future__ import annotations

import csv
import time
from collections import Counter, defaultdict

import numpy as np

from .self_check_context import (
    BASELINE_MIN_OBSERVATIONS,
    DETECTION_START_CM,
    EXPECTED_COLOR_SEQUENCE,
    PLANNED_PASSES,
)


class SelfCheckReportingMixin:
    def summary_lines(self) -> list[str]:
        metrics = self.metrics()
        stable = [row for row in metrics if row["status"] == "stable"]
        farthest = max((row["distance_end_cm"] for row in stable), default=None)
        unique_tracks = len({row["tracker_id"] for row in self.rows})
        result = [
            f"lap={self.current_lap_id} passes={len(self.pass_states)}/{PLANNED_PASSES} "
            f"observations={len(self.rows)} tracks={unique_tracks}",
            (
                "Q=quit R=ROI S=save continuous unknown test A=photo"
                if self.continuous_mode else
                "Q=quit R=ROI S=save B=start O-G-Y test A=photo"
            ),
            (
                "continuous=ACTIVE (unknown count/color)"
                if self.continuous_mode else
                "color test=ACTIVE (O>G>Y)"
                if self.evaluation_active else
                "color test=WAITING - press B before ORANGE enters"
            ),
            f"stable boundary={f'{farthest:.0f} cm' if farthest is not None else 'collecting'}",
        ]
        for row in reversed(metrics):
            if row["observations"] == 0:
                continue
            p10 = row["confidence_p10"]
            accuracy = row["pass_color_accuracy"]
            result.append(
                f"{row['distance_start_cm']:.0f}-{row['distance_end_cm']:.0f}cm "
                f"pass={row['correct_passes']}/{row['detected_passes']} p10={p10:.2f} "
                f"acc={accuracy:.1%} {row['status']}"
                if accuracy is not None else
                f"{row['distance_start_cm']:.0f}-{row['distance_end_cm']:.0f}cm "
                f"n={row['observations']} p10={p10:.2f} acc=-- {row['status']}"
            )
            if len(result) >= 7:
                break
        return result

    def analysis_markdown(self, metrics: list[dict], pass_results: list[dict]) -> str:
        """Build a readable analysis for the latest B-started evaluation cycle."""
        observations = len(self.rows)
        inference_times = {}
        for row in self.rows:
            inference_times.setdefault(
                int(row["inference_index"]), float(row["session_s"])
            )
        ordered_times = np.asarray(
            [inference_times[key] for key in sorted(inference_times)],
            dtype=float,
        )
        intervals = np.diff(ordered_times)
        valid_intervals = intervals[intervals > 0]
        mean_fps = (
            float(1.0 / np.mean(valid_intervals))
            if valid_intervals.size else None
        )
        median_fps = (
            float(1.0 / np.median(valid_intervals))
            if valid_intervals.size else None
        )
        duration = (
            float(ordered_times[-1] - ordered_times[0])
            if ordered_times.size >= 2 else 0.0
        )

        bin_counts = np.asarray(
            [int(row["observation_count"]) for row in pass_results],
            dtype=float,
        )
        mean_per_bin = float(np.mean(bin_counts)) if bin_counts.size else 0.0
        median_per_bin = float(np.median(bin_counts)) if bin_counts.size else 0.0

        pass_groups = defaultdict(list)
        for row in pass_results:
            pass_groups[int(row["pass_id"])].append(row)

        color_totals = Counter()
        color_correct = Counter()
        color_predictions = defaultdict(Counter)
        for row in self.rows:
            expected = str(row.get("expected_color", ""))
            predicted = str(row.get("predicted_color", "unknown"))
            if expected:
                color_totals[expected] += 1
                color_predictions[expected][predicted] += 1
                color_correct[expected] += int(predicted == expected)

        anomaly_counts = Counter()
        anomaly_rows = 0
        anomaly_file = self.directory / "anomaly_captures" / "anomalies.csv"
        first_inference = min(
            (int(row["inference_index"]) for row in self.rows),
            default=None,
        )
        if anomaly_file.exists():
            with anomaly_file.open("r", newline="", encoding="utf-8-sig") as handle:
                for anomaly in csv.DictReader(handle):
                    inference_index = int(anomaly.get("inference_index") or 0)
                    if first_inference is not None and inference_index < first_inference:
                        continue
                    anomaly_rows += 1
                    for reason in str(anomaly.get("reason", "")).split(";"):
                        if reason:
                            anomaly_counts[reason.split(":", 1)[0]] += 1

        identified_passes = len(self.pass_states)
        lap_ids = sorted(
            {
                int(row.get("lap_id") or 1)
                for row in pass_results
            }
        )

        lines = [
            "# 盤子距離自檢自動分析",
            "",
            f"產生時間：{time.strftime('%Y-%m-%d %H:%M:%S')}",
            "",
            "## 測試概況",
            "",
            "| 項目 | 結果 |",
            "|---|---:|",
            f"| 圈數 | {len(lap_ids)} |",
            f"| 盤次 | {identified_passes} / {PLANNED_PASSES} |",
            f"| observation | {observations} |",
            f"| 有效推論 frame | {len(inference_times)} |",
            f"| 記錄時間 | {duration:.2f} 秒 |",
            f"| 平均有效 FPS | {mean_fps:.2f} |" if mean_fps else "| 平均有效 FPS | 無法計算 |",
            f"| 中位有效 FPS | {median_fps:.2f} |" if median_fps else "| 中位有效 FPS | 無法計算 |",
            f"| 每盤每 10 cm 平均 observation | {mean_per_bin:.2f} |",
            f"| 每盤每 10 cm 中位 observation | {median_per_bin:.1f} |",
            "",
            "## 顏色結果",
            "",
            "| 預期顏色 | 正確 / 總數 | observation 正確率 | 預測分布 |",
            "|---|---:|---:|---|",
        ]
        for color in EXPECTED_COLOR_SEQUENCE:
            total = int(color_totals[color])
            correct = int(color_correct[color])
            accuracy = correct / total if total else None
            distribution = ", ".join(
                f"{name}={count}"
                for name, count in color_predictions[color].most_common()
            ) or "無資料"
            accuracy_text = f"{accuracy:.1%}" if accuracy is not None else "無資料"
            lines.append(
                f"| {color} | {correct} / {total} | {accuracy_text} | {distribution} |"
            )

        lines.extend([
            "",
            "## 每圈結果",
            "",
            "| Lap ID | Plate IDs | 盤數 | 正確區間 / 總區間 | 區間顏色正確率 |",
            "|---:|---|---:|---:|---:|",
        ])
        for lap_id in lap_ids:
            lap_rows = [
                row for row in pass_results
                if int(row.get("lap_id") or 1) == lap_id
            ]
            plate_ids = sorted({int(row["pass_id"]) for row in lap_rows})
            evaluated_lap_rows = [
                row for row in lap_rows if row.get("expected_color")
            ]
            correct_bins = sum(
                int(row["color_correct"]) for row in evaluated_lap_rows
            )
            total_bins = len(evaluated_lap_rows)
            accuracy_text = (
                f"{correct_bins / total_bins:.1%}" if total_bins else "無資料"
            )
            lines.append(
                f"| {lap_id} | {', '.join(map(str, plate_ids)) or '無'} "
                f"| {len(plate_ids)} | {correct_bins} / {total_bins} "
                f"| {accuracy_text} |"
            )

        lines.extend(["", "## 每個盤次", ""])
        for pass_id, rows in sorted(pass_groups.items()):
            lap_id = int(rows[0].get("lap_id") or 1)
            expected = str(rows[0]["expected_color"])
            evaluated_rows = [row for row in rows if row.get("expected_color")]
            bins = len(evaluated_rows)
            correct_bins = sum(int(row["color_correct"]) for row in evaluated_rows)
            first_cm = min(float(row["distance_bin_start_cm"]) for row in rows)
            last_cm = max(float(row["distance_bin_end_cm"]) for row in rows)
            lines.append(
                f"- L{lap_id} / P{pass_id} `{expected}`："
                f"{correct_bins}/{bins} 個區間正確，"
                f"觀測範圍 {first_cm:.0f}～{last_cm:.0f} cm。"
            )
        if not pass_groups:
            lines.append("- 尚未取得盤次資料。")

        lines.extend([
            "",
            "## 每 10 cm 結果",
            "",
            "| 距離 | observations | detected passes | correct passes | confidence p10 | confidence 中位數 | 狀態 |",
            "|---|---:|---:|---:|---:|---:|---|",
        ])
        for row in metrics:
            p10 = row["confidence_p10"]
            median = row["confidence_median"]
            lines.append(
                f"| {row['distance_start_cm']:.0f}～{row['distance_end_cm']:.0f} cm "
                f"| {row['observations']} | {row['detected_passes']} "
                f"| {row['correct_passes']} "
                f"| {p10:.3f}" if p10 is not None else
                f"| {row['distance_start_cm']:.0f}～{row['distance_end_cm']:.0f} cm "
                f"| {row['observations']} | {row['detected_passes']} "
                f"| {row['correct_passes']} | 無資料"
            )
            lines[-1] += (
                f" | {median:.3f} | {row['status']} |"
                if median is not None else
                f" | 無資料 | {row['status']} |"
            )

        range_rows = []
        pass_observation_totals = Counter()
        for result in pass_results:
            pass_observation_totals[int(result["pass_id"])] += int(
                result.get("observation_count", 0)
            )
        baseline_pass_ids = sorted(
            {
                int(row["pass_id"])
                for row in pass_results
                if float(row["distance_bin_start_cm"])
                == round(DETECTION_START_CM, 1)
                and pass_observation_totals[int(row["pass_id"])]
                >= BASELINE_MIN_OBSERVATIONS
            }
        )
        if identified_passes:
            for row in metrics:
                range_ok = bool(row["continuous_range_qualified"])
                range_rows.append((row, range_ok))

        qualified_range_rows = [item for item in range_rows if item[1]]
        provisional_end = max(
            (
                float(row["distance_end_cm"])
                for row, _ in qualified_range_rows
            ),
            default=None,
        )
        recommended_end = provisional_end
        first_failed_row = next(
            (row for row in metrics if not row["continuous_range_qualified"]),
            None,
        )

        lines.extend([
            "",
            "## 實際可辨識範圍判定",
            "",
            "判定規則：以 5～15 cm 出現的 pass_id 為基準。暫時漏失的 ID 若在後段 "
            "以相同 pass_id 且正確顏色重新出現，視為成功接回；只有未接回、出現額外 "
            "ID 或顏色錯誤才判定失敗。第一次不可恢復的失敗後停止延伸可辨識範圍。",
            "Observation 數與 confidence 只作為參考，不決定可辨識範圍。",
            "",
            "| 距離 | 出現 Plate ID | 缺少 ID | 多餘 ID | 後續可接回 ID | 本段接回 ID | ID 集合一致 | 顏色一致盤數 | 顏色一致率 | 恢復後範圍判定 |",
            "|---|---|---|---|---|---|---|---:|---:|---|",
        ])
        previous_missing_ids: set[int] = set()
        for row, range_ok in range_rows:
            bin_start = float(row["distance_start_cm"])
            present_ids = sorted(
                {
                    int(item["pass_id"])
                    for item in pass_results
                    if float(item["distance_bin_start_cm"]) == bin_start
                    and pass_observation_totals[int(item["pass_id"])]
                    >= BASELINE_MIN_OBSERVATIONS
                }
            )
            missing_ids = [
                pass_id for pass_id in baseline_pass_ids
                if pass_id not in present_ids
            ]
            extra_ids = [
                pass_id for pass_id in present_ids
                if pass_id not in baseline_pass_ids
            ]
            recovered_ids = sorted(previous_missing_ids & set(present_ids))
            present_text = ", ".join(map(str, present_ids)) or "無"
            missing_text = ", ".join(map(str, missing_ids)) or "無"
            extra_text = ", ".join(map(str, extra_ids)) or "無"
            recovered_text = ", ".join(map(str, recovered_ids)) or "無"
            future_recovered_text = (
                str(row.get("recovered_pass_ids", "")).replace(" ", ", ")
                or "無"
            )
            color_consistency = row["plate_color_consistency"]
            color_text = (
                f"{color_consistency:.1%}"
                if color_consistency is not None else "無資料"
            )
            lines.append(
                f"| {row['distance_start_cm']:.0f}～{row['distance_end_cm']:.0f} cm "
                f"| {present_text} | {missing_text} | {extra_text} "
                f"| {future_recovered_text} | {recovered_text} "
                f"| {'是' if row['plate_id_continuity'] else '否'} "
                f"| {row['color_consistent_passes']} | {color_text} "
                f"| {'合格' if range_ok else '不合格'} |"
            )
            previous_missing_ids = set(missing_ids)
        lines.append("")
        if provisional_end is None:
            lines.append("- 從第一個正式區間開始就沒有形成連續可辨識範圍。")
        else:
            lines.append(f"- 連續可辨識範圍：5～{recommended_end:.0f} cm。")
        if first_failed_row is not None:
            lines.append(
                f"- 第一次失敗區間：{first_failed_row['distance_start_cm']:.0f}～"
                f"{first_failed_row['distance_end_cm']:.0f} cm；"
                f"未接回漏盤 {first_failed_row['unrecovered_missing_passes']}、"
                f"額外 ID {first_failed_row['extra_pass_ids']}、"
                f"顏色一致 {first_failed_row['color_consistent_passes']}/"
                f"{first_failed_row['baseline_passes']} 盤。"
            )
        if identified_passes < PLANNED_PASSES:
            lines.append(
                f"- 目前只有 {identified_passes} 盤，尚未達規劃的 {PLANNED_PASSES} 盤；"
                "此結果只能作為暫定範圍，完成全部盤次後再定案。"
            )

        lines.extend([
            "",
            "## 異常截圖",
            "",
            f"本次評估週期共保存 {anomaly_rows} 張異常照片。",
            "",
        ])
        if anomaly_counts:
            for reason, count in anomaly_counts.most_common():
                lines.append(f"- `{reason}`：{count}")
        else:
            lines.append("- 沒有異常事件，或尚未產生異常 metadata。")

        lines.extend(["", "## 自動判讀", ""])
        if observations == 0:
            lines.append("- 尚無有效 observation，不能判斷距離或顏色表現。")
        else:
            if recommended_end is not None:
                lines.append(
                    f"- 依固定 pass_id、暫時漏失後可用同一 ID 接回、無額外 ID "
                    f"與盤級顏色一致性判定，"
                    f"連續可辨識範圍為 5～{recommended_end:.0f} cm。"
                )
            else:
                lines.append("- 目前沒有形成連續可辨識範圍。")
            for color in EXPECTED_COLOR_SEQUENCE:
                total = int(color_totals[color])
                if not total:
                    lines.append(f"- `{color}` 沒有資料。")
                    continue
                accuracy = color_correct[color] / total
                lines.append(
                    f"- `{color}` observation 正確率為 {accuracy:.1%}。"
                )
            if anomaly_counts["wrong_color"]:
                lines.append(
                    "- 主要異常包含錯色；應先確認顏色分類使用的影像與色域，再依此批資料調整 ROI。"
                )
            if anomaly_counts["low_confidence"]:
                lines.append(
                    "- 有低信心事件；請查看 anomaly_captures 中相同編號的 annotated 與 processed 圖片。"
                )
            lines.append(
                "- 這是自動摘要；正式偽陽率仍需要有明確標記的空軌道 frame 作為分母。"
            )

        lines.extend([
            "",
            "## 資料檔案",
            "",
            "- `distance_detections.csv`：逐次 observation",
            "- `pass_distance_results.csv`：每盤每 10 cm 多數決",
            "- `distance_metrics.csv`：每 10 cm 彙總",
            "- `anomaly_captures/anomalies.csv`：異常照片索引",
            "- `color_calibration.csv`：逐 observation HLS／Lab 量測",
            "- `color_calibration_suggestions.md`：自動色域建議",
            "",
        ])
        return "\n".join(lines)

