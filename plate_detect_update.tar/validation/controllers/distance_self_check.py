"""Public entry point for distance self-check and color calibration."""

from .self_check_context import (
    BASELINE_MIN_OBSERVATIONS,
    BIN_SIZE_CM,
    DETECTION_END_CM,
    DETECTION_START_CM,
    PASS_RECONNECT_MAX_SECONDS,
    PROJECT_ROOT,
    REQUIRED_DETECTION_LENGTH_CM,
    TRACK_LENGTH_CM,
    normalize_operational_colors,
    parse_args,
)
from .self_check_recorder import SelfCheckRecorder
from .self_check_runtime import main

__all__ = [
    "BASELINE_MIN_OBSERVATIONS",
    "BIN_SIZE_CM",
    "DETECTION_END_CM",
    "DETECTION_START_CM",
    "PASS_RECONNECT_MAX_SECONDS",
    "PROJECT_ROOT",
    "REQUIRED_DETECTION_LENGTH_CM",
    "SelfCheckRecorder",
    "TRACK_LENGTH_CM",
    "main",
    "normalize_operational_colors",
    "parse_args",
]
