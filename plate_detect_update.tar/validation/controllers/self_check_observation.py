"""Focused SelfCheckRecorder behavior."""

from __future__ import annotations

import time
from collections import Counter, defaultdict

import numpy as np

from .self_check_context import (
    BASELINE_MIN_OBSERVATIONS,
    BIN_SIZE_CM,
    CONTINUOUS_MAX_FIRST_DISTANCE_CM,
    DETECTION_END_CM,
    DETECTION_START_CM,
    EXPECTED_COLOR_SEQUENCE,
    MAX_TRACK_GAP_RATE,
    MIN_COLOR_ACCURACY,
    MIN_CONFIDENCE_P10,
    MIN_OBSERVATIONS_PER_BIN,
    PASS_RECONNECT_COLOR_MIN_CONFIDENCE,
    PLANNED_PASSES,
    TRACK_LENGTH_CM,
    distance_bin_end,
    distance_bin_start,
)


class SelfCheckObservationMixin:
    def record(
        self,
        inference_index: int,
        instances: list[dict],
        color_image: np.ndarray,
    ) -> None:
        # Do not create misleading observations before the operator aligns the
        # known O-G-Y sequence and explicitly starts the test with B.
        if not self.evaluation_active:
            return
        now = time.perf_counter() - self.started
        assigned_this_inference = set()
        ordered_instances = sorted(
            instances,
            key=lambda item: (
                int(item["tracker_id"]) not in self.tracker_to_pass,
                -float(item["distance_cm"]),
            ),
        )
        for instance in ordered_instances:
            distance = float(instance["distance_cm"])
            bin_start = distance_bin_start(distance)
            tracker_id = int(instance["tracker_id"])
            confidence = float(instance["confidence"])
            raw_box = instance.get("xyxy")
            box = (
                tuple(float(value) for value in raw_box)
                if raw_box is not None
                else None
            )
            pass_state = self._assign_pass(
                tracker_id,
                distance,
                now,
                inference_index,
                assigned_this_inference,
                box=box,
                local_color=str(instance.get("stable_color", "unknown")),
            )
            if pass_state is None:
                instance["measurement_phase"] = "exit_buffer_unmatched"
                continue
            pass_id = int(pass_state["pass_id"])
            lap_id = int(pass_state["lap_id"])
            expected_color = str(pass_state["expected_color"])
            if (
                self.handoff is not None
                and self.external_expected
                and not expected_color
            ):
                upstream_color = self.handoff.match_downstream_entry(pass_state)
                if upstream_color:
                    pass_state["expected_color"] = upstream_color
                    expected_color = upstream_color
                    binding = self.handoff.downstream_binding(pass_id)
                    if binding is not None:
                        pass_state["upstream_pass_id"] = binding.get(
                            "upstream_pass_id"
                        )
                        pass_state["upstream_sequence"] = binding.get("sequence")
                        pass_state["upstream_published_at"] = binding.get("timestamp")
                        pass_state["mqtt_received_at"] = binding.get("received_at")
            # Match the inbound edge first so the same handoff_id can be
            # relayed immediately to this camera's downstream neighbour.
            if (
                self.handoff is not None
                and self._publishes_downstream()
                and self.continuous_mode
                and float(pass_state.get("min_distance", TRACK_LENGTH_CM))
                <= CONTINUOUS_MAX_FIRST_DISTANCE_CM
            ):
                provisional_color = str(
                    instance.get("stable_color", "unknown") or "unknown"
                )
                if (
                    provisional_color != "unknown"
                    and confidence >= PASS_RECONNECT_COLOR_MIN_CONFIDENCE
                ):
                    self.handoff.publish_detected_plate(
                        pass_state, provisional_color, confidence, 1
                    )
            instance["pass_id"] = pass_id
            instance["lap_id"] = lap_id
            instance["expected_color"] = expected_color
            if distance < DETECTION_START_CM:
                instance["measurement_phase"] = "entry_buffer"
                continue
            if distance >= DETECTION_END_CM:
                instance["measurement_phase"] = "exit_buffer"
                self._lock_pass_result(pass_state, inference_index)
                continue
            if pass_state["decision_locked"]:
                instance["measurement_phase"] = "exit_buffer_locked"
                continue
            if not pass_state["measurement_started"]:
                pass_state["measurement_started"] = True
                pass_state["stage"] = "entered"
            instance["measurement_phase"] = "decision"
            predicted_color = instance.get("stable_color", "unknown")
            if (
                predicted_color
                and predicted_color != "unknown"
                and confidence >= PASS_RECONNECT_COLOR_MIN_CONFIDENCE
            ):
                pass_state["local_color_votes"][str(predicted_color)] += 1
            if (
                self.handoff is not None
                and self.external_expected
                and not self._publishes_downstream()
            ):
                stable_local_color = self._stable_local_color(pass_state)
                if stable_local_color:
                    self.handoff.publish_downstream_entry(
                        pass_state, stable_local_color
                    )
            color_correct = (
                int(predicted_color == expected_color) if expected_color else ""
            )
            previous = self.last_seen_inference.get(tracker_id)
            if previous is not None and inference_index - previous > 1:
                self.tracker_gaps[bin_start] += 1
            self.last_seen_inference[tracker_id] = inference_index
            self.tracker_observations[bin_start] += 1
            self.by_bin[bin_start].append(confidence)
            self.bin_tracker_ids[bin_start].add(tracker_id)
            self.rows.append(
                {
                    "session_s": round(now, 4),
                    "wall_timestamp": time.time(),
                    "inference_index": inference_index,
                    "tracker_id": tracker_id,
                    "pass_id": pass_id,
                    "lap_id": lap_id,
                    "distance_cm": round(distance, 3),
                    "distance_bin_start_cm": round(bin_start, 1),
                    "distance_bin_end_cm": round(distance_bin_end(bin_start), 1),
                    "confidence": round(confidence, 6),
                    "predicted_color": predicted_color,
                    "current_color": instance.get("current_color", "unknown"),
                    "raw_predicted_color": instance.get(
                        "raw_stable_color", predicted_color
                    ),
                    "raw_current_color": instance.get(
                        "raw_current_color",
                        instance.get("current_color", "unknown"),
                    ),
                    "expected_color": expected_color,
                    "upstream_pass_id": pass_state.get("upstream_pass_id", ""),
                    "upstream_sequence": pass_state.get("upstream_sequence", ""),
                    "upstream_published_at": pass_state.get(
                        "upstream_published_at", ""
                    ),
                    "mqtt_received_at": pass_state.get("mqtt_received_at", ""),
                    "color_correct": color_correct,
                }
            )
            self._publish_early_handoff(pass_state)
            self._record_color_calibration(
                inference_index, instance, color_image
            )
        self._finalize_missing_passes(
            {int(value) for value in assigned_this_inference},
            now,
            inference_index,
        )

    def pass_bin_results(self) -> list[dict]:
        grouped = defaultdict(list)
        for row in self.rows:
            grouped[(int(row["pass_id"]), float(row["distance_bin_start_cm"]))].append(row)
        results = []
        for (pass_id, bin_start), rows in sorted(grouped.items()):
            votes = Counter(row["predicted_color"] for row in rows)
            majority_color, majority_count = votes.most_common(1)[0]
            expected_color = rows[0]["expected_color"]
            confidences = [float(row["confidence"]) for row in rows]
            results.append(
                {
                    "pass_id": pass_id,
                    "lap_id": int(rows[0]["lap_id"]),
                    "expected_color": expected_color,
                    "distance_bin_start_cm": bin_start,
                    "distance_bin_end_cm": distance_bin_end(bin_start),
                    "observation_count": len(rows),
                    "majority_color": majority_color,
                    "majority_count": majority_count,
                    "majority_ratio": round(majority_count / len(rows), 5),
                    "color_correct": (
                        int(majority_color == expected_color)
                        if expected_color else ""
                    ),
                    "confidence_median": round(float(np.median(confidences)), 5),
                    "tracker_ids": " ".join(
                        str(value)
                        for value in sorted({int(row["tracker_id"]) for row in rows})
                    ),
                }
            )
        return results

    def metrics(self) -> list[dict]:
        metrics = []
        pass_results = self.pass_bin_results()
        def color_ok(row):
            value = row.get("color_correct", "")
            return True if value in ("", None) else bool(int(value))
        identified_passes = len(self.pass_states)
        baseline_results = [
            row for row in pass_results
            if row["distance_bin_start_cm"] == round(DETECTION_START_CM, 1)
        ]
        # A one-frame entrance artefact is not a physical reference plate.
        # Requiring repeat observations stops that transient ID from making
        # every later 10 cm segment fail continuity.
        pass_observation_totals = Counter(
            int(row["pass_id"]) for row in self.rows
        )
        baseline_pass_ids = {
            int(row["pass_id"])
            for row in baseline_results
            if pass_observation_totals[int(row["pass_id"])]
            >= BASELINE_MIN_OBSERVATIONS
        }
        continuous_range = bool(baseline_pass_ids)
        distance = DETECTION_START_CM
        while distance < DETECTION_END_CM - 1e-6:
            confidences = np.asarray(self.by_bin.get(distance, []), dtype=float)
            observations = int(confidences.size)
            gaps = int(self.tracker_gaps.get(distance, 0))
            gap_rate = gaps / max(1, self.tracker_observations.get(distance, 0))
            evaluated_rows = [
                row for row in self.rows
                if row["distance_bin_start_cm"] == round(distance, 1)
                and row["expected_color"]
            ]
            color_total = len(evaluated_rows)
            color_correct = sum(int(row["color_correct"]) for row in evaluated_rows)
            color_accuracy = color_correct / color_total if color_total else None
            bin_pass_results = [
                row for row in pass_results
                if row["distance_bin_start_cm"] == round(distance, 1)
                and pass_observation_totals[int(row["pass_id"])]
                >= BASELINE_MIN_OBSERVATIONS
            ]
            detected_passes = len(bin_pass_results)
            evaluated_pass_results = [
                row for row in bin_pass_results if row.get("expected_color")
            ]
            correct_passes = sum(
                int(row["color_correct"]) for row in evaluated_pass_results
            )
            bin_by_pass = {
                int(row["pass_id"]): row for row in bin_pass_results
            }
            bin_pass_ids = set(bin_by_pass)
            missing_baseline_ids = baseline_pass_ids - bin_pass_ids
            extra_pass_ids = bin_pass_ids - baseline_pass_ids
            same_plate_ids = (
                bool(baseline_pass_ids)
                and not missing_baseline_ids
                and not extra_pass_ids
            )
            color_consistent_passes = sum(
                int(color_ok(bin_by_pass[pass_id]))
                for pass_id in baseline_pass_ids & bin_pass_ids
            )
            all_plate_colors_consistent = (
                bool(baseline_pass_ids)
                and color_consistent_passes == len(baseline_pass_ids)
            )
            range_qualified = same_plate_ids and all_plate_colors_consistent
            continuous_range = continuous_range and range_qualified
            pass_accuracy = (
                correct_passes / len(evaluated_pass_results)
                if evaluated_pass_results else None
            )
            per_color = {}
            for color in EXPECTED_COLOR_SEQUENCE:
                color_rows = [
                    row for row in evaluated_rows if row["expected_color"] == color
                ]
                correct = sum(int(row["color_correct"]) for row in color_rows)
                per_color[color] = (
                    correct / len(color_rows) if color_rows else None
                )
            p10 = float(np.percentile(confidences, 10)) if observations else None
            median = float(np.median(confidences)) if observations else None
            p90 = float(np.percentile(confidences, 90)) if observations else None
            if observations < MIN_OBSERVATIONS_PER_BIN:
                status = "insufficient"
            elif color_total and color_accuracy < MIN_COLOR_ACCURACY:
                status = "unstable"
            elif p10 is not None and p10 < MIN_CONFIDENCE_P10:
                status = "unstable"
            elif gap_rate > MAX_TRACK_GAP_RATE:
                status = "unstable"
            else:
                status = "stable"
            metrics.append(
                {
                    "distance_start_cm": round(distance, 1),
                    "distance_end_cm": round(distance_bin_end(distance), 1),
                    "observations": observations,
                    "unique_tracker_ids": len(self.bin_tracker_ids.get(distance, set())),
                    "confidence_p10": round(p10, 5) if p10 is not None else None,
                    "confidence_median": round(median, 5) if median is not None else None,
                    "confidence_p90": round(p90, 5) if p90 is not None else None,
                    "color_correct": color_correct,
                    "color_total": color_total,
                    "color_accuracy": (
                        round(color_accuracy, 5) if color_accuracy is not None else None
                    ),
                    "planned_passes": PLANNED_PASSES,
                    "identified_passes": identified_passes,
                    "detected_passes": detected_passes,
                    "missing_identified_passes": max(0, identified_passes - detected_passes),
                    "correct_passes": correct_passes,
                    "baseline_passes": len(baseline_pass_ids),
                    "missing_baseline_passes": len(missing_baseline_ids),
                    "extra_pass_ids": len(extra_pass_ids),
                    "plate_id_continuity": int(same_plate_ids),
                    "color_consistent_passes": color_consistent_passes,
                    "plate_color_consistency": (
                        round(
                            color_consistent_passes / len(baseline_pass_ids), 5
                        )
                        if baseline_pass_ids else None
                    ),
                    "range_qualified": int(range_qualified),
                    "continuous_range_qualified": int(continuous_range),
                    "pass_color_accuracy": (
                        round(pass_accuracy, 5) if pass_accuracy is not None else None
                    ),
                    "pass_success_vs_planned": round(correct_passes / PLANNED_PASSES, 5),
                    "orange_accuracy": (
                        round(per_color["orange"], 5)
                        if per_color["orange"] is not None else None
                    ),
                    "green_accuracy": (
                        round(per_color["light_green"], 5)
                        if per_color["light_green"] is not None else None
                    ),
                    "yellow_accuracy": (
                        round(per_color["yellow"], 5)
                        if per_color["yellow"] is not None else None
                    ),
                    "track_gap_count": gaps,
                    "track_gap_rate": round(gap_rate, 5),
                    "status": status,
                }
            )
            distance += BIN_SIZE_CM
        # A temporary missing bin is recoverable when the same persistent
        # pass_id reappears later with the correct plate color.  This preserves
        # end-to-end continuity while still exposing the blind interval.
        recoverable_continuity = bool(baseline_pass_ids)
        for index, metric in enumerate(metrics):
            bin_start = float(metric["distance_start_cm"])
            current_results = {
                int(row["pass_id"]): row
                for row in pass_results
                if float(row["distance_bin_start_cm"]) == bin_start
                and pass_observation_totals[int(row["pass_id"])]
                >= BASELINE_MIN_OBSERVATIONS
            }
            current_ids = set(current_results)
            missing_ids = baseline_pass_ids - current_ids
            extra_ids = current_ids - baseline_pass_ids
            recovered_ids = set()
            for missing_id in missing_ids:
                later = [
                    row for row in pass_results
                    if int(row["pass_id"]) == missing_id
                    and float(row["distance_bin_start_cm"]) > bin_start
                ]
                if later and all(color_ok(row) for row in later):
                    recovered_ids.add(missing_id)
            unrecovered_ids = missing_ids - recovered_ids
            present_colors_correct = all(
                color_ok(current_results[pass_id])
                for pass_id in baseline_pass_ids & current_ids
            )
            recoverable_ok = (
                bool(baseline_pass_ids)
                and not extra_ids
                and not unrecovered_ids
                and present_colors_correct
            )
            recoverable_continuity = recoverable_continuity and recoverable_ok
            metric["recovered_passes"] = len(recovered_ids)
            metric["recovered_pass_ids"] = " ".join(
                str(value) for value in sorted(recovered_ids)
            )
            metric["unrecovered_missing_passes"] = len(unrecovered_ids)
            metric["unrecovered_missing_pass_ids"] = " ".join(
                str(value) for value in sorted(unrecovered_ids)
            )
            metric["recoverable_range_qualified"] = int(recoverable_ok)
            metric["continuous_range_qualified"] = int(recoverable_continuity)
        return metrics

