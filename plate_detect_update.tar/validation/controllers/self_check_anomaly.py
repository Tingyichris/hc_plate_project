"""Anomaly image capture for self-check sessions."""

from __future__ import annotations

import csv
import json
import time
from pathlib import Path

import cv2
import numpy as np

from .self_check_context import (
    ANOMALY_CAPTURE_COOLDOWN_SECONDS,
    ANOMALY_LOW_CONFIDENCE,
    ANOMALY_MAX_EXPECTED_INSTANCES,
)

class AnomalyCapture:
    """Save annotated and processed evidence for suspicious frames."""

    def __init__(self, session_directory: Path):
        self.directory = session_directory / "anomaly_captures"
        self.directory.mkdir(parents=True, exist_ok=True)
        self.metadata_file = self.directory / "anomalies.csv"
        self.seen_trackers: set[int] = set()
        self.last_color_by_pass: dict[int, str] = {}
        self.last_automatic_save = -1e9
        self.capture_count = 0

    def reset_tracking_state(self) -> None:
        self.seen_trackers.clear()
        self.last_color_by_pass.clear()
        self.last_automatic_save = -1e9

    @staticmethod
    def _instance_summary(instances: list[dict]) -> str:
        summary = [
            {
                "pass_id": instance.get("pass_id"),
                "tracker_id": int(instance["tracker_id"]),
                "distance_cm": round(float(instance.get("distance_cm", 0.0)), 2),
                "confidence": round(float(instance["confidence"]), 4),
                "color": str(instance.get("stable_color", "unknown")),
            }
            for instance in instances
        ]
        return json.dumps(summary, ensure_ascii=False, separators=(",", ":"))

    def _save(
        self,
        reason: str,
        inference_index: int,
        annotated_frame: np.ndarray,
        model_input: np.ndarray,
        instances: list[dict],
    ) -> None:
        self.capture_count += 1
        stamp = time.strftime("%Y%m%d_%H%M%S")
        base = f"{stamp}_{self.capture_count:04d}_f{inference_index:06d}"
        annotated_name = f"{base}_annotated.png"
        processed_name = f"{base}_processed.png"
        annotated_path = self.directory / annotated_name
        processed_path = self.directory / processed_name
        if not cv2.imwrite(str(annotated_path), annotated_frame):
            raise RuntimeError(f"Cannot save anomaly image: {annotated_path}")
        if not cv2.imwrite(str(processed_path), model_input):
            raise RuntimeError(f"Cannot save anomaly image: {processed_path}")

        write_header = not self.metadata_file.exists()
        with self.metadata_file.open("a", newline="", encoding="utf-8-sig") as handle:
            writer = csv.DictWriter(
                handle,
                fieldnames=[
                    "capture_index", "inference_index", "reason",
                    "annotated_image", "processed_image",
                    "detection_count", "instances",
                ],
            )
            if write_header:
                writer.writeheader()
            writer.writerow(
                {
                    "capture_index": self.capture_count,
                    "inference_index": inference_index,
                    "reason": reason,
                    "annotated_image": annotated_name,
                    "processed_image": processed_name,
                    "detection_count": len(instances),
                    "instances": self._instance_summary(instances),
                }
            )
        print(f"Anomaly capture saved: {base} reason={reason}")

    def observe(
        self,
        inference_index: int,
        annotated_frame: np.ndarray,
        model_input: np.ndarray,
        instances: list[dict],
        evaluation_active: bool,
    ) -> None:
        if not evaluation_active:
            return

        reasons = []
        has_new_tracker = False
        for instance in instances:
            tracker_id = int(instance["tracker_id"])
            confidence = float(instance["confidence"])
            color = str(instance.get("stable_color", "unknown"))
            pass_id = instance.get("pass_id")
            expected_color = str(instance.get("expected_color", ""))
            if tracker_id not in self.seen_trackers:
                self.seen_trackers.add(tracker_id)
                reasons.append(f"new_tracker:T{tracker_id}")
                has_new_tracker = True
            if confidence < ANOMALY_LOW_CONFIDENCE:
                reasons.append(f"low_confidence:{confidence:.2f}")
            if expected_color and color != expected_color:
                reasons.append(
                    f"wrong_color:{expected_color}_to_{color}"
                )
            if pass_id is not None:
                pass_id = int(pass_id)
                previous_color = self.last_color_by_pass.get(pass_id)
                if previous_color is not None and color != previous_color:
                    reasons.append(
                        f"color_change:P{pass_id}:{previous_color}_to_{color}"
                    )
                self.last_color_by_pass[pass_id] = color

        if len(instances) > ANOMALY_MAX_EXPECTED_INSTANCES:
            reasons.append(f"too_many_detections:{len(instances)}")
        if not reasons:
            return

        now = time.perf_counter()
        if (
            not has_new_tracker
            and now - self.last_automatic_save
            < ANOMALY_CAPTURE_COOLDOWN_SECONDS
        ):
            return
        self.last_automatic_save = now
        self._save(
            ";".join(dict.fromkeys(reasons)), inference_index,
            annotated_frame, model_input, instances,
        )

    def save_manual(
        self,
        inference_index: int,
        annotated_frame: np.ndarray,
        model_input: np.ndarray,
        instances: list[dict],
    ) -> None:
        self._save(
            "manual:A_key", inference_index,
            annotated_frame, model_input, instances,
        )


