"""Composed recorder for distance self-check sessions."""

from .self_check_lifecycle import SelfCheckLifecycleMixin
from .self_check_observation import SelfCheckObservationMixin
from .self_check_persistence import SelfCheckPersistenceMixin
from .self_check_reporting import SelfCheckReportingMixin


class SelfCheckRecorder(
    SelfCheckLifecycleMixin,
    SelfCheckObservationMixin,
    SelfCheckReportingMixin,
    SelfCheckPersistenceMixin,
):
    """Record observations, metrics, reports, and replayable evidence."""