"""Runtime loop and UI for distance self-check."""

from __future__ import annotations

import time

import cv2
import numpy as np

from plate_detector import constants as const
from plate_detector.aoi import load_aoi_polygon, resolve_aoi_file, select_aoi_polygon
from plate_detector.camera import list_cameras, open_camera
from plate_detector.camera_registry import auto_bind_devices, resolve_camera_selection
from plate_detector.color import color_bgr
from plate_detector.drawing import draw_aoi_overlay
from plate_detector.geometry import prepare_aoi_view, project_polygon_to_frame
from plate_detector.inference import create_inference_client, preprocess_aoi_for_inference, run_inference
from plate_detector.instances import create_color_history, create_tracker, process_predictions
from plate_detector.settings import CAMERA_FPS, DEFAULT_WARP_ENABLED
from validation.models.handoff import HandoffMQTT
from validation.models.topology import fetch_camera_neighbors
from .self_check_anomaly import AnomalyCapture
from .self_check_context import (
    CONFIDENCE_THRESHOLD,
    DEFAULT_CAMERA_INDEX,
    IOU_THRESHOLD,
    NEAR_DISTANCE_CM,
    TRACK_LENGTH_CM,
    WINDOW_TITLE,
    build_world_transform,
    draw_distance_grid,
    normalize_operational_colors,
    parse_args,
    transform_points,
)
from .self_check_recorder import SelfCheckRecorder
def draw_panel(frame: np.ndarray, lines: list[str]) -> None:
    x, y = 12, 24
    width = min(frame.shape[1] - 24, 520)
    height = 18 + len(lines) * 22
    overlay = frame.copy()
    cv2.rectangle(overlay, (6, 6), (6 + width, 6 + height), (15, 15, 15), -1)
    cv2.addWeighted(overlay, 0.72, frame, 0.28, 0, frame)
    for line in lines:
        cv2.putText(
            frame, line, (x, y), cv2.FONT_HERSHEY_SIMPLEX, 0.48,
            (245, 245, 245), 1, cv2.LINE_AA,
        )
        y += 22


def draw_waiting_banner(frame: np.ndarray, blocked: bool = False) -> None:
    height, width = frame.shape[:2]
    overlay = frame.copy()
    top = max(70, height // 2 - 75)
    bottom = min(height - 20, top + 150)
    cv2.rectangle(overlay, (20, top), (width - 20, bottom), (0, 0, 0), -1)
    cv2.addWeighted(overlay, 0.78, frame, 0.22, 0, frame)
    title = "CLEAR ROI FIRST" if blocked else "TEST NOT RECORDING"
    subtitle = (
        "Plate detected - wait until ROI is empty"
        if blocked else
        "Press B before the ORANGE plate enters (O > G > Y)"
    )
    title_size = cv2.getTextSize(
        title, cv2.FONT_HERSHEY_SIMPLEX, 1.05, 3
    )[0]
    subtitle_size = cv2.getTextSize(
        subtitle, cv2.FONT_HERSHEY_SIMPLEX, 0.65, 2
    )[0]
    cv2.putText(
        frame, title, ((width - title_size[0]) // 2, top + 55),
        cv2.FONT_HERSHEY_SIMPLEX, 1.05, (0, 80, 255), 3, cv2.LINE_AA,
    )
    cv2.putText(
        frame, subtitle, ((width - subtitle_size[0]) // 2, top + 105),
        cv2.FONT_HERSHEY_SIMPLEX, 0.65, (0, 230, 255), 2, cv2.LINE_AA,
    )


def main() -> None:
    args = parse_args()
    if args.list_cameras:
        list_cameras()
        return
    auto_bind_devices()

    selection = resolve_camera_selection(args.camera, args.camera_id, args.mqtt_camera_id)
    args.camera = selection.camera_index
    saved_binding = selection.binding
    logical_camera_id = selection.camera_id
    if args.camera is None:
        args.camera = DEFAULT_CAMERA_INDEX
    if saved_binding is not None:
        if args.handoff_role is None:
            args.handoff_role = str(saved_binding.get("handoff_role", "off"))
        if not args.peer_camera_id.strip():
            args.peer_camera_id = str(saved_binding.get("peer_camera_id", ""))
        if not args.upstream_camera_id.strip():
            args.upstream_camera_id = str(
                saved_binding.get("upstream_camera_id", "")
            )
        if not args.downstream_camera_id.strip():
            args.downstream_camera_id = str(
                saved_binding.get("downstream_camera_id", "")
            )
    if args.handoff_role is None:
        args.handoff_role = "off"

    if args.no_handoff:
        args.upstream_camera_id = ""
        args.downstream_camera_id = ""
        args.handoff_role = "off"
    topology_camera_id = selection.mqtt_camera_id
    if args.backend_url.strip() and not args.no_handoff:
        if not topology_camera_id:
            raise RuntimeError(
                "--backend-url requires --camera-id or --mqtt-camera-id"
            )
        neighbors = fetch_camera_neighbors(
            args.backend_url.strip(), topology_camera_id,
            args.backend_service_token.strip(),
        )
        args.upstream_camera_id = neighbors.upstream_camera_id
        args.downstream_camera_id = neighbors.downstream_camera_id
        args.handoff_role = "both"
        print(
            f"Loaded map v{neighbors.map_version} topology: "
            f"{neighbors.upstream_camera_id} > {topology_camera_id} > "
            f"{neighbors.downstream_camera_id}"
        )

    client = create_inference_client(CONFIDENCE_THRESHOLD, IOU_THRESHOLD)
    tracker = create_tracker(CAMERA_FPS, activation_threshold=CONFIDENCE_THRESHOLD)
    color_history = create_color_history()
    capture, frame = open_camera(args.camera)

    aoi_file = resolve_aoi_file(logical_camera_id, saved_binding)
    aoi_polygon = load_aoi_polygon(aoi_file, frame.shape)
    if args.select_roi or aoi_polygon is None:
        if args.headless:
            raise RuntimeError(
                f"Headless mode requires an existing four-point AOI file ({aoi_file}); "
                "run once with --select-roi before deployment."
            )
        aoi_polygon = select_aoi_polygon(frame, aoi_file)
    image_to_world, world_to_image = build_world_transform(aoi_polygon)
    role = args.handoff_role
    camera_id = logical_camera_id
    mqtt_camera_id = selection.mqtt_camera_id
    peer_camera_id = args.peer_camera_id.strip()
    upstream_camera_id = args.upstream_camera_id.strip()
    downstream_camera_id = args.downstream_camera_id.strip()
    if not upstream_camera_id and role == "downstream":
        upstream_camera_id = peer_camera_id
    if not downstream_camera_id and role == "upstream":
        downstream_camera_id = peer_camera_id
    receives_upstream = bool(upstream_camera_id)
    publishes_downstream = bool(downstream_camera_id)
    handoff_enabled = receives_upstream or publishes_downstream
    if receives_upstream and publishes_downstream:
        role = "both"
    elif receives_upstream:
        role = "downstream"
    elif publishes_downstream:
        role = "upstream"
    else:
        role = "off"
    if args.headless and handoff_enabled:
        args.continuous_handoff = True
    if handoff_enabled and not mqtt_camera_id:
        raise RuntimeError(
            "a camera/MQTT ID is required when handoff is enabled"
        )
    if args.continuous_handoff and not handoff_enabled:
        raise RuntimeError(
            "--continuous-handoff requires an upstream or downstream camera ID"
        )
    recorder = SelfCheckRecorder(
        external_expected=receives_upstream,
        session_suffix=camera_id or mqtt_camera_id,
        continuous_mode=bool(args.continuous_handoff),
    )
    handoff = None
    if handoff_enabled:
        handoff = HandoffMQTT(
            role=role,
            camera_id=mqtt_camera_id,
            peer_camera_id=peer_camera_id,
            upstream_camera_id=upstream_camera_id,
            downstream_camera_id=downstream_camera_id,
            output_directory=recorder.directory,
            host=str(const.REPORT_MQTT_BROKER_HOST),
            port=int(const.REPORT_MQTT_BROKER_PORT),
            username=str(const.REPORT_MQTT_USERNAME),
            password=str(const.REPORT_MQTT_PASSWORD),
            qos=int(const.REPORT_MQTT_QOS),
            keepalive=int(const.MQTT_KEEPALIVE),
            matching_mode=args.matching_mode,
        )
        recorder.handoff = handoff
        handoff.start()
    anomaly_capture = AnomalyCapture(recorder.directory)
    inference_index = 0
    last_autosave = time.monotonic()

    if args.headless:
        print(
            f"Distance self-check production mode started on camera {args.camera}; "
            f"autosave={args.autosave_seconds:g}s; no keyboard input required."
        )
    elif args.continuous_handoff:
        print(
            f"Continuous handoff started automatically on camera {args.camera}; "
            f"autosave={args.autosave_seconds:g}s. No B or Q required; "
            "use Ctrl+C in the supervisor terminal to stop both cameras."
        )
    else:
        print(
            f"Distance self-check started on camera {args.camera}. "
            "Q=quit, R=redraw ROI, S=save report, B=start test, "
            "A=save abnormal image"
        )
    if args.continuous_handoff:
        if args.headless:
            print("Continuous handoff ACTIVE: automatic start and persistence.")
        else:
            print("Continuous handoff ACTIVE: recording now; unknown count/color.")
    print("Output:", recorder.directory)
    try:
        while True:
            ok, frame = capture.read()
            if not ok:
                break
            original_aoi, masked_aoi, aoi_x, aoi_y, inverse, _warped = (
                prepare_aoi_view(frame, aoi_polygon, DEFAULT_WARP_ENABLED)
            )
            model_input = preprocess_aoi_for_inference(masked_aoi)
            result = run_inference(client, model_input)
            instances = process_predictions(
                result=result,
                # Match production: inference and color/reflection filtering
                # use the same reference-calibrated brightness and contrast.
                original_aoi=model_input,
                tracker=tracker,
                color_history=color_history,
            )
            for instance in instances:
                normalize_operational_colors(instance)
            inference_index += 1
            for instance in instances:
                polygon = project_polygon_to_frame(
                    instance["polygon"], aoi_x, aoi_y, frame.shape, inverse
                )
                center = np.mean(polygon.astype(np.float32), axis=0)
                world = transform_points(center.reshape(1, 2), image_to_world)[0]
                instance["distance_cm"] = float(
                    np.clip(world[1], NEAR_DISTANCE_CM, TRACK_LENGTH_CM)
                )
                instance["projected_polygon"] = polygon

            recorder.record(inference_index, instances, model_input)
            if handoff is not None:
                handoff.tick()
            output = frame.copy()
            draw_aoi_overlay(output, aoi_polygon)
            draw_distance_grid(output, world_to_image)
            for instance in instances:
                polygon = instance["projected_polygon"]
                color = color_bgr(instance.get("stable_color", "unknown"))
                box_x1 = int(np.min(polygon[:, 0]))
                box_y1 = int(np.min(polygon[:, 1]))
                box_x2 = int(np.max(polygon[:, 0]))
                box_y2 = int(np.max(polygon[:, 1]))
                cv2.rectangle(
                    output,
                    (box_x1, box_y1),
                    (box_x2, box_y2),
                    color,
                    2,
                    cv2.LINE_AA,
                )
                label = (
                    f"P{instance.get('pass_id', '-')}/T{instance['tracker_id']} "
                    f"{instance['distance_cm']:.1f}cm "
                    f"C{instance['confidence']:.2f} "
                    f"{instance.get('measurement_phase', '')}"
                )
                cv2.putText(
                    output, label, (box_x1, max(18, box_y1 - 8)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.46, color, 2, cv2.LINE_AA,
                )
            panel_lines = recorder.summary_lines()
            if handoff is not None:
                panel_lines.extend(handoff.display_lines())
            draw_panel(output, panel_lines)
            anomaly_capture.observe(
                inference_index=inference_index,
                annotated_frame=output,
                model_input=model_input,
                instances=instances,
                evaluation_active=recorder.evaluation_active,
            )
            cv2.putText(
                output,
                f"A=save anomaly | saved={anomaly_capture.capture_count}",
                (12, output.shape[0] - 14),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.48,
                (0, 220, 255),
                1,
                cv2.LINE_AA,
            )
            if not recorder.evaluation_active:
                draw_waiting_banner(output, blocked=bool(instances))
            if (
                args.autosave_seconds > 0
                and time.monotonic() - last_autosave >= args.autosave_seconds
            ):
                recorder.save()
                if handoff is not None:
                    handoff.snapshot()
                last_autosave = time.monotonic()
            if args.headless:
                key = -1
            else:
                cv2.imshow(WINDOW_TITLE, output)
                key = cv2.waitKey(1) & 0xFF
            if key == ord("q"):
                break
            if key == ord("s"):
                recorder.save()
                if handoff is not None:
                    handoff.save()
            if key == ord("a"):
                anomaly_capture.save_manual(
                    inference_index=inference_index,
                    annotated_frame=output,
                    model_input=model_input,
                    instances=instances,
                )
            if key == ord("b"):
                if args.continuous_handoff:
                    print("B ignored: continuous handoff is already recording.")
                    continue
                if instances:
                    print(
                        "Cannot start: a plate/detection is already inside ROI. "
                        "Wait until ROI is empty, then press B before ORANGE enters."
                    )
                else:
                    tracker.reset()
                    color_history.clear()
                    recorder.start_color_cycle()
                    anomaly_capture.reset_tracking_state()
            if key == ord("r"):
                aoi_polygon = select_aoi_polygon(frame, aoi_file)
                image_to_world, world_to_image = build_world_transform(aoi_polygon)
                tracker.reset()
                color_history.clear()
                recorder.reset()
                anomaly_capture.reset_tracking_state()
    finally:
        recorder.save()
        if handoff is not None:
            handoff.stop()
        capture.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
