"""Accuracy validation and improvement tools; the device never imports this package.

The runnable device program lives in ``../device``. Validation reuses its detection
modules (``plate_detector``) read-only, so that folder is put on ``sys.path`` here.
"""

import sys
from pathlib import Path

VALIDATION_ROOT = Path(__file__).resolve().parent
DEVICE_ROOT = VALIDATION_ROOT.parent / "device"

if str(DEVICE_ROOT) not in sys.path:
    sys.path.insert(0, str(DEVICE_ROOT))
