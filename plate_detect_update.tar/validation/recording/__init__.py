"""Live accuracy recording attached to the device detection loop."""
