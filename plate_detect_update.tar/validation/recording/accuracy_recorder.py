"""Structured accuracy logging for the live bbox plate detector.

The recorder keeps raw observations as CSV and produces a session summary.
Ground-truth add/remove events are entered by the operator; latency cannot be
measured reliably from model output alone.  Identity and stage tracking come
from the device's ``PlateIdentityTracker`` so validation sees the same IDs the
device publishes.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from plate_detector.plate_identity import PlateIdentityTracker, PlateState, box_center

from .recorder_output import RecorderOutputMixin
from .recorder_schema import CSV_FIELDS, EXPECTED_SEQUENCE

DUPLICATE_SMALLER_AREA_RATIO = 0.45


@dataclass
class RecordedPlateState(PlateState):
    duplicate_frames: int = 0
    batch_id: int | None = None
    sequence: int | None = None
    expected_color: str = ""


def duplicate_counts(instances) -> list[int]:
    counts = [0] * len(instances)
    for i, left in enumerate(instances):
        a = left["xyxy"]
        for j in range(i + 1, len(instances)):
            b = instances[j]["xyxy"]
            ix = max(0.0, min(a[2], b[2]) - max(a[0], b[0]))
            iy = max(0.0, min(a[3], b[3]) - max(a[1], b[1]))
            smaller = min(
                max(1.0, (a[2] - a[0]) * (a[3] - a[1])),
                max(1.0, (b[2] - b[0]) * (b[3] - b[1])),
            )
            if ix * iy / smaller >= DUPLICATE_SMALLER_AREA_RATIO:
                counts[i] += 1
                counts[j] += 1
    return counts


class BBoxAccuracyRecorder(RecorderOutputMixin, PlateIdentityTracker):
    """Record detections and derive identity, timing, duplicate and heat metrics."""

    state_class = RecordedPlateState

    def __init__(self, root="outputs/bbox_accuracy", reconnect_seconds=2.0):
        super().__init__(reconnect_seconds=reconnect_seconds)
        self.directory = Path(root) / datetime.now().strftime("%Y%m%d_%H%M%S")
        self.directory.mkdir(parents=True, exist_ok=True)
        self.rows: list[dict] = []
        self.frame_rows: list[dict] = []
        self.events: list[dict] = []
        self.crossing_events: list[dict] = []
        self.batches: dict[int, dict] = {}
        self.active_batch_id = 0
        self.manual_open: list[dict] = []
        self.error_points: list[tuple[int, int, float]] = []
        self.finalized = False
        self._duplicates: list[int] = []
        self.start_batch()

    def record(self, frame_index, inference_ms, instances, frame_shape):
        self.update(instances, frame_shape, frame_index, inference_ms)

    def start_batch(self):
        now = self._now()
        if self.active_batch_id in self.batches:
            self.batches[self.active_batch_id]["closed_s"] = round(now, 4)
        self.active_batch_id += 1
        self.batches[self.active_batch_id] = {
            "batch_id": self.active_batch_id,
            "started_s": round(now, 4),
            "closed_s": "",
            "entry_ids": [],
            "exit_ids": [],
        }
        print(f"Started batch {self.active_batch_id}: expected red -> light_green -> orange")

    def display_lines(self):
        batch = self.batches[self.active_batch_id]
        return [
            f"batch={self.active_batch_id} entry={len(batch['entry_ids'])}/3 exit={len(batch['exit_ids'])}/3",
            "expected=R > LG > O | B=next batch",
        ]

    # ---- PlateIdentityTracker hooks -------------------------------------
    def _on_frame(self, now, frame_index, inference_ms, active_instances):
        self._duplicates = duplicate_counts(active_instances)
        colors = Counter(item.get("stable_color", "unknown") for item in active_instances)
        self.frame_rows.append({
            "session_s": round(now, 4), "frame_index": frame_index,
            "inference_index": self.inference_index, "inference_ms": round(inference_ms, 3),
            "plate_count": len(active_instances), "red_count": colors["red"],
            "light_green_count": colors["light_green"], "orange_count": colors["orange"],
            "unknown_count": colors["unknown"], "duplicate_pair_count": sum(self._duplicates) // 2,
        })

    def _on_entry(self, state):
        batch = self.batches[self.active_batch_id]
        sequence = len(batch["entry_ids"]) + 1
        state.batch_id = self.active_batch_id
        state.sequence = sequence
        state.expected_color = EXPECTED_SEQUENCE[sequence - 1] if sequence <= len(EXPECTED_SEQUENCE) else ""
        batch["entry_ids"].append(state.plate_id)

    def _on_exit(self, state):
        batch = self.batches.get(state.batch_id)
        if batch is not None and state.plate_id not in batch["exit_ids"]:
            batch["exit_ids"].append(state.plate_id)

    def _on_crossing(self, state, line, color, now, progress):
        self.crossing_events.append({
            "type": "line_crossing",
            "line": line,
            "time_s": round(now, 4),
            "plate_id": state.plate_id,
            "batch_id": state.batch_id or "",
            "sequence": state.sequence or "",
            "expected_color": state.expected_color,
            "predicted_color": color,
            "correct": int(color == state.expected_color) if state.expected_color else "",
            "progress": round(progress, 4),
        })

    def _on_observation(self, *, now, frame_index, inference_ms, index, item, state, box,
                        progress, reappeared, switched):
        duplicates = self._duplicates[index]
        state.duplicate_frames += int(duplicates > 0)
        cx, cy = box_center(box)
        row = dict.fromkeys(CSV_FIELDS, "")
        row.update({
            "session_s": round(now, 4), "frame_index": frame_index,
            "inference_index": self.inference_index, "inference_ms": round(inference_ms, 3),
            "tracker_id": int(item["tracker_id"]), "plate_id": state.plate_id,
            "confidence": round(float(item.get("confidence", 0)), 5),
            "current_color": item.get("current_color", "unknown"),
            "stable_color": item.get("stable_color", "unknown"),
            "x1": round(box[0], 2), "y1": round(box[1], 2), "x2": round(box[2], 2), "y2": round(box[3], 2),
            "center_x": round(cx, 2), "center_y": round(cy, 2),
            "width": round(box[2] - box[0], 2), "height": round(box[3] - box[1], 2),
            "duplicate_count": duplicates, "is_reappearance": int(reappeared),
            "color_switched": int(switched), "progress": round(progress, 4),
            "batch_id": state.batch_id or "", "sequence": state.sequence or "",
            "expected_color": state.expected_color, "stage": state.stage,
        })
        self.rows.append(row)
        item["batch_id"] = state.batch_id
        item["sequence"] = state.sequence
        item["expected_color"] = state.expected_color
        if duplicates or switched or reappeared:
            self.error_points.append((int(cx), int(cy), 1.0 + duplicates))

    def _on_frame_done(self, now, visible):
        self._pair_manual_events(now, visible)

    # ---- Operator ground-truth marks ------------------------------------
    def mark_add(self, color):
        event = {
            "type": "ground_truth_add", "color": color, "time_s": round(self._now(), 4),
            "matched_plate_id": "", "latency_ms": "",
        }
        self.events.append(event)
        self.manual_open.append(event)
        print(f"Marked ADD {color}")

    def mark_remove(self):
        now = self._now()
        open_items = [item for item in self.manual_open if not item.get("removed")]
        target = open_items[0] if open_items else None
        event = {
            "type": "ground_truth_remove",
            "color": target["color"] if target else "unknown",
            "time_s": round(now, 4),
            "matched_plate_id": target.get("matched_plate_id", "") if target else "",
            "latency_ms": "",
        }
        self.events.append(event)
        if target:
            target["removed"] = now
            target["remove_event"] = event
        print("Marked REMOVE")

    def _pair_manual_events(self, now, visible):
        for event in self.manual_open:
            if not event["matched_plate_id"]:
                candidates = [
                    pid for pid in visible
                    if self.states[pid].last_color == event["color"]
                    and self.states[pid].first_seen >= event["time_s"] - 0.25
                ]
                if candidates:
                    pid = min(candidates, key=lambda value: self.states[value].first_seen)
                    event["matched_plate_id"] = pid
                    event["latency_ms"] = round(max(0, self.states[pid].first_seen - event["time_s"]) * 1000, 2)
            remove_event = event.get("remove_event")
            pid = event.get("matched_plate_id")
            if remove_event and pid and not remove_event["latency_ms"] and pid not in visible:
                remove_event["latency_ms"] = round(max(0, now - remove_event["time_s"]) * 1000, 2)
