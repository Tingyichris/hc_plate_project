"""Output generation for :class:`BBoxAccuracyRecorder`."""

from __future__ import annotations

import json
from collections import Counter

import cv2
import numpy as np

from plate_detector import constants as const
from validation.models.csv_io import write_csv

from .recorder_schema import CSV_FIELDS, EXPECTED_SEQUENCE


class RecorderOutputMixin:
    def _write_csv(self, name, rows, fields):
        write_csv(self.directory / name, rows, fields)

    def _batch_rows(self):
        rows = []
        for batch in self.batches.values():
            entry_ids = batch["entry_ids"]
            exit_ids = batch["exit_ids"]
            if not entry_ids and not exit_ids:
                continue
            missing_ids = [pid for pid in entry_ids if pid not in exit_ids]
            extra_ids = [pid for pid in exit_ids if pid not in entry_ids]
            entry_states = [self.states[pid] for pid in entry_ids]
            exit_states = [self.states[pid] for pid in exit_ids]
            entry_correct = sum(
                state.entry_color == state.expected_color
                for state in entry_states
                if state.expected_color
            )
            exit_correct = sum(
                state.exit_color == state.expected_color
                for state in exit_states
                if state.expected_color
            )
            rows.append({
                "batch_id": batch["batch_id"],
                "started_s": batch["started_s"],
                "closed_s": batch["closed_s"],
                "expected_count": len(EXPECTED_SEQUENCE),
                "entry_count": len(entry_ids),
                "exit_count": len(exit_ids),
                "entry_plate_ids": " ".join(map(str, entry_ids)),
                "exit_plate_ids": " ".join(map(str, exit_ids)),
                "missing_plate_ids": " ".join(map(str, missing_ids)),
                "extra_plate_ids": " ".join(map(str, extra_ids)),
                "entry_extra_count": max(0, len(entry_ids) - len(EXPECTED_SEQUENCE)),
                "entry_missing_count": max(0, len(EXPECTED_SEQUENCE) - len(entry_ids)),
                "order_correct": int(entry_ids == exit_ids),
                "entry_colors": " ".join(state.entry_color for state in entry_states),
                "exit_colors": " ".join(state.exit_color for state in exit_states),
                "entry_color_correct": entry_correct,
                "exit_color_correct": exit_correct,
            })
        return rows

    def finalize(self):
        if self.finalized:
            return
        self.finalized = True
        self.batches[self.active_batch_id]["closed_s"] = round(self._now(), 4)
        self._write_csv("detections.csv", self.rows, CSV_FIELDS)
        frame_fields = [
            "session_s", "frame_index", "inference_index", "inference_ms",
            "plate_count", "red_count", "light_green_count", "orange_count",
            "unknown_count", "duplicate_pair_count",
        ]
        self._write_csv("frames.csv", self.frame_rows, frame_fields)
        self._write_csv(
            "events.csv", self.events,
            ["type", "color", "time_s", "matched_plate_id", "latency_ms"],
        )
        crossing_fields = [
            "type", "line", "time_s", "plate_id", "batch_id", "sequence",
            "expected_color", "predicted_color", "correct", "progress",
        ]
        self._write_csv("crossings.csv", self.crossing_events, crossing_fields)
        batch_rows = self._batch_rows()
        batch_fields = [
            "batch_id", "started_s", "closed_s", "expected_count",
            "entry_count", "exit_count", "entry_plate_ids", "exit_plate_ids",
            "missing_plate_ids", "extra_plate_ids", "entry_extra_count",
            "entry_missing_count", "order_correct", "entry_colors",
            "exit_colors", "entry_color_correct", "exit_color_correct",
        ]
        self._write_csv("batches.csv", batch_rows, batch_fields)
        tracks = [self._track_row(state) for state in self.states.values()]
        track_fields = [
            "plate_id", "tracker_ids", "first_seen_s", "last_seen_s",
            "duration_s", "observations", "final_color", "disappearances",
            "reappearances", "color_switches", "duplicate_frames", "batch_id",
            "sequence", "expected_color", "stage", "entry_time_s", "entry_color",
            "count_time_s", "count_color", "exit_time_s", "exit_color",
            "final_correct",
        ]
        self._write_csv("plates.csv", tracks, track_fields)
        summary = self._summary(batch_rows)
        (self.directory / "summary.json").write_text(
            json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        self._write_heatmap()
        print("Accuracy records saved:", self.directory)

    @staticmethod
    def _track_row(state):
        return {
            "plate_id": state.plate_id,
            "tracker_ids": ",".join(map(str, sorted(state.tracker_ids))),
            "first_seen_s": round(state.first_seen, 4),
            "last_seen_s": round(state.last_seen, 4),
            "duration_s": round(state.last_seen - state.first_seen, 4),
            "observations": state.observations,
            "final_color": state.last_color,
            "disappearances": state.disappearances,
            "reappearances": state.reappearances,
            "color_switches": state.color_switches,
            "duplicate_frames": state.duplicate_frames,
            "batch_id": state.batch_id or "",
            "sequence": state.sequence or "",
            "expected_color": state.expected_color,
            "stage": state.stage,
            "entry_time_s": round(state.entry_time, 4) if state.entry_time is not None else "",
            "entry_color": state.entry_color,
            "count_time_s": round(state.count_time, 4) if state.count_time is not None else "",
            "count_color": state.count_color,
            "exit_time_s": round(state.exit_time, 4) if state.exit_time is not None else "",
            "exit_color": state.exit_color,
            "final_correct": (
                int(state.exit_color == state.expected_color)
                if state.exit_color and state.expected_color else ""
            ),
        }

    def _summary(self, batch_rows):
        colors = Counter(row["stable_color"] for row in self.rows)
        latencies = [float(e["latency_ms"]) for e in self.events if e["latency_ms"] != ""]
        inference = [row["inference_ms"] for row in self.frame_rows]
        return {
            "test_condition": {
                "meal": const.TEST_MEAL,
                "spacing": const.TEST_SPACING,
                "speed": const.TEST_SPEED,
                "planned_laps": int(const.TEST_PLANNED_LAPS),
            },
            "duration_s": round(self._now(), 3),
            "inference_count": self.inference_index,
            "unique_plate_count": len(self.states),
            "observation_color_counts": dict(colors),
            "reappearance_count": sum(s.reappearances for s in self.states.values()),
            "color_switch_count": sum(s.color_switches for s in self.states.values()),
            "duplicate_frame_count": sum(s.duplicate_frames for s in self.states.values()),
            "manual_event_count": len(self.events),
            "completed_batch_count": sum(
                row["entry_count"] == 3 and row["exit_count"] == 3 for row in batch_rows
            ),
            "entry_crossing_count": sum(row["entry_count"] for row in batch_rows),
            "exit_crossing_count": sum(row["exit_count"] for row in batch_rows),
            "missing_at_exit_count": sum(len(row["missing_plate_ids"].split()) for row in batch_rows),
            "extra_at_exit_count": sum(len(row["extra_plate_ids"].split()) for row in batch_rows),
            "order_error_count": sum(not row["order_correct"] for row in batch_rows),
            "entry_color_correct_count": sum(row["entry_color_correct"] for row in batch_rows),
            "exit_color_correct_count": sum(row["exit_color_correct"] for row in batch_rows),
            "inference_mean_ms": round(float(np.mean(inference)), 2) if inference else None,
            "inference_p95_ms": round(float(np.percentile(inference, 95)), 2) if inference else None,
            "latency_mean_ms": round(float(np.mean(latencies)), 2) if latencies else None,
            "latency_max_ms": round(max(latencies), 2) if latencies else None,
            "notes": (
                "Counts are model observations. "
                "Precision/recall require operator ground-truth events or labelled video."
            ),
        }

    def _write_heatmap(self):
        if not self.frame_shape:
            return
        height, width = self.frame_shape
        heat = np.zeros((height, width), np.float32)
        for x, y, weight in self.error_points:
            if 0 <= x < width and 0 <= y < height:
                heat[y, x] += weight
        if not np.any(heat):
            heat[0, 0] = 0.001
        heat = cv2.GaussianBlur(heat, (0, 0), sigmaX=max(8, width / 40))
        heat = cv2.normalize(heat, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        image = cv2.applyColorMap(heat, cv2.COLORMAP_JET)
        cv2.imwrite(str(self.directory / "error_heatmap.png"), image)
