"""Save false-positive/positive detection evidence for later model improvement."""

from __future__ import annotations

import json
import os
import time

import cv2
import numpy as np

from plate_detector.color import color_bgr

MASK_OPACITY = 0.28


def save_detection_capture(
    session_dir,
    frame_index,
    before_preprocess,
    model_input,
    predictions,
    tracked_instances,
    preprocess_mode,
    warp_active,
    use_aoi,
):
    """Save input images, tracked mask overlay, and JSONL metadata."""
    timestamp = time.time()
    timestamp_text = time.strftime(
        "%Y%m%d_%H%M%S",
        time.localtime(timestamp),
    )
    milliseconds = int((timestamp % 1.0) * 1000)
    sample_id = f"{timestamp_text}_{milliseconds:03d}_f{frame_index:06d}"
    original_name = f"{sample_id}_original_raw.png"
    original_bbox_name = f"{sample_id}_original_bbox.png"
    processed_name = f"{sample_id}_processed.png"
    tracked_name = f"{sample_id}_tracked_mask.png"
    original_path = os.path.join(session_dir, original_name)
    original_bbox_path = os.path.join(session_dir, original_bbox_name)
    processed_path = os.path.join(session_dir, processed_name)
    tracked_path = os.path.join(session_dir, tracked_name)

    original_bbox_image = before_preprocess.copy()
    tracked_image = model_input.copy()
    mask_overlay = tracked_image.copy()
    for instance in tracked_instances:
        polygon = np.rint(instance["polygon"]).astype(np.int32)
        mask_color = color_bgr(instance.get("stable_color", "unknown"))
        cv2.fillPoly(mask_overlay, [polygon], mask_color)
    cv2.addWeighted(
        mask_overlay,
        MASK_OPACITY,
        tracked_image,
        1.0 - MASK_OPACITY,
        0,
        tracked_image,
    )
    for instance in tracked_instances:
        polygon = np.rint(instance["polygon"]).astype(np.int32)
        mask_color = color_bgr(instance.get("stable_color", "unknown"))
        box_x1, box_y1, box_x2, box_y2 = (
            np.rint(instance["xyxy"]).astype(int).tolist()
        )
        cv2.polylines(
            tracked_image,
            [polygon],
            True,
            mask_color,
            2,
            cv2.LINE_AA,
        )
        tracker_id = instance.get("tracker_id")
        plate_id = instance.get("persistent_plate_id")
        identity = (
            f"P{plate_id}/T{tracker_id}"
            if plate_id is not None
            else f"T{tracker_id}"
        )
        label = (
            f"{identity} {instance.get('confidence', 0.0):.2f} "
            f"{instance.get('stable_color', 'unknown')}"
        )
        label_x = int(np.min(polygon[:, 0]))
        label_y = max(18, int(np.min(polygon[:, 1])) - 6)
        cv2.rectangle(
            original_bbox_image,
            (box_x1, box_y1),
            (box_x2, box_y2),
            mask_color,
            3,
            cv2.LINE_AA,
        )
        cv2.putText(
            original_bbox_image,
            label,
            (max(0, box_x1), max(18, box_y1 - 6)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,
            (255, 255, 255),
            2,
            cv2.LINE_AA,
        )
        cv2.putText(
            tracked_image,
            label,
            (label_x, label_y),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,
            (255, 255, 255),
            2,
            cv2.LINE_AA,
        )

    original_saved = cv2.imwrite(original_path, before_preprocess)
    original_bbox_saved = cv2.imwrite(
        original_bbox_path,
        original_bbox_image,
    )
    processed_saved = cv2.imwrite(processed_path, model_input)
    tracked_saved = cv2.imwrite(tracked_path, tracked_image)
    if (
        not original_saved
        or not original_bbox_saved
        or not processed_saved
        or not tracked_saved
    ):
        raise RuntimeError(f"Could not save detection capture {sample_id}")

    tracked_records = []
    for instance in tracked_instances:
        tracked_records.append(
            {
                "tracker_id": instance.get("tracker_id"),
                "plate_id": instance.get("persistent_plate_id"),
                "confidence": float(instance.get("confidence", 0.0)),
                "current_color": instance.get("current_color"),
                "stable_color": instance.get("stable_color"),
                "xyxy": np.asarray(instance["xyxy"]).astype(float).tolist(),
                "polygon": np.asarray(instance["polygon"]).astype(int).tolist(),
            }
        )

    record = {
        "sample_id": sample_id,
        "timestamp": timestamp,
        "frame_index": frame_index,
        "original_raw": original_name,
        "original_bbox": original_bbox_name,
        "processed": processed_name,
        "tracked_mask": tracked_name,
        "preprocess_mode": preprocess_mode,
        "warp_active": bool(warp_active),
        "use_aoi": bool(use_aoi),
        "prediction_count": len(predictions),
        "predictions": predictions,
        "tracked_count": len(tracked_records),
        "tracked_instances": tracked_records,
    }
    metadata_path = os.path.join(session_dir, "detections.jsonl")
    with open(metadata_path, "a", encoding="utf-8") as metadata_file:
        metadata_file.write(json.dumps(record, ensure_ascii=False) + "\n")

    return sample_id
