"""Shared CSV schema and expected test sequence for accuracy recording."""

CSV_FIELDS = [
    "session_s", "frame_index", "inference_index", "inference_ms",
    "tracker_id", "plate_id", "confidence", "current_color", "stable_color",
    "x1", "y1", "x2", "y2", "center_x", "center_y", "width", "height",
    "duplicate_count", "is_reappearance", "color_switched",
    "progress", "batch_id", "sequence", "expected_color", "stage",
]

EXPECTED_SEQUENCE = ("red", "light_green", "orange")
