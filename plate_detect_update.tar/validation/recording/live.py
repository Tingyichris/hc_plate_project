"""Run the device detector with accuracy recording and evidence capture attached.

    python -m validation detect-record [--camera N | --camera-id ID]

The device loop is reused unchanged; this module only adds observers.
"""

from __future__ import annotations

import argparse
import os
import time

import cv2

from plate_detector import constants as const
from plate_detector.launcher import add_camera_arguments, build_runtime
from plate_detector.runtime import DetectionObserver
from validation import settings as vset

from .accuracy_recorder import BBoxAccuracyRecorder
from .detection_capture import save_detection_capture

MARK_KEYS = {ord("1"): "red", ord("2"): "green", ord("3"): "yellow"}


class AccuracyRecordingObserver(DetectionObserver):
    """B=new batch, 1/2/3=ground-truth add, 0=ground-truth remove."""

    def __init__(self, recorder: BBoxAccuracyRecorder):
        self.recorder = recorder

    def display_lines(self):
        return self.recorder.display_lines()

    def on_key(self, key, result, output):
        if key == ord("b"):
            self.recorder.start_batch()
        elif key in MARK_KEYS:
            self.recorder.mark_add(MARK_KEYS[key])
        elif key == ord("0"):
            self.recorder.mark_remove()

    def close(self):
        self.recorder.finalize()


class DetectionCaptureObserver(DetectionObserver):
    """Periodically save positive detections for false-positive review."""

    def __init__(self, root, interval_seconds):
        self.session_dir = os.path.join(root, time.strftime("%Y%m%d_%H%M%S"))
        os.makedirs(self.session_dir, exist_ok=True)
        self.interval_seconds = interval_seconds
        self.last_capture = float("-inf")
        print("Detection capture enabled:", os.path.abspath(self.session_dir), f"interval={interval_seconds:.2f}s")

    def on_inference(self, result):
        now = time.time()
        if not result.instances or now - self.last_capture < self.interval_seconds:
            return
        try:
            sample_id = save_detection_capture(
                session_dir=self.session_dir, frame_index=result.frame_index,
                before_preprocess=result.masked_aoi, model_input=result.model_input,
                predictions=result.predictions, tracked_instances=result.instances,
                preprocess_mode=result.preprocess_mode, warp_active=result.warp_active, use_aoi=result.use_aoi,
            )
            self.last_capture = now
            print(
                "Detection capture saved:", sample_id,
                f"tracked={len(result.instances)}", f"best={result.best_confidence:.2f}",
            )
        except Exception as error:  # evidence capture must never stop detection
            print("Detection capture error:", repr(error))


class OutputVideoObserver(DetectionObserver):
    def __init__(self, path, fps):
        self.path = path
        self.fps = fps
        self.writer = None

    def on_output(self, output, result):
        if self.writer is None:
            height, width = output.shape[:2]
            self.writer = cv2.VideoWriter(self.path, cv2.VideoWriter_fourcc(*"mp4v"), self.fps, (width, height))
        self.writer.write(output)

    def close(self):
        if self.writer is not None:
            self.writer.release()
            print("Output saved:", self.path)


class SnapshotKeyObserver(DetectionObserver):
    """S=save the raw AOI, annotated output, and model input images."""

    def on_key(self, key, result, output):
        if key != ord("s") or result is None:
            return
        timestamp = int(time.time())
        files = [(f"raw_aoi_{timestamp}.jpg", result.original_aoi), (f"segmentation_{timestamp}.jpg", output)]
        if result.model_input is not None:
            name = f"model_input_{result.preprocess_mode}_warp_{int(result.warp_active)}_{timestamp}.jpg"
            files.append((name, result.model_input))
        for name, image in files:
            cv2.imwrite(name, image)
            print("Saved:", name)


def build_observers(args):
    observers = [SnapshotKeyObserver()]
    recorder = None
    if vset.RECORDING_ENABLED and not args.no_recording:
        recorder = BBoxAccuracyRecorder(root=str(vset.validation_path(vset.RECORDING_ROOT)))
        observers.append(AccuracyRecordingObserver(recorder))
    if vset.DETECTION_CAPTURE_DETECTIONS and not args.no_capture:
        observers.append(DetectionCaptureObserver(
            str(vset.validation_path(vset.DETECTION_CAPTURE_ROOT)),
            float(vset.DETECTION_CAPTURE_INTERVAL_SECONDS),
        ))
    output_video = args.output_video or str(vset.DETECTION_OUTPUT_VIDEO).strip()
    if output_video:
        observers.append(OutputVideoObserver(output_video, float(const.CAMERA_FPS)))
    return recorder, observers


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    add_camera_arguments(parser)
    parser.add_argument("--no-recording", action="store_true", help="skip the bbox accuracy recorder")
    parser.add_argument("--no-capture", action="store_true", help="skip periodic detection captures")
    parser.add_argument("--output-video", default="", help="also save the annotated stream as MP4")
    args = parser.parse_args()
    recorder, observers = build_observers(args)
    build_runtime(args, identity=recorder, observers=observers).run()


if __name__ == "__main__":
    main()
