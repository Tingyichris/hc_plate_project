"""Public handoff API assembled from focused modules under 500 lines."""

from .handoff_alignment import align_monotonic_events
from .handoff_messages import HandoffMessageMixin
from .handoff_persistence import HandoffPersistenceMixin
from .handoff_report import build_handoff_markdown
from .handoff_reporting import HandoffReportingMixin
from .handoff_transport import HandoffTransportMixin
from .handoff_upstream import HandoffUpstreamMixin


class HandoffMQTT(
    HandoffTransportMixin,
    HandoffUpstreamMixin,
    HandoffMessageMixin,
    HandoffReportingMixin,
    HandoffPersistenceMixin,
):
    """Coordinate adjacent cameras over MQTT while preserving the public API."""


__all__ = ["HandoffMQTT", "align_monotonic_events", "build_handoff_markdown"]