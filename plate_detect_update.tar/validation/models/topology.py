"""Resolve one camera's immediate neighbours from the backend track map."""

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from itertools import pairwise
from urllib.request import Request, urlopen

Point = tuple[float, float]


@dataclass(frozen=True, slots=True)
class CameraNeighbors:
    camera_id: str
    upstream_camera_id: str
    downstream_camera_id: str
    map_version: int


def _catmull_rom(p0: Point, p1: Point, p2: Point, p3: Point, n: int) -> list[Point]:
    points = []
    for index in range(n):
        t = index / n
        t2, t3 = t * t, t * t * t
        points.append((
            0.5 * ((2 * p1[0]) + (-p0[0] + p2[0]) * t
                   + (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2
                   + (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3),
            0.5 * ((2 * p1[1]) + (-p0[1] + p2[1]) * t
                   + (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2
                   + (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3),
        ))
    return points


def _densify(path: list[Point], closed: bool, samples_per_segment: int = 24) -> list[Point]:
    if len(path) < 3:
        fine = list(path)
    else:
        fine = []
        count = len(path)
        last = count if closed else count - 1
        for index in range(last):
            p0 = path[(index - 1) % count] if closed else path[max(index - 1, 0)]
            p1 = path[index % count]
            p2 = path[(index + 1) % count] if closed else path[min(index + 1, count - 1)]
            p3 = path[(index + 2) % count] if closed else path[min(index + 2, count - 1)]
            fine.extend(_catmull_rom(p0, p1, p2, p3, samples_per_segment))
        if not closed:
            fine.append(path[-1])
    if closed and fine and fine[0] != fine[-1]:
        fine.append(fine[0])
    return fine


def _project(point: Point, fine: list[Point]) -> float:
    if len(fine) < 2:
        raise ValueError("track path must contain at least two points")
    cumulative = [0.0]
    for start, end in pairwise(fine):
        cumulative.append(cumulative[-1] + math.dist(start, end))
    if cumulative[-1] <= 0:
        raise ValueError("track path length must be positive")
    best_s, best_distance = 0.0, math.inf
    for index in range(1, len(fine)):
        x0, y0 = fine[index - 1]
        x1, y1 = fine[index]
        dx, dy = x1 - x0, y1 - y0
        segment_squared = dx * dx + dy * dy or 1.0
        ratio = max(0.0, min(1.0, (
            (point[0] - x0) * dx + (point[1] - y0) * dy
        ) / segment_squared))
        closest = (x0 + ratio * dx, y0 + ratio * dy)
        distance = math.dist(point, closest)
        if distance < best_distance:
            best_distance = distance
            best_s = (
                cumulative[index - 1] + ratio * math.hypot(dx, dy)
            ) / cumulative[-1]
    return best_s


def neighbors_from_map(document: dict, camera_id: str) -> CameraNeighbors:
    track = document.get("track") or {}
    path = [tuple(map(float, point)) for point in track.get("path_px", [])]
    closed = bool(track.get("closed", True))
    fine = _densify(path, closed)
    ordered = []
    for camera in document.get("cameras", []):
        checkpoint = camera.get("marker_px") or camera.get("counting_point_px")
        if not checkpoint:
            raise ValueError(f"camera {camera.get('id', '?')} has no counting point")
        ordered.append((str(camera["id"]), _project(tuple(checkpoint), fine)))
    ordered.sort(key=lambda item: item[1])
    ids = [item[0] for item in ordered]
    if camera_id not in ids:
        raise LookupError(f"camera {camera_id!r} is not present in active map")
    if len(ids) < 2:
        raise ValueError("active map must contain at least two cameras")
    index = ids.index(camera_id)
    upstream = ids[index - 1] if index > 0 else (ids[-1] if closed else "")
    downstream = ids[index + 1] if index + 1 < len(ids) else (ids[0] if closed else "")
    return CameraNeighbors(
        camera_id=camera_id,
        upstream_camera_id=upstream,
        downstream_camera_id=downstream,
        map_version=int(document.get("version", 0)),
    )


def fetch_camera_neighbors(
    backend_url: str, camera_id: str, service_token: str = "", timeout: float = 10.0,
) -> CameraNeighbors:
    url = f"{backend_url.rstrip('/')}/api/maps/current"
    headers = {"Accept": "application/json"}
    if service_token:
        headers["Authorization"] = f"Bearer {service_token}"
    request = Request(url, headers=headers)
    with urlopen(request, timeout=timeout) as response:
        document = json.loads(response.read().decode("utf-8"))
    return neighbors_from_map(document, camera_id)
