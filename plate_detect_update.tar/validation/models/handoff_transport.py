"""MQTT connection lifecycle and publishing for handoff."""

from __future__ import annotations

import json
import threading
import time
from collections import deque
from pathlib import Path
from uuid import uuid4

import paho.mqtt.client as mqtt

from .handoff_constants import TOPIC_ROOT


class HandoffTransportMixin:
    HC_COLOR_CODES = {
        "orange": "#f28c28", "yellow": "#f2cf3a",
        "light_green": "#88d66c", "green": "#4cae7a",
        "red": "#e0564c", "gold": "#d4af37", "black": "#2f333d",
        "white": "#f2f2f2", "unknown": "#8892a6",
    }

    def __init__(
        self,
        role: str,
        camera_id: str,
        peer_camera_id: str,
        output_directory: Path,
        host: str = "192.168.100.69",
        port: int = 1883,
        username: str = "",
        password: str = "",
        qos: int = 1,
        keepalive: int = 30,
        matching_mode: str = "fifo",
        upstream_camera_id: str = "",
        downstream_camera_id: str = "",
    ) -> None:
        if role not in {"off", "upstream", "downstream", "both"}:
            raise ValueError("role must be off, upstream, downstream, or both")
        legacy_peer = str(peer_camera_id).strip()
        upstream_id = str(upstream_camera_id).strip()
        downstream_id = str(downstream_camera_id).strip()
        if not upstream_id and role == "downstream":
            upstream_id = legacy_peer
        if not downstream_id and role == "upstream":
            downstream_id = legacy_peer
        self.receives_upstream = bool(upstream_id) and role in {"downstream", "both"}
        self.publishes_downstream = bool(downstream_id) and role in {"upstream", "both"}
        self.role = (
            "both" if self.receives_upstream and self.publishes_downstream
            else "downstream" if self.receives_upstream
            else "upstream" if self.publishes_downstream
            else "off"
        )
        self.camera_id = camera_id
        self.upstream_camera_id = upstream_id
        self.downstream_camera_id = downstream_id
        # Kept for the existing two-camera report schema.  In dual mode the
        # report describes the inbound edge, so its peer is the upstream node.
        self.peer_camera_id = upstream_id or downstream_id or legacy_peer
        self.output_directory = Path(output_directory)
        self.host = host
        self.port = int(port)
        self.qos = int(qos)
        self.keepalive = int(keepalive)
        if matching_mode not in {"fifo", "dp"}:
            raise ValueError("matching_mode must be 'fifo' or 'dp'")
        self.matching_mode = matching_mode
        self.session_id = f"{camera_id}-{time.strftime('%Y%m%d-%H%M%S')}"
        self._lock = threading.RLock()
        self._connected = False
        self._ever_connected = False
        self._stopped = False
        self._last_heartbeat_sent = 0.0
        self._next_sequence = 1
        self._pending: deque[dict] = deque()
        self._matched_by_pass: dict[int, dict] = {}
        self._upstream_lifecycle: dict[tuple[str, int], dict] = {}
        self._downstream_lifecycle: dict[int, dict] = {}
        self._seen_message_ids: set[str] = set()
        self._last_event_signature: dict[tuple[str, str], float] = {}
        self._peer_last_heartbeat: dict[str, float] = {}
        self._travel_samples: list[float] = []
        self._live_alignment_operations: list[dict] = []
        self._alignment_candidates: list[dict] = []
        self._reported_unarrived: set[tuple[str, int]] = set()
        self.rows: list[dict] = []
        self.events: list[dict] = []
        camera_ids = {
            item for item in (camera_id, upstream_id, downstream_id) if item
        }
        self.stats = {item: self._empty_stats() for item in camera_ids}

        callback_api = getattr(mqtt, "CallbackAPIVersion", None)
        if callback_api is not None:
            self.client = mqtt.Client(
                callback_api.VERSION2,
                client_id=f"self-check-{camera_id}-{uuid4().hex[:8]}",
                protocol=mqtt.MQTTv311,
            )
        else:  # pragma: no cover - paho 1.x compatibility
            self.client = mqtt.Client(
                client_id=f"self-check-{camera_id}-{uuid4().hex[:8]}",
                protocol=mqtt.MQTTv311,
            )
        if username:
            self.client.username_pw_set(username, password)
        # hc_detext_map uses this retained status as its liveness source. A
        # client has one LWT, so the interoperable status topic owns it.
        self.client.will_set(
            f"sushi/status/{self.camera_id}",
            json.dumps({"state": "offline", "reason": "lwt"}),
            qos=self.qos,
            retain=True,
        )
        self.client.on_connect = self._on_connect
        self.client.on_disconnect = self._on_disconnect
        self.client.on_message = self._on_message

    @staticmethod
    def _empty_stats() -> dict:
        return {
            "connect_count": 0,
            "disconnect_count": 0,
            "reconnect_count": 0,
            "publish_success": 0,
            "publish_failure": 0,
            "messages_received": 0,
            "duplicate_messages": 0,
            "out_of_order_events": 0,
            "event_flickers": 0,
            "heartbeat_gaps": 0,
            "last_heartbeat": None,
        }

    def start(self) -> None:
        self.client.connect_async(self.host, self.port, keepalive=self.keepalive)
        self.client.loop_start()

    def stop(self) -> None:
        if self._stopped:
            return
        self._stopped = True
        try:
            self._publish_hc_status("offline")
            self._publish("status", {"state": "offline"})
            self.client.disconnect()
        finally:
            self.client.loop_stop()
            self.save()

    def _on_connect(self, client, _userdata, _flags, reason_code, _properties=None):
        ok = not bool(getattr(reason_code, "is_failure", False))
        if isinstance(reason_code, (int, float)):
            ok = int(reason_code) == 0
        if not ok:
            return
        with self._lock:
            stats = self.stats[self.camera_id]
            stats["connect_count"] += 1
            if self._ever_connected:
                stats["reconnect_count"] += 1
            self._ever_connected = True
            self._connected = True
        if self.receives_upstream:
            client.subscribe(
                f"{TOPIC_ROOT}/event/{self.upstream_camera_id}", qos=self.qos
            )
            client.subscribe(
                f"{TOPIC_ROOT}/status/{self.upstream_camera_id}", qos=self.qos
            )
        if self.publishes_downstream and self.downstream_camera_id:
            client.subscribe(
                f"{TOPIC_ROOT}/status/{self.downstream_camera_id}", qos=self.qos
            )
        self._publish("status", {"state": "online"})
        self._publish_hc_status("online")

    def _on_disconnect(self, _client, _userdata, _disconnect_flags=None,
                       _reason_code=None, _properties=None):
        with self._lock:
            if self._connected and not self._stopped:
                self.stats[self.camera_id]["disconnect_count"] += 1
            self._connected = False

    def _publish(self, kind: str, body: dict) -> bool:
        payload = {
            "schema": 1,
            "message_id": uuid4().hex,
            "camera_id": self.camera_id,
            "role": self.role,
            "session_id": self.session_id,
            "kind": kind,
            "timestamp": time.time(),
            **body,
        }
        topic_group = "status" if kind in {"status", "heartbeat"} else "event"
        try:
            info = self.client.publish(
                f"{TOPIC_ROOT}/{topic_group}/{self.camera_id}",
                json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
                qos=self.qos,
                retain=False,
            )
            ok = info.rc == mqtt.MQTT_ERR_SUCCESS
        except Exception:
            ok = False
        self.stats[self.camera_id][
            "publish_success" if ok else "publish_failure"
        ] += 1
        self.events.append({**payload, "direction": "sent", "publish_ok": int(ok)})
        return ok

    def _publish_hc_status(self, state: str) -> bool:
        payload = {"state": state, "reason": "ok"}
        try:
            info = self.client.publish(
                f"sushi/status/{self.camera_id}",
                json.dumps(payload, separators=(",", ":")),
                qos=self.qos,
                retain=True,
            )
            return info.rc == mqtt.MQTT_ERR_SUCCESS
        except Exception:
            return False

    def _publish_hc_event(
        self, event: str, plate_id: int, color: str, local_pass_id: int,
        extra: dict | None = None,
    ) -> bool:
        """Publish hc_detext_map's Pi-to-fusion v1 event contract."""
        operational_color = str(color or "unknown").lower()
        payload = {
            "event": event,
            "plate_id": int(plate_id),
            "class": operational_color,
            "color": self.HC_COLOR_CODES.get(
                operational_color, self.HC_COLOR_CODES["unknown"]
            ),
            "source": "plate_distance_self_check",
            "role": self.role,
            "session_id": self.session_id,
            "local_pass_id": int(local_pass_id),
            "raw_operational_color": operational_color,
            **(extra or {}),
        }
        topic = f"sushi/events/{self.camera_id}"
        try:
            info = self.client.publish(
                topic,
                json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
                qos=self.qos,
                retain=False,
            )
            ok = info.rc == mqtt.MQTT_ERR_SUCCESS
        except Exception:
            ok = False
        self.events.append({
            "schema": "hc_detext_map/v1", "camera_id": self.camera_id,
            "timestamp": time.time(), "kind": event, "topic": topic,
            **payload, "direction": "sent_hc", "publish_ok": int(ok),
        })
        return ok

    def _removal_event_id(self, state: dict) -> str:
        return (
            f"{self.session_id}:{self.camera_id}:"
            f"{int(state['pass_id'])}:local-removal"
        )

    def _hc_plate_id(self, state: dict) -> int:
        if (
            not self.receives_upstream
            and self.publishes_downstream
            and state.get("handoff_sequence") is not None
        ):
            return int(state["handoff_sequence"])
        return int(state["pass_id"])

