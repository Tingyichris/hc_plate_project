"""Markdown rendering for handoff results."""

from __future__ import annotations

import statistics
from collections import Counter


def _rate_row(label: str, value) -> str:
    return f"| {label} | {value:.1%} |" if value is not None else f"| {label} | 無資料 |"


def build_handoff_markdown(summary: dict, rows: list[dict]) -> str:
    """Build the human-readable handoff report from saved result rows."""
    matched_rows = [
        row for row in rows if row.get("handoff_status") == "fifo_paired"
    ]
    correct_rows = [row for row in matched_rows if str(row.get("color_correct")) == "1"]
    missing_rows = [row for row in rows if row.get("handoff_status") == "downstream_missing"]
    pickup_rows = [
        row for row in rows
        if row.get("handoff_status") == "removed_between_cameras"
    ]
    upstream_take_rows = [
        row for row in rows if row.get("handoff_status") == "removed_at_upstream"
    ]
    downstream_take_rows = [
        row for row in rows if row.get("handoff_status") == "removed_at_downstream"
    ]
    extra_rows = [row for row in rows if row.get("handoff_status") == "downstream_extra"]
    travel_times = [
        float(row["travel_time_s"])
        for row in matched_rows if str(row.get("travel_time_s", "")).strip()
    ]
    downstream_color_counts: dict[str, int] = {}
    comparison_counts: dict[tuple[str, str], int] = {}
    for row in rows:
        downstream_color = str(row.get("downstream_color", "")).strip()
        upstream_color = str(row.get("upstream_color", "")).strip()
        if downstream_color:
            downstream_color_counts[downstream_color] = (
                downstream_color_counts.get(downstream_color, 0) + 1
            )
        if upstream_color and downstream_color:
            key = (upstream_color, downstream_color)
            comparison_counts[key] = comparison_counts.get(key, 0) + 1
    lines = [
        "# 兩鏡頭銜接分析",
        "",
        "## 整體結果",
        "",
        "| 項目 | 結果 |",
        "|---|---:|",
        f"| cam-2 收到的 cam-3 盤數 | {summary['upstream_received']} |",
        f"| FIFO 配對（身分未驗證） | {summary['fifo_paired']} |",
        f"| 下游漏盤／未完成 | {summary['downstream_missing']} |",
        f"| 疑似在兩鏡頭間拿走 | {summary.get('removed_between_cameras', 0)} |",
        f"| 疑似在上游 cam-3 拿走 | {summary.get('removed_at_upstream', 0)} |",
        f"| 疑似在下游 cam-2 拿走 | {summary.get('removed_at_downstream', 0)} |",
        f"| 下游多餘盤 | {summary['downstream_extra']} |",
        _rate_row("FIFO 配對率（非身分準確率）", summary.get("fifo_pairing_rate")),
        _rate_row("FIFO 配對後顏色一致率", summary.get("color_agreement_rate_among_fifo_pairs")),
        "| 已由真值確認為同一實體盤 | 0 |",
        "",
        "計算方式：",
        "",
        "```text",
        "FIFO 配對率 = FIFO 配對盤數 / cam-2 實際收到的 cam-3 盤數",
        "顏色一致率 = 上下游顏色一致盤數 / FIFO 配對盤數",
        "FIFO 配對與顏色一致都不能證明是同一實體盤；身分準確率需要獨立真值。",
        "```",
        "",
        "> 注意：目前分母是 cam-2 已收到的 MQTT 盤數；cam-3 辨識到但 MQTT 發送失敗的盤，不會進入此分母，應搭配下方 MQTT 發送失敗數一起判讀。",
        "",
        "## 下游獨立判斷與上游差異",
        "",
        "cam-2 的模型、顏色投票與最終鎖定皆獨立執行；cam-3 傳來的顏色不參與 cam-2 判色或選擇配對，只在兩邊都完成後比較。",
        "",
        "### cam-2 自己鎖定的顏色",
        "",
        "| cam-2 顏色 | 盤數 |",
        "|---|---:|",
    ]
    if downstream_color_counts:
        for color, count in sorted(downstream_color_counts.items()):
            lines.append(f"| {color} | {count} |")
    else:
        lines.append("| 無資料 | 0 |")
    lines.extend([
        "",
        "### cam-3 收到值 → cam-2 自己判斷",
        "",
        "| cam-3 顏色 | cam-2 顏色 | 盤數 | 比較結果 |",
        "|---|---|---:|---|",
    ])
    if comparison_counts:
        for (upstream_color, downstream_color), count in sorted(comparison_counts.items()):
            result = "一致" if upstream_color == downstream_color else "不一致"
            lines.append(
                f"| {upstream_color} | {downstream_color} | {count} | {result} |"
            )
    else:
        lines.append("| 無資料 | 無資料 | 0 | 無法比較 |")
    lines.extend([
        "",
        "`downstream_color` 是 cam-2 自己的判斷；`upstream_color` 是 MQTT 收到的參考值；`color_correct` 只表示兩者是否一致。",
        "",
        "## 每圈結果",
        "",
        "| Lap | 上游盤數 | FIFO 配對 | 顏色一致 | 中途拿走 | 漏盤／未完成 | 多餘盤 | FIFO 配對率 | 顏色一致率 |",
        "|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ])
    lap_ids = sorted({int(row["lap_id"]) for row in rows if str(row.get("lap_id", "")).strip()})
    for lap_id in lap_ids:
        lap_rows = [row for row in rows if str(row.get("lap_id", "")) == str(lap_id)]
        lap_upstream = [row for row in lap_rows if str(row.get("upstream_pass_id", "")).strip()]
        lap_matched = [
            row for row in lap_rows
            if row.get("handoff_status") == "fifo_paired"
        ]
        lap_correct = [row for row in lap_matched if str(row.get("color_correct")) == "1"]
        lap_missing = sum(row.get("handoff_status") == "downstream_missing" for row in lap_rows)
        lap_pickup = sum(
            row.get("handoff_status") == "removed_between_cameras"
            for row in lap_rows
        )
        lap_extra = sum(row.get("handoff_status") == "downstream_extra" for row in lap_rows)
        handoff_rate = len(lap_matched) / len(lap_upstream) if lap_upstream else None
        color_rate = len(lap_correct) / len(lap_matched) if lap_matched else None
        lines.append(
            f"| {lap_id} | {len(lap_upstream)} | {len(lap_matched)} | {len(lap_correct)} "
            f"| {lap_pickup} | {lap_missing} | {lap_extra} | "
            f"{f'{handoff_rate:.1%}' if handoff_rate is not None else '無資料'} | "
            f"{f'{color_rate:.1%}' if color_rate is not None else '無資料'} |"
        )
    if not lap_ids:
        lines.append("| - | 0 | 0 | 0 | 0 | 0 | 0 | 無資料 | 無資料 |")

    lines.extend([
        "",
        "## 每盤銜接結果",
        "",
        "| Lap | 順序 | cam-3 Plate ID | cam-2 Plate ID | 上游顏色 | 下游顏色 | 結果 | 行程時間 | 下游 Tracker IDs |",
        "|---:|---:|---:|---:|---|---|---|---:|---|",
    ])
    def row_order(row):
        sequence = str(row.get("sequence", "")).strip()
        return (int(row.get("lap_id") or 0), int(sequence) if sequence else 10**9)
    for row in sorted(rows, key=row_order):
        status = str(row.get("handoff_status", ""))
        if status == "fifo_paired":
            result = (
                "FIFO 配對／顏色一致／身分未驗證"
                if str(row.get("color_correct")) == "1"
                else "FIFO 配對／顏色不一致／身分未驗證"
            )
        elif status == "removed_between_cameras":
            result = "疑似在兩鏡頭間拿走"
        elif status == "removed_at_upstream":
            result = "疑似在上游 cam-3 拿走"
        elif status == "removed_at_downstream":
            result = "疑似在下游 cam-2 拿走"
        elif status == "downstream_missing":
            result = "下游漏盤／未完成"
        else:
            result = "下游多餘盤"
        travel = row.get("travel_time_s", "")
        travel_text = f"{float(travel):.3f} s" if str(travel).strip() else "-"
        lines.append(
            f"| {row.get('lap_id', '-') or '-'} | {row.get('sequence', '-') or '-'} "
            f"| {row.get('upstream_pass_id', '-') or '-'} | {row.get('downstream_pass_id', '-') or '-'} "
            f"| {row.get('upstream_color', '-') or '-'} | {row.get('downstream_color', '-') or '-'} "
            f"| {result} | {travel_text} | {row.get('downstream_tracker_ids', '-') or '-'} |"
        )

    mismatches = [row for row in matched_rows if str(row.get("color_correct")) != "1"]
    lines.extend(["", "## 拿走位置判定", ""])
    color_names = {"orange": "O", "yellow": "Y", "light_green": "G"}
    def append_take_summary(label: str, take_rows: list[dict]) -> None:
        if not take_rows:
            lines.append(f"- {label}：0 盤。")
            return
        counts = Counter(str(row.get("upstream_color") or row.get("downstream_color") or "") for row in take_rows)
        colors = "、".join(
            f"{color_names.get(color, color)} × {count}"
            for color, count in sorted(counts.items())
        )
        sequences = "、".join(
            f"#{row.get('sequence')}"
            for row in sorted(take_rows, key=lambda item: int(item.get("sequence") or 0))
            if str(row.get("sequence", "")).strip()
        )
        suffix = f"；上游順序 {sequences}" if sequences else ""
        lines.append(f"- {label}：{len(take_rows)} 盤（{colors}）{suffix}。")
    append_take_summary("上游 cam-3 範圍拿走", upstream_take_rows)
    append_take_summary("兩鏡頭之間拿走", pickup_rows)
    append_take_summary("下游 cam-2 範圍拿走", downstream_take_rows)

    lines.extend(["", "### 兩鏡頭之間明細", ""])
    if pickup_rows:
        pickup_counts = Counter(str(row.get("upstream_color", "")) for row in pickup_rows)
        lines.append(f"- 判定有拿走：共 {len(pickup_rows)} 盤。")
        lines.append(
            "- 顏色數量：" + "、".join(
                f"{color_names.get(color, color)} × {count}"
                for color, count in sorted(pickup_counts.items())
            ) + "。"
        )
        lines.append(
            "- 上游順序：" + "、".join(
                f"#{row.get('sequence')} "
                f"{color_names.get(str(row.get('upstream_color', '')), row.get('upstream_color', ''))}"
                for row in sorted(pickup_rows, key=lambda item: int(item.get("sequence") or 0))
            ) + "。"
        )
    else:
        lines.append("- 未判定有盤子在兩鏡頭之間被拿走。")
    lines.append(
        "- 判定依據：上游已完成鎖定，且超過本次行程時間窗仍未抵達下游；"
        "若 cam-2 本身漏辨識，仍可能形成相同現象，需搭配影像異常紀錄確認。"
    )

    lines.extend(["", "## 異常摘要", ""])
    anomaly_groups = (mismatches, missing_rows, extra_rows, pickup_rows, upstream_take_rows, downstream_take_rows)
    if not any(anomaly_groups):
        lines.append("- 本次沒有顏色不一致、下游漏盤或下游多餘盤。")
    else:
        for row in mismatches:
            lines.append(
                f"- 顏色不一致：L{row.get('lap_id')}，cam-3 P{row.get('upstream_pass_id')} "
                f"`{row.get('upstream_color')}` → cam-2 P{row.get('downstream_pass_id')} "
                f"`{row.get('downstream_color')}`。"
            )
        for row in missing_rows:
            lines.append(
                f"- 下游漏盤／未完成：L{row.get('lap_id')}，cam-3 P{row.get('upstream_pass_id')}，順序 {row.get('sequence')}。"
            )
        for row in pickup_rows:
            lines.append(
                f"- 疑似中途拿走：L{row.get('lap_id')}，順序 {row.get('sequence')}，"
                f"cam-3 P{row.get('upstream_pass_id')} `{row.get('upstream_color')}`。"
            )
        for row in upstream_take_rows:
            lines.append(
                f"- 疑似上游拿走：L{row.get('lap_id')}，順序 {row.get('sequence')}，"
                f"P{row.get('upstream_pass_id')} `{row.get('upstream_color')}`。"
            )
        for row in downstream_take_rows:
            lines.append(
                f"- 疑似下游拿走：L{row.get('lap_id')}，順序 {row.get('sequence')}，"
                f"cam-2 P{row.get('downstream_pass_id')} `{row.get('downstream_color')}`。"
            )
        for row in extra_rows:
            lines.append(
                f"- 下游多餘盤：L{row.get('lap_id')}，cam-2 P{row.get('downstream_pass_id')}，沒有可配對的上游資料。"
            )

    lines.extend(["", "## 行程時間", ""])
    if travel_times:
        lines.extend([
            f"- FIFO 配對樣本（身分未驗證）：{len(travel_times)}",
            f"- 最短：{min(travel_times):.3f} 秒",
            f"- 中位數：{statistics.median(travel_times):.3f} 秒",
            f"- 最長：{max(travel_times):.3f} 秒",
            "- 行程時間窗已用於中途拿走判定與後續盤重新對齊。",
        ])
    else:
        lines.append("- 無 FIFO 配對樣本。")

    lines.extend([
        "",
        "## MQTT 穩定性",
        "",
        "| Camera | 連線 | 斷線 | 重連 | 發送成功 | 發送失敗 | 收到訊息 | 重複 | 亂序 | 事件閃爍 | Heartbeat 中斷 |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ])
    for camera_id, stats in summary.get("mqtt", {}).items():
        lines.append(
            f"| {camera_id} | {stats.get('connect_count', 0)} | {stats.get('disconnect_count', 0)} "
            f"| {stats.get('reconnect_count', 0)} | {stats.get('publish_success', 0)} "
            f"| {stats.get('publish_failure', 0)} | {stats.get('messages_received', 0)} "
            f"| {stats.get('duplicate_messages', 0)} | {stats.get('out_of_order_events', 0)} "
            f"| {stats.get('event_flickers', 0)} | {stats.get('heartbeat_gaps', 0)} |"
        )
    lines.extend([
        "",
        "判定說明：發送失敗包含未連上 broker、斷線期間發布、MQTT 回傳錯誤或發送例外；事件閃爍是同一盤同類事件在 1 秒內重複；Heartbeat 中斷是超過 6 秒未收到對方狀態。",
        "",
    ])
    # Show each camera's own judgment independently of MQTT/FIFO pairing.
    lines.extend([
        "", "## 上游單獨判斷（cam-3）", "",
        "此表只列 cam-3 自己鎖定並送出的結果，不使用下游結果修正。", "",
        "| Lap | 順序 | 上游 Plate ID | 上游判斷顏色 | 信心值 | MQTT 發送時間 |",
        "|---:|---:|---:|---|---:|---:|",
    ])
    upstream_seen: set[tuple[str, str]] = set()
    upstream_rows = []
    for row in sorted(rows, key=row_order):
        pass_id = str(row.get("upstream_pass_id", "")).strip()
        if not pass_id:
            continue
        key = (str(row.get("upstream_session_id", "")), pass_id)
        if key in upstream_seen:
            continue
        upstream_seen.add(key)
        upstream_rows.append(row)
    if upstream_rows:
        for row in upstream_rows:
            lines.append(
                f"| {row.get('lap_id', '-') or '-'} | {row.get('sequence', '-') or '-'} "
                f"| {row.get('upstream_pass_id', '-') or '-'} | {row.get('upstream_color', '-') or '-'} "
                f"| {row.get('upstream_confidence', '-') or '-'} "
                f"| {row.get('upstream_published_at', '-') or '-'} |"
            )
    else:
        lines.append("| - | - | - | 無資料 | - | - |")

    lines.extend([
        "", "## 下游單獨判斷（cam-2）", "",
        "此表只列 cam-2 自己實際偵測並鎖定的結果，不以上游顏色作為判斷輸入。", "",
        "| Lap | 下游 Plate ID | 下游判斷顏色 | 信心值 | Tracker IDs | 第一次看到時間 | 鎖定時間 |",
        "|---:|---:|---|---:|---|---:|---:|",
    ])
    downstream_seen: set[tuple[str, str]] = set()
    downstream_rows = []
    for row in sorted(rows, key=row_order):
        pass_id = str(row.get("downstream_pass_id", "")).strip()
        if not pass_id:
            continue
        key = (str(row.get("lap_id", "")), pass_id)
        if key in downstream_seen:
            continue
        downstream_seen.add(key)
        downstream_rows.append(row)
    if downstream_rows:
        def downstream_pass_order(row):
            value = str(row.get("downstream_pass_id", "")).strip()
            return int(value) if value.isdigit() else 10**9

        downstream_rows.sort(key=downstream_pass_order)
        for row in downstream_rows:
            lines.append(
                f"| {row.get('lap_id', '-') or '-'} | {row.get('downstream_pass_id', '-') or '-'} "
                f"| {row.get('downstream_color', '-') or '-'} | {row.get('downstream_confidence', '-') or '-'} "
                f"| {row.get('downstream_tracker_ids', '-') or '-'} "
                f"| {row.get('downstream_first_seen_at', '-') or '-'} "
                f"| {row.get('downstream_locked_at', '-') or '-'} |"
            )
    else:
        lines.append("| - | - | 無資料 | - | - | - | - |")

    upstream_colors = [str(row.get("upstream_color", "")) for row in upstream_rows]
    downstream_colors = [str(row.get("downstream_color", "")) for row in downstream_rows]
    compared = min(len(upstream_colors), len(downstream_colors))
    independently_equal = sum(
        upstream_colors[index] == downstream_colors[index]
        for index in range(compared)
    )
    lines.extend(["", "### 兩邊獨立順序比較", ""])
    if compared:
        lines.append(
            f"- 依兩邊各自 Plate ID 順序比較：{independently_equal}/{compared} "
            f"（{independently_equal / compared:.1%}）顏色一致。"
        )
        if len(upstream_colors) != len(downstream_colors):
            lines.append(
                f"- 盤數不同：上游 {len(upstream_colors)} 盤，下游 {len(downstream_colors)} 盤。"
            )
    else:
        lines.append("- 沒有足夠資料可比較。")

    return "\n".join(lines)


