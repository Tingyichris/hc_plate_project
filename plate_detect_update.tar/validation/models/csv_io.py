"""CSV helpers shared by validation reports and re-analysis tools."""

from __future__ import annotations

import csv
from pathlib import Path


def read_csv(path: Path, missing_ok: bool = False) -> list[dict]:
    """Read a UTF-8 (BOM tolerant) CSV as dicts; return [] for a missing file when allowed."""
    path = Path(path)
    if missing_ok and not path.exists():
        return []
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict], fields: list[str]) -> None:
    with Path(path).open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
