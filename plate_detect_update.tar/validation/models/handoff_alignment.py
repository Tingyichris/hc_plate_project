"""Monotonic cross-camera event alignment."""

from __future__ import annotations

from .handoff_constants import (
    ALIGNMENT_GAP_COST,
    ALIGNMENT_MAX_TIME_ERROR_SECONDS,
    DEFAULT_TRAVEL_SECONDS,
    TRAVEL_WINDOW_MIN_SLACK_SECONDS,
)
def align_monotonic_events(
    upstream: list[dict],
    downstream: list[dict],
    expected_travel_s: float = DEFAULT_TRAVEL_SECONDS,
) -> list[dict]:
    """Globally align two ordered camera streams without allowing overtakes.

    A match pays normalized travel-time error.  Skipping either side pays a
    fixed gap cost.  Unlike online FIFO, a missing plate therefore does not
    force every following plate to shift by one position.
    """
    n, m = len(upstream), len(downstream)
    inf = float("inf")
    dp = [[inf] * (m + 1) for _ in range(n + 1)]
    previous: list[list[tuple[int, int, str] | None]] = [
        [None] * (m + 1) for _ in range(n + 1)
    ]
    dp[0][0] = 0.0
    for i in range(1, n + 1):
        dp[i][0] = dp[i - 1][0] + ALIGNMENT_GAP_COST
        previous[i][0] = (i - 1, 0, "skip_upstream")
    for j in range(1, m + 1):
        dp[0][j] = dp[0][j - 1] + ALIGNMENT_GAP_COST
        previous[0][j] = (0, j - 1, "skip_downstream")

    for i in range(1, n + 1):
        for j in range(1, m + 1):
            choices = [
                (dp[i - 1][j] + ALIGNMENT_GAP_COST, i - 1, j, "skip_upstream"),
                (dp[i][j - 1] + ALIGNMENT_GAP_COST, i, j - 1, "skip_downstream"),
            ]
            travel = (
                float(downstream[j - 1]["first_seen_at"])
                - float(upstream[i - 1]["detected_at"])
            )
            error = abs(travel - float(expected_travel_s))
            if error <= ALIGNMENT_MAX_TIME_ERROR_SECONDS:
                match_cost = error / TRAVEL_WINDOW_MIN_SLACK_SECONDS
                choices.append((dp[i - 1][j - 1] + match_cost, i - 1, j - 1, "match"))
            best = min(choices, key=lambda item: item[0])
            dp[i][j] = best[0]
            previous[i][j] = (best[1], best[2], best[3])

    operations = []
    i, j = n, m
    while i or j:
        step = previous[i][j]
        if step is None:  # pragma: no cover - defensive guard
            break
        pi, pj, operation = step
        item = {"operation": operation}
        if operation in {"match", "skip_upstream"}:
            item["upstream"] = upstream[i - 1]
        if operation in {"match", "skip_downstream"}:
            item["downstream"] = downstream[j - 1]
        if operation == "match":
            item["travel_time_s"] = round(
                float(downstream[j - 1]["first_seen_at"])
                - float(upstream[i - 1]["detected_at"]),
                4,
            )
        operations.append(item)
        i, j = pi, pj
    operations.reverse()
    return operations


