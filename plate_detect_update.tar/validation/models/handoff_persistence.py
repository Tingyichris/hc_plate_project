"""Snapshot and final persistence for handoff sessions."""

from __future__ import annotations

import csv
import json
import statistics
import time
from collections import Counter

from .handoff_report import build_handoff_markdown


class HandoffPersistenceMixin:
    def snapshot(self) -> None:
        """Persist a live snapshot without declaring pending plates missing."""
        with self._lock:
            self.save(finalize_pending=False)

    def save(self, finalize_pending: bool = True) -> None:
        self.output_directory.mkdir(parents=True, exist_ok=True)
        lifecycle_direction = "sent" if self.publishes_downstream else "received"
        lifecycle_events = [
            event for event in self.events
            if event.get("kind") in {
                "plate_detected", "plate_updated", "plate_final",
                "plate_removed", "plate_locked",
            }
            and event.get("direction") == lifecycle_direction
        ]
        lifecycle_by_key: dict[tuple[str, str], dict] = {}
        for event in lifecycle_events:
            key = (
                str(event.get("session_id", "")),
                str(event.get("upstream_pass_id", "")),
            )
            item = lifecycle_by_key.setdefault(key, {
                "session_id": key[0],
                "lap_id": event.get("lap_id", ""),
                "sequence": event.get("sequence", ""),
                "upstream_pass_id": key[1],
                "detected_color": "",
                "final_color": "",
                "status": "detected",
                "detected_at": "",
                "final_at": "",
                "removed_at": "",
            })
            kind = event.get("kind")
            if kind in {"plate_detected", "plate_locked"}:
                item["detected_color"] = event.get("color", "")
                item["detected_at"] = event.get("timestamp", "")
                if kind == "plate_locked":
                    item["final_color"] = event.get("color", "")
                    item["final_at"] = event.get("timestamp", "")
                    item["status"] = "final"
            elif kind == "plate_updated":
                item["detected_color"] = event.get("color", "")
            elif kind == "plate_final":
                item["final_color"] = event.get("color", "")
                item["final_at"] = event.get("timestamp", "")
                item["status"] = "final"
            elif kind == "plate_removed":
                item["removed_at"] = event.get("timestamp", "")
                item["status"] = "removed"
        lifecycle_fields = [
            "session_id", "lap_id", "sequence", "upstream_pass_id",
            "detected_color", "final_color", "status", "detected_at",
            "final_at", "removed_at",
        ]
        with (self.output_directory / "upstream_lifecycle.csv").open(
            "w", newline="", encoding="utf-8-sig"
        ) as handle:
            writer = csv.DictWriter(handle, fieldnames=lifecycle_fields)
            writer.writeheader()
            writer.writerows(lifecycle_by_key.values())

        inventory = [
            event for event in lifecycle_events
            if event.get("kind") in {"plate_final", "plate_locked"}
        ]
        inventory_fields = [
            "session_id", "lap_id", "sequence", "upstream_pass_id", "color",
            "confidence", "observations", "timestamp", "publish_ok",
        ]
        with (self.output_directory / "upstream_inventory.csv").open(
            "w", newline="", encoding="utf-8-sig"
        ) as handle:
            writer = csv.DictWriter(handle, fieldnames=inventory_fields)
            writer.writeheader()
            writer.writerows(
                {key: event.get(key, "") for key in inventory_fields}
                for event in inventory
            )
        if self.publishes_downstream:
            inventory_lines = [
                "# 上游自動盤子清單", "",
                f"共確認並發布 {len(inventory)} 盤。", "",
                "| 順序 | Plate ID | 顏色 | Confidence | Observations | MQTT |",
                "|---:|---:|---|---:|---:|---|",
            ]
            for event in inventory:
                inventory_lines.append(
                    f"| {event.get('sequence')} | {event.get('upstream_pass_id')} "
                    f"| {event.get('color')} | {event.get('confidence')} "
                    f"| {event.get('observations')} "
                    f"| {'成功' if event.get('publish_ok') else '失敗'} |"
                )
            (self.output_directory / "upstream_inventory_summary.md").write_text(
                "\n".join(inventory_lines) + "\n", encoding="utf-8"
            )
        if (
            self.receives_upstream
            and finalize_pending
            and self.matching_mode == "fifo"
        ):
            self._expire_overdue_pending(time.time())
            existing_missing = {
                (row.get("upstream_session_id"), row.get("upstream_pass_id"))
                for row in self.rows
            }
            for upstream in self._pending:
                key = (upstream.get("session_id"), upstream.get("upstream_pass_id"))
                if key in existing_missing:
                    continue
                self._report_unarrived(upstream, timed_out=False)
                existing_missing.add(key)
            finalized_downstream_ids = {
                int(row["downstream_pass_id"])
                for row in self.rows
                if str(row.get("downstream_pass_id", "")).strip()
            }
            for downstream_pass_id, upstream in self._matched_by_pass.items():
                if downstream_pass_id in finalized_downstream_ids:
                    continue
                key = (upstream.get("session_id"), upstream.get("upstream_pass_id"))
                if key in existing_missing:
                    continue
                self.rows.append({
                    "upstream_session_id": upstream.get("session_id", ""),
                    "upstream_pass_id": upstream.get("upstream_pass_id", ""),
                    "downstream_pass_id": downstream_pass_id,
                    "lap_id": upstream.get("lap_id", ""),
                    "sequence": upstream.get("sequence", ""),
                    "upstream_color": upstream.get("color", ""),
                    "downstream_color": "",
                    "color_correct": "",
                    "handoff_status": "downstream_missing",
                    "travel_time_s": round(float(upstream.get("travel_time_s", 0.0)), 4),
                    "upstream_confidence": upstream.get("confidence", ""),
                    "downstream_confidence": "",
                    "downstream_tracker_ids": "",
                })
                existing_missing.add(key)

        fields = [
            "upstream_session_id", "upstream_pass_id", "downstream_pass_id",
            "lap_id", "sequence", "upstream_color", "downstream_color",
            "color_correct", "handoff_status", "pairing_method",
            "identity_status", "travel_time_s",
            "upstream_confidence", "downstream_confidence",
            "downstream_tracker_ids",
            "upstream_published_at", "downstream_mqtt_received_at",
            "mqtt_delay_ms", "downstream_first_seen_at", "downstream_locked_at",
        ]
        for row in self.rows:
            if row.get("handoff_status") == "fifo_paired":
                row["pairing_method"] = "fifo"
                row["identity_status"] = "unverified"
            else:
                row.setdefault("pairing_method", "")
                row.setdefault("identity_status", "not_applicable")

        with (self.output_directory / "handoff_results.csv").open(
            "w", newline="", encoding="utf-8-sig"
        ) as handle:
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader()
            writer.writerows(self.rows)

        with (self.output_directory / "mqtt_events.jsonl").open(
            "w", encoding="utf-8"
        ) as handle:
            for event in self.events:
                handle.write(json.dumps(event, ensure_ascii=False) + "\n")

        received_keys = {
            (str(event.get("session_id", "")), str(event.get("upstream_pass_id", "")))
            for event in self.events
            if event.get("kind") in {"plate_detected", "plate_locked"}
            and event.get("direction") == "received"
        }
        sent = len(received_keys)
        fifo_paired = sum(
            row["handoff_status"] == "fifo_paired" for row in self.rows
        )
        correct = sum(row.get("color_correct") == 1 for row in self.rows)
        pickup_rows = [
            row for row in self.rows
            if row.get("handoff_status") == "removed_between_cameras"
        ]
        upstream_take_rows = [
            row for row in self.rows
            if row.get("handoff_status") == "removed_at_upstream"
        ]
        downstream_take_rows = [
            row for row in self.rows
            if row.get("handoff_status") == "removed_at_downstream"
        ]
        mqtt_stats = {
            key: self._public_stats(value) for key, value in self.stats.items()
        }
        mqtt_health = {
            "publish_failure": sum(
                int(item.get("publish_failure", 0))
                for item in mqtt_stats.values()
            ),
            "disconnect_count": sum(
                int(item.get("disconnect_count", 0))
                for item in mqtt_stats.values()
            ),
            "duplicate_messages": sum(
                int(item.get("duplicate_messages", 0))
                for item in mqtt_stats.values()
            ),
            "out_of_order_events": sum(
                int(item.get("out_of_order_events", 0))
                for item in mqtt_stats.values()
            ),
        }
        mqtt_health["healthy"] = all(
            value == 0 for value in mqtt_health.values()
        )
        summary = {
            "role": self.role,
            "camera_id": self.camera_id,
            "peer_camera_id": self.peer_camera_id,
            "upstream_camera_id": self.upstream_camera_id,
            "downstream_camera_id": self.downstream_camera_id,
            "upstream_received": sent,
            "fifo_paired": fifo_paired,
            "color_agreement_count": correct,
            "identity_verified_count": 0,
            "identity_unverified_count": fifo_paired,
            "downstream_missing": sum(row["handoff_status"] == "downstream_missing" for row in self.rows),
            "removed_between_cameras": len(pickup_rows),
            "removed_at_upstream": len(upstream_take_rows),
            "removed_at_downstream": len(downstream_take_rows),
            "removed_at_upstream_color_counts": dict(sorted(Counter(
                str(row.get("upstream_color", ""))
                for row in upstream_take_rows
                if str(row.get("upstream_color", "")).strip()
            ).items())),
            "removed_at_downstream_color_counts": dict(sorted(Counter(
                str(row.get("downstream_color", ""))
                for row in downstream_take_rows
                if str(row.get("downstream_color", "")).strip()
            ).items())),
            "removed_color_counts": dict(sorted(Counter(
                str(row.get("upstream_color", ""))
                for row in pickup_rows
                if str(row.get("upstream_color", "")).strip()
            ).items())),
            "removed_sequences": [
                int(row["sequence"])
                for row in sorted(
                    pickup_rows, key=lambda item: int(item.get("sequence") or 0)
                )
                if str(row.get("sequence", "")).strip()
            ],
            "downstream_extra": sum(row["handoff_status"] == "downstream_extra" for row in self.rows),
            "upstream_removed": sum(
                item.get("status") == "removed"
                for item in lifecycle_by_key.values()
            ),
            "fifo_pairing_rate": fifo_paired / sent if sent else None,
            "color_agreement_rate_among_fifo_pairs": (
                correct / fifo_paired if fifo_paired else None
            ),
            "identity_accuracy": None,
            "identity_accuracy_reason": "ground_truth_not_provided",
            "travel_time_median_s": statistics.median(self._travel_samples) if self._travel_samples else None,
            "downstream_local_color_counts": dict(
                sorted(
                    Counter(
                        str(row.get("downstream_color", ""))
                        for row in self.rows
                        if str(row.get("downstream_color", "")).strip()
                    ).items()
                )
            ),
            "mqtt_health": mqtt_health,
            "mqtt": mqtt_stats,
        }
        (self.output_directory / "handoff_summary.json").write_text(
            json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        (self.output_directory / "handoff_analysis_summary.md").write_text(
            build_handoff_markdown(summary, self.rows), encoding="utf-8"
        )
        if self.matching_mode == "dp":
            self._save_authoritative_alignment()
