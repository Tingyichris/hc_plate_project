"""Upstream publication and live alignment behavior."""

from __future__ import annotations

import statistics
import time

from .handoff_alignment import align_monotonic_events
from .handoff_constants import (
    ALIGNMENT_MAX_TIME_ERROR_SECONDS,
    DEFAULT_TRAVEL_SECONDS,
    HEARTBEAT_MISSING_SECONDS,
    HEARTBEAT_SECONDS,
    TRAVEL_WINDOW_MAX_SLACK_SECONDS,
    TRAVEL_WINDOW_MIN_SLACK_SECONDS,
)


class HandoffUpstreamMixin:
    def suspect_local_removal(self, state: dict) -> None:
        color = str(
            state.get("final_color")
            or state.get("handoff_color")
            or "unknown"
        )
        self._publish_hc_event(
            "catch_suspected", self._hc_plate_id(state), color,
            int(state["pass_id"]),
            {"event_id": self._removal_event_id(state), "status": "suspected"},
        )

    def revoke_local_removal(self, state: dict) -> None:
        color = str(
            state.get("final_color")
            or state.get("handoff_color")
            or "unknown"
        )
        self._publish_hc_event(
            "catch_revoked", self._hc_plate_id(state), color,
            int(state["pass_id"]),
            {"event_id": self._removal_event_id(state), "status": "revoked"},
        )

    def tick(self) -> None:
        now = time.time()
        if now - self._last_heartbeat_sent >= HEARTBEAT_SECONDS:
            self._last_heartbeat_sent = now
            self._publish_hc_status("online")
            self._publish(
                "heartbeat",
                {
                    "state": "online",
                    "mqtt_stats": self._public_stats(self.stats[self.camera_id]),
                },
            )
        for camera_id, last_seen in list(self._peer_last_heartbeat.items()):
            stats = self.stats.setdefault(camera_id, self._empty_stats())
            if now - last_seen > HEARTBEAT_MISSING_SECONDS:
                marker = int(now // HEARTBEAT_MISSING_SECONDS)
                if stats.get("_gap_marker") != marker:
                    stats["heartbeat_gaps"] += 1
                    stats["_gap_marker"] = marker
        if self.receives_upstream and self.matching_mode == "dp":
            with self._lock:
                self._recompute_live_alignment()
        elif self.receives_upstream:
            with self._lock:
                self._expire_overdue_pending(now)

    def _recompute_live_alignment(self) -> None:
        if not self.receives_upstream or self.matching_mode != "dp":
            return
        upstream = sorted(
            (
                {**item, "detected_at": float(item.get("timestamp", 0.0))}
                for item in self._upstream_lifecycle.values()
                if not item.get("removed")
            ),
            key=lambda item: int(item.get("sequence", 0)),
        )
        downstream = sorted(
            self._downstream_lifecycle.values(),
            key=lambda item: (
                float(item.get("first_seen_at", 0.0)),
                int(item.get("pass_id", 0)),
            ),
        )
        operations = align_monotonic_events(
            upstream, downstream, DEFAULT_TRAVEL_SECONDS
        )
        selected = {
            (int(item["upstream"].get("upstream_pass_id", 0)),
             int(item["downstream"].get("pass_id", 0)))
            for item in operations if item["operation"] == "match"
        }
        candidates = []
        for source in upstream:
            for target in downstream:
                travel = (
                    float(target["first_seen_at"])
                    - float(source["detected_at"])
                )
                error = abs(travel - DEFAULT_TRAVEL_SECONDS)
                allowed = error <= ALIGNMENT_MAX_TIME_ERROR_SECONDS
                pair = (
                    int(source.get("upstream_pass_id", 0)),
                    int(target.get("pass_id", 0)),
                )
                candidates.append({
                    "source_camera_id": self.upstream_camera_id,
                    "source_local_pass_id": pair[0],
                    "source_sequence": source.get("sequence", ""),
                    "target_camera_id": self.camera_id,
                    "target_local_pass_id": pair[1],
                    "travel_time_s": round(travel, 4),
                    "expected_travel_time_s": DEFAULT_TRAVEL_SECONDS,
                    "time_error_s": round(error, 4),
                    "total_cost": (
                        round(error / TRAVEL_WINDOW_MIN_SLACK_SECONDS, 6)
                        if allowed else None
                    ),
                    "hard_gate_results": {"travel_time": allowed},
                    "selected": pair in selected,
                    "rejection_reason": "" if allowed else "travel_time_outlier",
                })
        bindings = {}
        for item in operations:
            if item["operation"] != "match":
                continue
            source = item["upstream"]
            target = item["downstream"]
            source["matched_at"] = float(target["first_seen_at"])
            source["travel_time_s"] = float(item["travel_time_s"])
            bindings[int(target["pass_id"])] = source
        self._matched_by_pass = bindings
        self._live_alignment_operations = operations
        self._alignment_candidates = candidates

    def _travel_window(self) -> tuple[float, float]:
        """Return the current arrival estimate and symmetric tolerance."""
        if len(self._travel_samples) >= 3:
            estimate = statistics.median(self._travel_samples)
            spread = statistics.pstdev(self._travel_samples)
            slack = max(TRAVEL_WINDOW_MIN_SLACK_SECONDS, spread * 3.0)
            return estimate, min(TRAVEL_WINDOW_MAX_SLACK_SECONDS, slack)
        return DEFAULT_TRAVEL_SECONDS, TRAVEL_WINDOW_MIN_SLACK_SECONDS

    @staticmethod
    def _unarrived_row(upstream: dict, status: str) -> dict:
        return {
            "upstream_session_id": upstream.get("session_id", ""),
            "upstream_pass_id": upstream.get("upstream_pass_id", ""),
            "downstream_pass_id": "",
            "lap_id": upstream.get("lap_id", ""),
            "sequence": upstream.get("sequence", ""),
            "upstream_color": upstream.get("color", ""),
            "downstream_color": "",
            "color_correct": "",
            "handoff_status": status,
            "travel_time_s": "",
            "upstream_confidence": upstream.get("confidence", ""),
            "downstream_confidence": "",
            "downstream_tracker_ids": "",
            "upstream_published_at": upstream.get("timestamp", ""),
            "downstream_mqtt_received_at": upstream.get("received_at", ""),
        }

    def _report_unarrived(self, upstream: dict, timed_out: bool) -> None:
        key = (
            str(upstream.get("session_id", "")),
            int(upstream.get("upstream_pass_id", 0)),
        )
        if key in self._reported_unarrived:
            return
        self._reported_unarrived.add(key)
        # Only an upstream plate that reached its final line can be considered
        # a pickup between cameras.  Early detections that vanished upstream
        # remain ordinary incomplete detections.
        status = (
            "removed_between_cameras"
            if timed_out and upstream.get("final_received")
            else "downstream_missing"
        )
        self.rows.append(self._unarrived_row(upstream, status))

    def _expire_overdue_pending(self, now: float) -> None:
        estimate, slack = self._travel_window()
        while self._pending:
            oldest = self._pending[0]
            expected = float(oldest["timestamp"]) + estimate
            if now <= expected + slack:
                break
            expired = self._pending.popleft()
            self._report_unarrived(expired, timed_out=True)

    def start_lap(self, lap_id: int) -> None:
        self._publish("lap_start", {"lap_id": int(lap_id)})

    def publish_locked_plate(self, state: dict) -> None:
        if not self.publishes_downstream or not state.get("final_color"):
            return
        sequence = self._next_sequence
        self._next_sequence += 1
        ok = self._publish(
            "plate_locked",
            {
                "lap_id": int(state["lap_id"]),
                "upstream_pass_id": int(state["pass_id"]),
                "sequence": sequence,
                "color": str(state["final_color"]),
                "confidence": state.get("final_confidence_median"),
                "observations": int(state.get("final_observations", 0)),
            },
        )
        print(
            f"UPSTREAM #{sequence}: P{int(state['pass_id'])} "
            f"color={state['final_color']} mqtt={'ok' if ok else 'failed'}"
        )

    def publish_detected_plate(
        self, state: dict, color: str, confidence: float | None, observations: int
    ) -> bool:
        """Publish a reversible upstream lifecycle as soon as one plate is credible."""
        if not self.publishes_downstream or not color:
            return False
        if state.get("handoff_detected"):
            previous = str(state.get("handoff_color", ""))
            if previous != str(color):
                state["handoff_color"] = str(color)
                self._publish("plate_updated", {
                    "lap_id": int(state["lap_id"]),
                    "upstream_pass_id": int(state["pass_id"]),
                    "sequence": int(state["handoff_sequence"]),
                    "color": str(color),
                    "confidence": confidence,
                    "observations": int(observations),
                    "handoff_id": str(
                        state.get("handoff_id")
                        or f"{self.session_id}:{int(state['handoff_sequence'])}"
                    ),
                })
                self._publish_hc_event(
                    "update", int(state["handoff_sequence"]), str(color),
                    int(state["pass_id"]),
                    {
                        "handoff_id": str(
                            state.get("handoff_id")
                            or f"{self.session_id}:{int(state['handoff_sequence'])}"
                        ),
                        "status": "confirmed",
                    },
                )
            return True
        sequence = self._next_sequence
        self._next_sequence += 1
        state["handoff_detected"] = True
        state["handoff_sequence"] = sequence
        state["handoff_color"] = str(color)
        binding = self._matched_by_pass.get(int(state["pass_id"]))
        handoff_id = str(
            (binding or {}).get("handoff_id")
            or state.get("handoff_id")
            or f"{self.session_id}:{sequence}"
        )
        state["handoff_id"] = handoff_id
        ok = self._publish("plate_detected", {
            "lap_id": int(state["lap_id"]),
            "upstream_pass_id": int(state["pass_id"]),
            "sequence": sequence,
            "color": str(color),
            "confidence": confidence,
            "observations": int(observations),
            "handoff_id": handoff_id,
        })
        print(
            f"UPSTREAM DETECTED #{sequence}: P{int(state['pass_id'])} "
            f"color={color} mqtt={'ok' if ok else 'failed'}"
        )
        self._publish_hc_event(
            "entry", sequence, str(color), int(state["pass_id"]),
            {
                "handoff_id": handoff_id,
                "status": "provisional",
                "color_source": "upstream_local",
            },
        )
        return ok

    def publish_final_plate(self, state: dict) -> None:
        """Finalize an already announced upstream ID after the exit line."""
        if not self.publishes_downstream or not state.get("final_color"):
            return
        if not state.get("handoff_detected"):
            self.publish_detected_plate(
                state,
                str(state["final_color"]),
                state.get("final_confidence_median"),
                int(state.get("final_observations", 0)),
            )
        if state.get("handoff_final"):
            return
        state["handoff_final"] = True
        self._publish("plate_final", {
            "lap_id": int(state["lap_id"]),
            "upstream_pass_id": int(state["pass_id"]),
            "sequence": int(state["handoff_sequence"]),
            "color": str(state["final_color"]),
            "confidence": state.get("final_confidence_median"),
            "observations": int(state.get("final_observations", 0)),
            "handoff_id": str(
                state.get("handoff_id")
                or f"{self.session_id}:{int(state['handoff_sequence'])}"
            ),
        })
        self._publish_hc_event(
            "exit", int(state["handoff_sequence"]),
            str(state["final_color"]), int(state["pass_id"]),
            {
                "handoff_id": str(
                    state.get("handoff_id")
                    or f"{self.session_id}:{int(state['handoff_sequence'])}"
                ),
                "status": "confirmed",
            },
        )

    def publish_removed_plate(self, state: dict) -> None:
        """Cancel an early ID that disappeared before crossing the exit line."""
        if (
            not self.publishes_downstream
            or not state.get("handoff_detected")
            or state.get("handoff_final")
            or state.get("handoff_removed")
        ):
            return
        state["handoff_removed"] = True
        self._publish("plate_removed", {
            "lap_id": int(state["lap_id"]),
            "upstream_pass_id": int(state["pass_id"]),
            "sequence": int(state["handoff_sequence"]),
            "color": str(state.get("handoff_color", "")),
            "reason": "disappeared_before_exit",
            "handoff_id": str(
                state.get("handoff_id")
                or f"{self.session_id}:{int(state['handoff_sequence'])}"
            ),
        })
        self._publish_hc_event(
            "catch", int(state["handoff_sequence"]),
            str(state.get("handoff_color", "unknown")), int(state["pass_id"]),
            {
                "event_id": self._removal_event_id(state),
                "handoff_id": str(
                    state.get("handoff_id")
                    or f"{self.session_id}:{int(state['handoff_sequence'])}"
                ),
                "status": "confirmed",
            },
        )

