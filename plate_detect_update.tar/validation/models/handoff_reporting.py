"""Authoritative alignment and live status reporting."""

from __future__ import annotations

import hashlib
import json
import time
from collections import Counter

from .handoff_alignment import align_monotonic_events
from .handoff_constants import (
    ALIGNMENT_GAP_COST,
    ALIGNMENT_MAX_TIME_ERROR_SECONDS,
    DEFAULT_TRAVEL_SECONDS,
)


class HandoffReportingMixin:
    def display_lines(self) -> list[str]:
        peer = self.stats.get(self.upstream_camera_id, {})
        return [
            f"handoff={self.role} mqtt={'up' if self._connected else 'down'}",
            (
                f"edge={self.upstream_camera_id or '-'}>{self.camera_id}>"
                f"{self.downstream_camera_id or '-'}"
            ),
            (
                f"pending={len(self._pending)} result_rows={len(self.rows)} "
                f"peer_flicker={peer.get('event_flickers', 0)}"
            ),
        ]

    @staticmethod
    def _public_stats(stats: dict) -> dict:
        return {key: value for key, value in stats.items() if not key.startswith("_")}

    def _authoritative_alignment(self) -> tuple[dict, list[dict]]:
        """Build the final non-greedy result from complete local lifecycles."""
        upstream_all = sorted(
            self._upstream_lifecycle.values(),
            key=lambda item: int(item.get("sequence", 0)),
        )
        upstream_removed = [item for item in upstream_all if item.get("removed")]
        upstream_final = [
            {
                **item,
                "detected_at": float(item.get("timestamp", 0.0)),
            }
            for item in upstream_all
            if item.get("final_received") and not item.get("removed")
        ]
        downstream_all = sorted(
            self._downstream_lifecycle.values(),
            key=lambda item: (float(item.get("first_seen_at", 0.0)), int(item["pass_id"])),
        )
        uncertain = [
            item for item in downstream_all
            if item.get("status") == "removed_local"
            and int(item.get("observations", 0)) < 2
        ]
        downstream_qualified = [item for item in downstream_all if item not in uncertain]
        operations = align_monotonic_events(
            upstream_final, downstream_qualified, DEFAULT_TRAVEL_SECONDS
        )
        rows: list[dict] = []
        for item in upstream_removed:
            rows.append({
                "status": "removed_at_upstream",
                "sequence": item.get("sequence", ""),
                "upstream_pass_id": item.get("upstream_pass_id", ""),
                "downstream_pass_id": "",
                "upstream_color": item.get("color", ""),
                "downstream_color": "",
                "travel_time_s": "",
            })
        for operation in operations:
            kind = operation["operation"]
            upstream = operation.get("upstream")
            downstream = operation.get("downstream")
            if kind == "match":
                status = (
                    "removed_at_downstream"
                    if downstream.get("status") == "removed_local"
                    else "matched"
                )
            elif kind == "skip_upstream":
                status = "removed_between_cameras"
            elif downstream.get("status") == "removed_local":
                status = "uncertain_downstream_unmatched"
            else:
                status = "downstream_extra"
            rows.append({
                "status": status,
                "sequence": upstream.get("sequence", "") if upstream else "",
                "upstream_pass_id": upstream.get("upstream_pass_id", "") if upstream else "",
                "downstream_pass_id": downstream.get("pass_id", "") if downstream else "",
                "upstream_color": upstream.get("color", "") if upstream else "",
                "downstream_color": downstream.get("color", "") if downstream else "",
                "travel_time_s": operation.get("travel_time_s", ""),
                "downstream_observations": downstream.get("observations", "") if downstream else "",
            })
        for item in uncertain:
            rows.append({
                "status": "uncertain_low_evidence",
                "sequence": "",
                "upstream_pass_id": "",
                "downstream_pass_id": item.get("pass_id", ""),
                "upstream_color": "",
                "downstream_color": item.get("color", ""),
                "travel_time_s": "",
                "downstream_observations": item.get("observations", 0),
            })
        counts = Counter(row["status"] for row in rows)
        summary = {
            "algorithm": "monotonic_dynamic_programming",
            "expected_travel_s": DEFAULT_TRAVEL_SECONDS,
            "matched": counts["matched"],
            "removed_at_upstream": counts["removed_at_upstream"],
            "removed_between_cameras": counts["removed_between_cameras"],
            "removed_at_downstream": counts["removed_at_downstream"],
            "downstream_extra": counts["downstream_extra"],
            "uncertain": counts["uncertain_low_evidence"]
            + counts["uncertain_downstream_unmatched"],
        }
        return summary, rows

    def _save_authoritative_alignment(self) -> None:
        if not self.receives_upstream:
            return
        if self.matching_mode == "dp":
            self._recompute_live_alignment()
        summary, rows = self._authoritative_alignment()
        configuration = {
            "matching_mode": self.matching_mode,
            "expected_travel_s": DEFAULT_TRAVEL_SECONDS,
            "gap_cost": ALIGNMENT_GAP_COST,
            "max_time_error_s": ALIGNMENT_MAX_TIME_ERROR_SECONDS,
        }
        configuration_hash = hashlib.sha256(
            json.dumps(configuration, sort_keys=True).encode("utf-8")
        ).hexdigest()
        summary["configuration"] = configuration
        summary["configuration_hash"] = configuration_hash
        (self.output_directory / "sequence_alignment.json").write_text(
            json.dumps({"summary": summary, "rows": rows}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        (self.output_directory / "alignment_candidates.json").write_text(
            json.dumps(self._alignment_candidates, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        decisions = [
            {
                "decision_id": f"{self.session_id}:{index}",
                "run_id": self.session_id,
                "algorithm_name": "monotonic_dynamic_programming",
                "algorithm_version": 1,
                "configuration_hash": configuration_hash,
                "decision_type": row["status"],
                "location": {
                    "source_camera_id": self.upstream_camera_id,
                    "target_camera_id": self.camera_id,
                },
                "source_event_refs": [row.get("upstream_pass_id")]
                if row.get("upstream_pass_id") else [],
                "target_event_refs": [row.get("downstream_pass_id")]
                if row.get("downstream_pass_id") else [],
                "reason_codes": [
                    "insufficient_evidence"
                    if row["status"].startswith("uncertain")
                    else "alignment_wrong_gap"
                    if row["status"] == "downstream_extra"
                    else row["status"]
                ],
                "confidence": None,
                "provisional_or_final": "final",
                "created_at": time.time(),
            }
            for index, row in enumerate(rows, start=1)
        ]
        (self.output_directory / "algorithm_decisions.json").write_text(
            json.dumps(decisions, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        color_names = {"orange": "O", "yellow": "Y", "light_green": "G"}
        lines = [
            "# 權威序列對齊結果", "",
            "此結果使用整批單調動態規劃；即時 MQTT FIFO 僅作暫定通知。", "",
            "| 狀態 | 數量 |", "|---|---:|",
            f"| 正常完成 | {summary['matched']} |",
            f"| 上游範圍拿走 | {summary['removed_at_upstream']} |",
            f"| 兩鏡頭之間拿走 | {summary['removed_between_cameras']} |",
            f"| 下游範圍拿走 | {summary['removed_at_downstream']} |",
            f"| 下游多餘事件 | {summary['downstream_extra']} |",
            f"| 不確定 | {summary['uncertain']} |", "",
            "| 上游序號 | 上游顏色 | 下游 Pass | 下游顏色 | 狀態 | 行程秒數 | 觀測數 |",
            "|---:|---|---:|---|---|---:|---:|",
        ]
        labels = {
            "matched": "正常完成",
            "removed_at_upstream": "上游拿走",
            "removed_between_cameras": "鏡頭間拿走",
            "removed_at_downstream": "下游拿走",
            "downstream_extra": "下游多餘",
            "uncertain_low_evidence": "低證據不確定",
            "uncertain_downstream_unmatched": "未配對不確定",
        }
        for row in rows:
            lines.append(
                f"| {row.get('sequence') or '-'} "
                f"| {color_names.get(row.get('upstream_color'), row.get('upstream_color') or '-')} "
                f"| {row.get('downstream_pass_id') or '-'} "
                f"| {color_names.get(row.get('downstream_color'), row.get('downstream_color') or '-')} "
                f"| {labels.get(row['status'], row['status'])} "
                f"| {row.get('travel_time_s') or '-'} "
                f"| {row.get('downstream_observations') or '-'} |"
            )
        (self.output_directory / "sequence_alignment_summary.md").write_text(
            "\n".join(lines) + "\n", encoding="utf-8"
        )

