"""Inbound MQTT handling and downstream lifecycle matching."""

from __future__ import annotations

import json
import time
from collections import Counter, deque

from .handoff_constants import EVENT_FLICKER_SECONDS, HEARTBEAT_MISSING_SECONDS


class HandoffMessageMixin:
    def _on_message(self, _client, _userdata, message) -> None:
        try:
            payload = json.loads(message.payload.decode("utf-8"))
        except Exception:
            return
        camera_id = str(payload.get("camera_id", ""))
        if not camera_id or camera_id == self.camera_id:
            return
        with self._lock:
            stats = self.stats.setdefault(camera_id, self._empty_stats())
            stats["messages_received"] += 1
            message_id = str(payload.get("message_id", ""))
            if message_id in self._seen_message_ids:
                stats["duplicate_messages"] += 1
                return
            self._seen_message_ids.add(message_id)
            kind = str(payload.get("kind", ""))
            now = time.time()
            if kind in {"heartbeat", "status"}:
                previous = self._peer_last_heartbeat.get(camera_id)
                if previous is not None and now - previous > HEARTBEAT_MISSING_SECONDS:
                    stats["heartbeat_gaps"] += 1
                self._peer_last_heartbeat[camera_id] = now
                stats["last_heartbeat"] = payload.get("timestamp")
                remote_stats = payload.get("mqtt_stats")
                if isinstance(remote_stats, dict):
                    for key in (
                        "connect_count", "disconnect_count", "reconnect_count",
                        "publish_success", "publish_failure",
                    ):
                        if key in remote_stats:
                            stats[key] = remote_stats[key]
            semantic_id = str(
                payload.get("upstream_pass_id", payload.get("state", ""))
            )
            signature = (camera_id, f"{kind}:{semantic_id}")
            previous_event = self._last_event_signature.get(signature)
            if previous_event is not None and now - previous_event < EVENT_FLICKER_SECONDS:
                if kind in {
                    "lap_start", "plate_locked", "plate_detected",
                    "plate_final", "plate_removed", "status",
                }:
                    stats["event_flickers"] += 1
            self._last_event_signature[signature] = now
            received_event = {
                **payload,
                "received_at": now,
                "direction": "received",
                "publish_ok": "",
            }
            self.events.append(received_event)
            if (
                self.receives_upstream
                and camera_id == self.upstream_camera_id
                and kind in {
                    "plate_detected", "plate_updated", "plate_final",
                    "plate_removed", "plate_locked",
                }
            ):
                sequence = int(payload.get("sequence", 0))
                lifecycle_key = (
                    str(payload.get("session_id", "")),
                    int(payload.get("upstream_pass_id", 0)),
                )
                if kind in {"plate_detected", "plate_locked"}:
                    if lifecycle_key in self._upstream_lifecycle:
                        return
                    if self._pending and sequence <= int(self._pending[-1]["sequence"]):
                        stats["out_of_order_events"] += 1
                    entry = {
                        **payload,
                        "received_at": now,
                        "handoff_id": str(
                            payload.get("handoff_id")
                            or f"{payload.get('session_id', '')}:{sequence}"
                        ),
                        "final_received": kind == "plate_locked",
                    }
                    self._upstream_lifecycle[lifecycle_key] = entry
                    self._pending.append(entry)
                elif lifecycle_key in self._upstream_lifecycle:
                    entry = self._upstream_lifecycle[lifecycle_key]
                    if kind in {"plate_updated", "plate_final"}:
                        entry.update({
                            "color": payload.get("color", entry.get("color", "")),
                            "confidence": payload.get(
                                "confidence", entry.get("confidence", "")
                            ),
                            "observations": payload.get(
                                "observations", entry.get("observations", "")
                            ),
                            "final_received": kind == "plate_final"
                            or entry.get("final_received", False),
                            "final_timestamp": payload.get("timestamp", "")
                            if kind == "plate_final"
                            else entry.get("final_timestamp", ""),
                        })
                        if kind == "plate_final":
                            # The arrival window may expire slightly before
                            # the upstream plate reaches its final line.  Once
                            # final confirmation arrives, upgrade that timed-
                            # out row from generic missing to pickup evidence.
                            for result in self.rows:
                                if (
                                    str(result.get("upstream_session_id", ""))
                                    == lifecycle_key[0]
                                    and int(result.get("upstream_pass_id") or 0)
                                    == lifecycle_key[1]
                                    and result.get("handoff_status")
                                    == "downstream_missing"
                                    and not result.get("downstream_pass_id")
                                ):
                                    result["handoff_status"] = (
                                        "removed_between_cameras"
                                    )
                        for result in self.rows:
                            if (
                                str(result.get("upstream_session_id", ""))
                                == lifecycle_key[0]
                                and int(result.get("upstream_pass_id") or 0)
                                == lifecycle_key[1]
                                and result.get("handoff_status") == "fifo_paired"
                            ):
                                result["upstream_color"] = entry.get("color", "")
                                downstream_color = str(
                                    result.get("downstream_color", "")
                                )
                                result["color_correct"] = int(
                                    bool(downstream_color)
                                    and downstream_color == entry.get("color", "")
                                )
                    elif kind == "plate_removed":
                        entry["removed"] = True
                        self._pending = deque(
                            item for item in self._pending if item is not entry
                        )
                        matched_locally = any(
                            binding is entry
                            for binding in self._matched_by_pass.values()
                        )
                        if not matched_locally:
                            key = (
                                str(entry.get("session_id", "")),
                                int(entry.get("upstream_pass_id", 0)),
                            )
                            if key not in self._reported_unarrived:
                                self._reported_unarrived.add(key)
                                self.rows.append(self._unarrived_row(
                                    entry, "removed_at_upstream"
                                ))
                        for local_pass_id, binding in list(
                            self._matched_by_pass.items()
                        ):
                            if binding is entry:
                                binding["removed"] = True
                if self.matching_mode == "dp":
                    self._recompute_live_alignment()

    def downstream_binding(self, pass_id: int) -> dict | None:
        with self._lock:
            binding = self._matched_by_pass.get(int(pass_id))
            return dict(binding) if binding is not None else None

    def publish_downstream_entry(
        self, state: dict, color: str, provisional: bool = False
    ) -> bool:
        """Publish one shared-ID entry, then update it after local confirmation."""
        if not self.receives_upstream:
            return False
        operational_color = str(color or "unknown")
        if operational_color == "unknown":
            return False
        binding = self._matched_by_pass.get(int(state["pass_id"]))
        if binding is None:
            return False
        handoff_id = str(
            binding.get("handoff_id")
            or f"{binding.get('session_id', '')}:{int(binding.get('sequence', 0))}"
        )
        if state.get("hc_entry_published"):
            if provisional or state.get("hc_color_confirmed"):
                return False
            state["hc_color_confirmed"] = True
            return self._publish_hc_event(
                "update", int(state["pass_id"]), operational_color,
                int(state["pass_id"]),
                {
                    "handoff_id": handoff_id,
                    "status": "confirmed",
                    "color_source": "downstream_local",
                },
            )
        state["hc_entry_published"] = True
        state["hc_color_confirmed"] = not provisional
        return self._publish_hc_event(
            "entry", int(state["pass_id"]), operational_color,
            int(state["pass_id"]),
            {
                "handoff_id": handoff_id,
                "status": "provisional" if provisional else "confirmed",
                "color_source": (
                    "upstream_reference" if provisional else "downstream_local"
                ),
            },
        )

    def match_downstream_entry(self, state: dict) -> str:
        """Register a local entry and return its current provisional binding."""
        if not self.receives_upstream:
            return ""
        pass_id = int(state["pass_id"])
        with self._lock:
            self._downstream_lifecycle.setdefault(pass_id, {
                "pass_id": pass_id,
                "lap_id": int(state.get("lap_id", 0)),
                "first_seen_at": float(state.get("first_seen_unix", time.time())),
                "status": "detected",
                "color": "",
                "observations": 0,
                "tracker_ids": [],
            })
            if self.matching_mode == "dp":
                self._recompute_live_alignment()
                binding = self._matched_by_pass.get(pass_id)
                if binding:
                    state["handoff_id"] = str(
                        binding.get("handoff_id")
                        or f"{binding.get('session_id', '')}:{int(binding.get('sequence', 0))}"
                    )
                return str(binding.get("color", "")) if binding else ""
            if pass_id in self._matched_by_pass:
                binding = self._matched_by_pass[pass_id]
                color = str(binding.get("color", ""))
                state["handoff_id"] = str(
                    binding.get("handoff_id")
                    or f"{binding.get('session_id', '')}:{int(binding.get('sequence', 0))}"
                )
                if not self.publishes_downstream:
                    self.publish_downstream_entry(state, color, provisional=True)
                return color
            now = time.time()
            self._expire_overdue_pending(now)
            if not self._pending:
                return ""
            estimate, slack = self._travel_window()
            expected = float(self._pending[0]["timestamp"]) + estimate
            if now < expected - slack:
                return ""
            upstream = self._pending.popleft()
            matched_at = now
            travel_time = matched_at - float(upstream["timestamp"])
            self._travel_samples.append(travel_time)
            upstream["matched_at"] = matched_at
            upstream["travel_time_s"] = travel_time
            binding = upstream
            self._matched_by_pass[pass_id] = binding
            state["handoff_id"] = str(
                binding.get("handoff_id")
                or f"{binding.get('session_id', '')}:{int(binding.get('sequence', 0))}"
            )
            self._publish("plate_claimed", {
                "upstream_session_id": upstream.get("session_id", ""),
                "upstream_pass_id": upstream.get("upstream_pass_id", ""),
                "sequence": upstream.get("sequence", ""),
                "downstream_pass_id": pass_id,
                "downstream_first_seen_at": state.get("first_seen_unix", ""),
            })
            color = str(upstream.get("color", ""))
            if not self.publishes_downstream:
                self.publish_downstream_entry(state, color, provisional=True)
            return color

    def finalize_downstream(self, state: dict) -> None:
        if not self.receives_upstream:
            return
        pass_id = int(state["pass_id"])
        with self._lock:
            if not self.publishes_downstream:
                self.publish_downstream_entry(
                    state, str(state.get("final_color") or "unknown")
                )
            if not self.publishes_downstream and not state.get("hc_exit_published"):
                state["hc_exit_published"] = True
                self._publish_hc_event(
                    "exit", pass_id,
                    str(state.get("final_color") or "unknown"), pass_id,
                )
            self._downstream_lifecycle[pass_id] = {
                "pass_id": pass_id,
                "lap_id": int(state.get("lap_id", 0)),
                "first_seen_at": float(state.get("first_seen_unix", time.time())),
                "status": "completed",
                "color": str(state.get("final_color") or ""),
                "observations": int(state.get("final_observations", 0)),
                "confidence": state.get("final_confidence_median"),
                "tracker_ids": sorted(state.get("tracker_ids", set())),
            }
            if self.matching_mode == "dp":
                self._recompute_live_alignment()
            upstream = self._matched_by_pass.get(pass_id)
            if upstream is not None and upstream.get("removed"):
                self.rows.append({
                    "upstream_session_id": upstream.get("session_id", ""),
                    "upstream_pass_id": upstream.get("upstream_pass_id", ""),
                    "downstream_pass_id": pass_id,
                    "lap_id": upstream.get("lap_id", state["lap_id"]),
                    "sequence": upstream.get("sequence", ""),
                    "upstream_color": upstream.get("color", ""),
                    "downstream_color": state.get("final_color") or "",
                    "color_correct": "",
                    "handoff_status": "upstream_removed",
                    "travel_time_s": "",
                    "upstream_confidence": upstream.get("confidence", ""),
                    "downstream_confidence": state.get("final_confidence_median"),
                    "downstream_tracker_ids": " ".join(
                        str(value) for value in sorted(state.get("tracker_ids", set()))
                    ),
                })
                return
            if upstream is None:
                result_row = {
                    "upstream_session_id": "",
                    "upstream_pass_id": "",
                    "downstream_pass_id": pass_id,
                    "lap_id": int(state["lap_id"]),
                    "sequence": "",
                    "upstream_color": "",
                    "downstream_color": state.get("final_color") or "",
                    "color_correct": "",
                    "handoff_status": "downstream_extra",
                    "travel_time_s": "",
                    "upstream_confidence": "",
                    "downstream_confidence": state.get("final_confidence_median"),
                    "downstream_tracker_ids": " ".join(
                        str(value) for value in sorted(state.get("tracker_ids", set()))
                    ),
                }
                self.rows.append(result_row)
                self._publish(
                    "downstream_result",
                    {
                        "status": "downstream_extra",
                        "downstream_pass_id": pass_id,
                        "downstream_color": state.get("final_color") or "",
                    },
                )
                return
            upstream_color = str(upstream.get("color", ""))
            downstream_color = str(state.get("final_color") or "")
            result_row = {
                "upstream_session_id": upstream.get("session_id", ""),
                "upstream_pass_id": upstream.get("upstream_pass_id", ""),
                "downstream_pass_id": pass_id,
                "lap_id": upstream.get("lap_id", state["lap_id"]),
                "sequence": upstream.get("sequence", ""),
                "upstream_color": upstream_color,
                "downstream_color": downstream_color,
                "color_correct": int(bool(downstream_color) and upstream_color == downstream_color),
                "handoff_status": "fifo_paired",
                "travel_time_s": round(float(upstream["travel_time_s"]), 4),
                "upstream_confidence": upstream.get("confidence", ""),
                "downstream_confidence": state.get("final_confidence_median"),
                "downstream_tracker_ids": " ".join(
                    str(value) for value in sorted(state.get("tracker_ids", set()))
                ),
                "upstream_published_at": upstream.get("timestamp", ""),
                "downstream_mqtt_received_at": upstream.get("received_at", ""),
                "mqtt_delay_ms": round(
                    (float(upstream.get("received_at", upstream["timestamp"]))
                     - float(upstream["timestamp"])) * 1000.0,
                    3,
                ),
                "downstream_first_seen_at": state.get("first_seen_unix", ""),
                "downstream_locked_at": time.time(),
            }
            self.rows.append(result_row)
            self._publish(
                "downstream_result",
                {
                    "status": "fifo_paired",
                    "upstream_session_id": upstream.get("session_id", ""),
                    "upstream_pass_id": upstream.get("upstream_pass_id", ""),
                    "sequence": upstream.get("sequence", ""),
                    "downstream_pass_id": pass_id,
                    "downstream_color": downstream_color,
                    "color_match": int(
                        bool(downstream_color) and upstream_color == downstream_color
                    ),
                },
            )

    def finalize_downstream_removed(self, state: dict) -> None:
        """Record a plate that appeared at cam-2 but vanished before its exit."""
        if not self.receives_upstream:
            return
        pass_id = int(state["pass_id"])
        with self._lock:
            if any(
                str(row.get("downstream_pass_id", "")) == str(pass_id)
                for row in self.rows
            ):
                return
            votes = Counter(state.get("local_color_votes") or {})
            local_color = votes.most_common(1)[0][0] if votes else ""
            if not self.publishes_downstream:
                self.publish_downstream_entry(state, local_color or "unknown")
            if not self.publishes_downstream and not state.get("hc_catch_published"):
                state["hc_catch_published"] = True
                self._publish_hc_event(
                    "catch", pass_id, local_color or "unknown", pass_id,
                    {"event_id": self._removal_event_id(state),
                     "status": "confirmed"},
                )
            self._downstream_lifecycle[pass_id] = {
                "pass_id": pass_id,
                "lap_id": int(state.get("lap_id", 0)),
                "first_seen_at": float(state.get("first_seen_unix", time.time())),
                "status": "removed_local",
                "color": local_color,
                "observations": int(sum(votes.values())),
                "tracker_ids": sorted(state.get("tracker_ids", set())),
            }
            if self.matching_mode == "dp":
                self._recompute_live_alignment()
            upstream = self._matched_by_pass.get(pass_id)
            row = {
                "upstream_session_id": upstream.get("session_id", "") if upstream else "",
                "upstream_pass_id": upstream.get("upstream_pass_id", "") if upstream else "",
                "downstream_pass_id": pass_id,
                "lap_id": upstream.get("lap_id", state.get("lap_id", "")) if upstream else state.get("lap_id", ""),
                "sequence": upstream.get("sequence", "") if upstream else "",
                "upstream_color": upstream.get("color", "") if upstream else "",
                "downstream_color": local_color,
                "color_correct": "",
                "handoff_status": "removed_at_downstream",
                "travel_time_s": round(float(upstream.get("travel_time_s", 0.0)), 4) if upstream else "",
                "upstream_confidence": upstream.get("confidence", "") if upstream else "",
                "downstream_confidence": "",
                "downstream_tracker_ids": " ".join(
                    str(value) for value in sorted(state.get("tracker_ids", set()))
                ),
                "upstream_published_at": upstream.get("timestamp", "") if upstream else "",
                "downstream_mqtt_received_at": upstream.get("received_at", "") if upstream else "",
                "downstream_first_seen_at": state.get("first_seen_unix", ""),
                "downstream_locked_at": "",
            }
            self.rows.append(row)
            self._publish("downstream_result", {
                "status": "removed_at_downstream",
                "upstream_session_id": row["upstream_session_id"],
                "upstream_pass_id": row["upstream_pass_id"],
                "sequence": row["sequence"],
                "downstream_pass_id": pass_id,
                "downstream_color": local_color,
            })

