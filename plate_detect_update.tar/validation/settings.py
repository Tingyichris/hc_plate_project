"""Validation-only settings: evidence recording and capture outputs.

Relative paths resolve under the validation folder so the device folder stays free of
accuracy-validation outputs.
"""

from pathlib import Path

from validation import VALIDATION_ROOT

OUTPUT_ROOT = VALIDATION_ROOT / "outputs"

DETECTION_CAPTURE_DETECTIONS = True
DETECTION_CAPTURE_ROOT = "outputs/false_positive_captures/cam-2"
DETECTION_CAPTURE_INTERVAL_SECONDS = 1.0
DETECTION_OUTPUT_VIDEO = ""
RECORDING_ENABLED = True
RECORDING_ROOT = "outputs/cam-2/bbox_accuracy"


def validation_path(value: str | Path) -> Path:
    """Resolve a validation output path relative to the validation folder."""
    path = Path(value)
    return path if path.is_absolute() else VALIDATION_ROOT / path
