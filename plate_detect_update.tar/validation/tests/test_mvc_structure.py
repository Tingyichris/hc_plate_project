"""Regression checks for MVC module compatibility and project-root paths."""

from __future__ import annotations

import unittest
from pathlib import Path

from validation.controllers import distance_self_check as self_check_controller
from plate_detector.aoi import resolve_aoi_file
from validation.tools import batch_preprocess_images


class MvcStructureTest(unittest.TestCase):
    def test_controllers_read_config_from_device_folder(self):
        expected = Path(__file__).resolve().parents[2] / "device"
        self.assertEqual(batch_preprocess_images.PROJECT_ROOT, expected)
        self.assertEqual(self_check_controller.PROJECT_ROOT, expected)
        self.assertEqual(batch_preprocess_images.DEFAULT_ROI_FILE, resolve_aoi_file())


if __name__ == "__main__":
    unittest.main()
