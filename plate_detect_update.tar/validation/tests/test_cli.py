"""Tests for the validation command dispatcher."""

from __future__ import annotations

import sys
import unittest
from unittest.mock import MagicMock, patch

from validation import __main__ as cli


class ValidationCliTest(unittest.TestCase):
    def test_subcommand_is_removed_before_forwarding(self):
        module = MagicMock()
        with patch.object(sys, "argv", ["validation", "record", "--camera", "2", "--output", "run.mp4"]):
            with patch.object(cli.importlib, "import_module", return_value=module) as importer:
                cli.main()
                self.assertEqual(sys.argv[1:], ["--camera", "2", "--output", "run.mp4"])
        importer.assert_called_once_with("validation.tools.record_video")
        module.main.assert_called_once_with()

    def test_unknown_command_exits(self):
        with patch.object(sys, "argv", ["validation", "detect"]):
            with self.assertRaises(SystemExit):
                cli.main()


if __name__ == "__main__":
    unittest.main()
