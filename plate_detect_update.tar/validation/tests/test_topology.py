import math
import unittest

from validation.models.topology import neighbors_from_map


class TopologyTest(unittest.TestCase):
    def test_twelve_camera_ring_has_one_neighbor_on_each_side(self):
        points = [
            [
                100 + 80 * math.cos(2 * math.pi * index / 12),
                100 + 80 * math.sin(2 * math.pi * index / 12),
            ]
            for index in range(12)
        ]
        document = {
            "version": 12,
            "track": {"path_px": points, "closed": True},
            "cameras": [
                {"id": f"cam-{index + 1}", "counting_point_px": point}
                for index, point in enumerate(points)
            ],
        }
        neighbors = neighbors_from_map(document, "cam-6")
        self.assertEqual(neighbors.upstream_camera_id, "cam-5")
        self.assertEqual(neighbors.downstream_camera_id, "cam-7")

    def test_closed_track_resolves_both_neighbors(self):
        document = {
            "version": 7,
            "track": {
                "path_px": [[0, 0], [100, 0], [100, 100], [0, 100]],
                "closed": True,
            },
            "cameras": [
                {"id": "cam-3", "counting_point_px": [100, 100]},
                {"id": "cam-1", "counting_point_px": [0, 0]},
                {"id": "cam-4", "counting_point_px": [0, 100]},
                {"id": "cam-2", "counting_point_px": [100, 0]},
            ],
        }
        neighbors = neighbors_from_map(document, "cam-2")
        self.assertEqual(neighbors.upstream_camera_id, "cam-1")
        self.assertEqual(neighbors.downstream_camera_id, "cam-3")
        self.assertEqual(neighbors.map_version, 7)

    def test_unknown_camera_is_rejected(self):
        document = {
            "version": 1,
            "track": {"path_px": [[0, 0], [100, 0]], "closed": False},
            "cameras": [
                {"id": "cam-1", "counting_point_px": [0, 0]},
                {"id": "cam-2", "counting_point_px": [100, 0]},
            ],
        }
        with self.assertRaises(LookupError):
            neighbors_from_map(document, "cam-9")


if __name__ == "__main__":
    unittest.main()
