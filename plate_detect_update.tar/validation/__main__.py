"""Validation and accuracy-improvement entry point (not needed on the device).

    python -m validation --help
"""

from __future__ import annotations

import importlib
import sys

HELP = """\
Plate detection validation / accuracy improvement

Live evidence collection:
  python -m validation detect-record [--camera N | --camera-id ID] [--output-video FILE.mp4]
  python -m validation self-check --camera-id LOGICAL_ID [--continuous-handoff] [--select-roi]
  python -m validation color-calibration --camera CAMERA_INDEX
  python -m validation record (--camera N | --camera-id ID) --output FILE.mp4

Offline analysis:
  python -m validation batch-preprocess INPUT_DIRECTORY OUTPUT_DIRECTORY [--roi FILE]
  python -m validation evaluate OUTPUT_DIRECTORY --sequence COLORS [--removal EVENT]
  python -m validation reanalyze-existing OUTPUT_DIRECTORY
  python -m validation reanalyze-handoff OUTPUT_DIRECTORY

For color calibration, wait until the ROI is empty, press B, then insert
orange, green, and yellow plates in order.
Use "python -m validation COMMAND --help" for command-specific parameters.
"""

COMMANDS = {
    "detect-record": "validation.recording.live",
    "self-check": "validation.controllers.distance_self_check",
    "color-calibration": "validation.tools.color_calibration",
    "record": "validation.tools.record_video",
    "batch-preprocess": "validation.tools.batch_preprocess_images",
    "evaluate": "validation.controllers.evaluate_run",
    "reanalyze-existing": "validation.controllers.reanalyze_existing",
    "reanalyze-handoff": "validation.controllers.reanalyze_handoff",
}


def main() -> None:
    args = sys.argv[1:]
    if not args or args[0] in {"-h", "--help"}:
        print(HELP)
        return
    module_name = COMMANDS.get(args[0])
    if module_name is None:
        raise SystemExit(f"Unknown command: {args[0]!r}. Available commands: {', '.join(COMMANDS)}")
    sys.argv = [f"validation {args[0]}", *args[1:]]
    importlib.import_module(module_name).main()


if __name__ == "__main__":
    main()
