"""Start both handoff cameras in unattended production mode.

The MQTT broker and inference service must already be available.  Both camera
workers autosave, run without OpenCV windows, and are restarted if either one
exits unexpectedly.
"""

from __future__ import annotations

import argparse
import subprocess
import sys
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parent
LOG_DIR = ROOT / "runtime_logs"


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mqtt-host", default="127.0.0.1")
    parser.add_argument("--mqtt-port", type=int, default=1883)
    parser.add_argument("--upstream-camera", type=int, default=1)
    parser.add_argument("--downstream-camera", type=int, default=2)
    parser.add_argument("--autosave-seconds", type=float, default=5.0)
    parser.add_argument("--restart-delay", type=float, default=3.0)
    return parser.parse_args()


def worker_args(camera: int, role: str, camera_id: str, peer_id: str, args):
    return [
        sys.executable,
        str(ROOT / "distance_self_check.py"),
        "--camera", str(camera),
        "--handoff-role", role,
        "--camera-id", camera_id,
        "--peer-camera-id", peer_id,
        "--mqtt-host", args.mqtt_host,
        "--mqtt-port", str(args.mqtt_port),
        "--continuous-handoff",
        "--headless",
        "--autosave-seconds", str(args.autosave_seconds),
    ]


def run_pair(args) -> int:
    LOG_DIR.mkdir(exist_ok=True)
    logs = [
        (LOG_DIR / "cam-3.log").open("a", encoding="utf-8", buffering=1),
        (LOG_DIR / "cam-2.log").open("a", encoding="utf-8", buffering=1),
    ]
    commands = [
        worker_args(args.upstream_camera, "upstream", "cam-3", "cam-2", args),
        worker_args(args.downstream_camera, "downstream", "cam-2", "cam-3", args),
    ]
    processes = []
    try:
        for command, log in zip(commands, logs):
            processes.append(subprocess.Popen(
                command,
                cwd=str(ROOT),
                stdout=log,
                stderr=subprocess.STDOUT,
            ))
        while all(process.poll() is None for process in processes):
            time.sleep(1.0)
        return next(
            (process.returncode for process in processes if process.returncode is not None),
            1,
        )
    finally:
        for process in processes:
            if process.poll() is None:
                process.terminate()
        for process in processes:
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
        for log in logs:
            log.close()


def main() -> None:
    args = parse_args()
    print("Production handoff supervisor started. Press Ctrl+C only for maintenance.")
    try:
        while True:
            code = run_pair(args)
            print(f"Camera worker exited with code {code}; restarting in {args.restart_delay:g}s")
            time.sleep(max(0.0, args.restart_delay))
    except KeyboardInterrupt:
        print("Production handoff supervisor stopped.")


if __name__ == "__main__":
    main()
